#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ww3_bench.py -- Find the most efficient run configuration for a WAVEWATCH III (WW3) simulation.

The script reads the CPU topology of the machine (physical cores, sockets, hyperthreads) and runs
ww3_shel with different parallel layouts and time steps, several simulations at a time when they fit
in the cores, each pinned to its own block of cores and working in its own directory.

For every experiment the script
  1. builds one ww3_shel per parallel mode from the switch file (serial: SHRD; MPI: DIST MPI;
     OpenMP: SHRD OMPG; hybrid MPI + OpenMP: DIST MPI OMPG OMPH). Changing the number of cores or the
     time step does not need a new build: WW3 distributes the sea points over the MPI ranks itself;
  2. edits ww3_grid.inp / ww3_grid.nml -> the four time steps (DTMAX, DTXY, DTKTH, DTMIN; the search
     variable is the global step DTMAX, the others keep their ratios) and runs ww3_grid once per
     time step to produce mod_def.ww3;
  3. edits ww3_shel.inp / ww3_shel.nml -> end time = start time + `sim_days` (and the output
     server type IOSTYP in stage 4);
  4. runs ww3_shel (mpirun / OMP_NUM_THREADS / srun), measures the wall-clock time and detects
     instabilities (NaN or floating-point errors in the output, crashes, an optional field check, and
     the propagation CFL number cg_max * DTXY / dx of the lowest frequency).

Stages: 1) time-step search with the serial build; 2) number of cores from `ref_cores`, stopping at
the first configuration with efficiency E = T(1)/(n T(n)) above the threshold; 3) re-timing alone of
the efficiency points measured while sharing the machine; 4) output server types (IOSTYP) on the MPI
runs with more cores than the stage-2 stop point.

With all the results it writes a CSV, figures (PNG), and a report in Markdown, PDF and LaTeX. The files
in run_dir are never modified: every run works on copies. Results are appended to a CSV, so an
interrupted benchmark resumes when the same command is launched again.

Usage
-----
    python3 ww3_bench.py --init-config bench.json   # write an example configuration
    python3 ww3_bench.py -c bench.json --dry-run    # show plan + file edits, nothing is run
    python3 ww3_bench.py -c bench.json              # run the benchmark
    python3 ww3_bench.py -c bench.json --report-only
    python3 ww3_bench.py --check-nc 'ww3.*.nc' --hs-max 30   # field check (for check_cmd)

Requirements: Python >= 3.8, numpy, matplotlib. Optional: reportlab (PDF), netCDF4 or scipy (--check-nc).
"""
from __future__ import annotations

import argparse
import csv
import datetime as _dt
import fnmatch
import glob
import json
import math
import os
import platform
import re
import shlex
import shutil
import signal
import socket
import statistics
import subprocess
import sys
import threading
import time
from pathlib import Path

G = 9.81
DAY = 86400.0
R_EARTH = 6.371e6

# ----------------------------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------------------------
DEFAULT_CONFIG = {
    # --- WW3 case ------------------------------------------------------------------------------
    "run_dir": ".",                 # directory where ww3_shel normally runs (inputs, forcing, *.ww3)
    "grid_input": None,             # None = ww3_grid.nml if present, otherwise ww3_grid.inp
    "shel_input": None,             # None = ww3_shel.nml if present, otherwise ww3_shel.inp
    "switch_file": "switch",        # switch file of the case (relative to run_dir or absolute)

    # --- builds (one ww3_shel per parallel mode) ------------------------------------------------
    # Placeholders: {ww3_dir} {switch} (edited switch file) {build_dir} {jobs} {run_dir}
    "ww3_dir": None,                # WW3 source tree (top directory with CMakeLists.txt); needed to compile
    "compile_cmd": "cmake -S {ww3_dir} -B {build_dir} -DSWITCH={switch} -DCMAKE_INSTALL_PREFIX={build_dir}/install"
                   " -DCMAKE_BUILD_TYPE=Release > /dev/null && cmake --build {build_dir} --target install -j {jobs}",
    "shel_exe": "{build_dir}/install/bin/ww3_shel",   # executable produced by compile_cmd
    "grid_exe": "{build_dir}/install/bin/ww3_grid",   # ww3_grid of the serial build
    # Already built executables (skip compile_cmd for those modes), e.g.
    # {"serial": "/opt/ww3/serial/bin/ww3_shel", "mpi": "/opt/ww3/mpi/bin/ww3_shel", "grid": "/opt/ww3/serial/bin/ww3_grid"}
    "executables": {},
    # parallel switches of each mode (every other switch of the case is kept)
    "mode_switches": {"serial": ["SHRD"], "mpi": ["DIST", "MPI"], "openmp": ["SHRD", "OMPG"],
                      "hybrid": ["DIST", "MPI", "OMPG", "OMPH"]},
    "parallel_switches": ["SHRD", "DIST", "MPI", "OMPG", "OMPH", "OMPX"],  # removed before adding the above
    "build_jobs": 4,                # make -j of each build
    "build_parallel": 2,            # simultaneous builds
    "compile_timeout_s": 3600,

    # --- search space -----------------------------------------------------------------------
    "modes": ["mpi", "openmp"],     # any of "mpi", "openmp", "hybrid"
    "hybrid_threads": [2, 4],       # hybrid: OpenMP threads per MPI rank (ranks = cores / threads)
    "ref_cores": 12,                # stage 2 starts with this number of cores
    "core_step": 2,                 # E <= threshold -> core_step fewer cores
    "sim_days": 1.0,                # simulated period of every run (days)
    "repeat": 1,                    # repetitions of each timed run (median is used)

    # --- machine / concurrency ----------------------------------------------------------------
    "max_cores": None,              # maximum number of cores to use (set it by hand); None = all physical cores
    "use_hyperthreads": False,
    "reserve_cores": 0,             # leave the first N cores free (OS, other users)
    "cpu_list": None,               # explicit logical CPU ids to use, overrides the detection
    "max_parallel_jobs": None,      # None = as many simultaneous runs as cores allow; 1 = sequential
    "efficiency_study": True,       # speed-up / efficiency table and plot (NLHPC "Estudio de Eficiencia")
    "efficiency_threshold": 0.5,    # stage 2 stops at the first core count with E = T(1)/(n T(n)) above this
    "efficiency_exclusive": True,   # re-time alone the points of the efficiency curve measured sharing
    "keep_outputs": False,          # keep out_grd.ww3 / out_pnt.ww3 / restart files of every run

    # --- launch order and reports ------------------------------------------------------------
    "launch_order": "large_first",  # or "small_first"
    "live_report": True,            # rebuild figures and report after every finished simulation
    "pdf_report": True,
    "latex_report": True,

    # --- stage 1: time-step search with the serial build ------------------------------------
    # dt = DTMAX, the global time step. dt_ref, doubled while stable; after the first unstable run the
    # next dt is the midpoint between the last stable and the last unstable dt; stops after two
    # unstable runs in a row. Never above an unstable dt; going down, never below a stable dt whose
    # half is stable.
    "dt_ref": None,                 # reference DTMAX (s); None = the one in the grid input
    "timestep_mode": "proportional",  # DTXY and DTKTH keep their ratio to DTMAX
    "dtmin_mode": "fixed",          # "fixed": DTMIN unchanged (capped at DTMAX); "proportional"
    "min_steps": 10,                # never use a dt that leaves fewer global steps than this in sim_days
    "dt_tol": 0.01,
    "dt_hour_divisor": True,        # optimal dt = largest integer <= the largest stable dt with 3600/dt integer
    "dt_speculation": "strict",     # "strict" (at most 2 serial runs at once) or "aggressive"
    "max_dt_runs": 30,
    "serial_ref_exclusive": True,   # re-time T(1) alone if the serial run at the optimal dt shared the machine
    "explore_exclusive": True,      # stage 2 runs one at a time, so E(n) decisions are not biased by contention

    # --- stability ---------------------------------------------------------------------------
    # WW3 rarely stops when a time step is too long: the fields become noisy or NaN. A run is unstable if
    #  - the log shows NaN / floating-point errors (unstable_regex), or the model crashes with them,
    #  - the propagation CFL number cg(f1)*DTXY/dx exceeds cfl_limit and cfl_rule is "unstable"
    #    (such runs are not launched: the dt is marked unstable directly),
    #  - check_cmd (run in the run directory after the model, not timed) exits with a non-zero code.
    "cfl_limit": 1.0,
    "cfl_rule": "unstable",         # "unstable" | "warn" (run and only report it) | "off"
    "check_cmd": None,              # e.g. "{grid_dir}/ww3_ounf > ounf.log && python3 {bench} --check-nc 'ww3.*.nc'"
    "prep_cmds": [],                # commands run in the run directory before the timed run, e.g. ["{grid_bin}/ww3_strt"]

    # --- stage 4: output server type (IOSTYP) on the MPI runs above the stage-2 stop point ------
    # 0 = no server, direct output from every process (needs a parallel file system), 1 = no server,
    # 2 = last process reserved for output, 3 = several dedicated output processes. [] disables the stage.
    "iostyp_tests": [2, 3],
    "option_modes": ["mpi"],        # parallel modes of the stage-4 tests
    "option_cores": None,           # None = core counts above the stop point; or a list, e.g. [16, 20]

    "blowup_is_global": True,       # an unstable dt is not run with other layouts (running ones are killed)
    "backfill": True,               # fill idle cores with smaller runs that do not delay the queue head
    "backfill_safety": 1.25,

    # --- files of run_dir that are outputs (never linked into the run directories) ----------------
    "output_globs": ["out_grd.*", "out_pnt.*", "out_bnd.*", "log.*", "restart[0-9]*.ww3", "nest[0-9]*.ww3",
                     "track_o.ww3", "partition.*", "mod_def.ww3", "mask.ww3", "ww3.*.nc", "test*.ww3",
                     "prf.*", "output.ww3", "*.nml.log", "ww3_shel.out", "ww3_grid.out"],
    "copy_below_mb": 20,            # other files smaller than this are copied, larger ones symlinked

    # --- execution --------------------------------------------------------------------------
    # placeholders: {exe} {np} (cores) {ranks} {threads} {cpus} (e.g. 4,5,6,7) {places} (e.g. {4},{5})
    "run_cmd": {
        "serial": "taskset -c {cpus} {exe}",
        "openmp": "taskset -c {cpus} {exe}",
        "mpi": "taskset -c {cpus} mpirun --bind-to none -np {ranks} {exe}",
        "hybrid": "taskset -c {cpus} mpirun --bind-to none -np {ranks} {exe}",
    },
    "env": {
        "serial": {"OMP_NUM_THREADS": "1"},
        "openmp": {"OMP_NUM_THREADS": "{threads}", "OMP_PLACES": "{places}", "OMP_PROC_BIND": "close",
                   "OMP_STACKSIZE": "512M"},
        "mpi": {"OMP_NUM_THREADS": "1"},
        "hybrid": {"OMP_NUM_THREADS": "{threads}", "OMP_PROC_BIND": "close", "OMP_STACKSIZE": "512M"},
    },
    # --- HPC (Slurm) ----------------------------------------------------------------------------
    "launcher": "auto",             # "auto": Slurm inside a Slurm job (SLURM_JOB_ID set), local otherwise
    "slurm_step_flags": "--exact --cpu-bind=cores",
    "walltime_margin_s": 600,
    "timeout_s": 6 * 3600,
    "blowup_grace_s": 30,           # kill the run this long after NaN appears in the log
    "poll_s": 2.0,

    # --- log parsing ------------------------------------------------------------------------
    "unstable_regex": r"\bNaN\b|\bInfinity\b|floating[- ]point (exception|invalid)|SIGFPE|"
                      r"Floating-point exception",
    "done_regex": r"End of program",
    "error_regex": r"\*\*\* WAVEWATCH III ERROR|\*\*\* ERROR|Segmentation fault|forrtl: severe|MPI_ABORT|"
                   r"Program received signal|ERROR STOP",

    # --- output -----------------------------------------------------------------------------
    "output_dir": "bench_results",
}

EXAMPLE_COMMENT = (
    "Example configuration for ww3_bench.py. Paths are relative to this file. "
    "Remove keys you do not need: missing keys take the defaults documented in the script."
)
MODES = ("serial", "mpi", "openmp", "hybrid")


def load_config(path: Path | None) -> dict:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    base = Path.cwd()
    user = {}
    if path:
        with open(path) as f:
            user = json.load(f)
        user.pop("_comment", None)
        for k, v in user.items():
            if k not in cfg:
                print(f"[warn] unknown config key '{k}' (ignored)")
                continue
            if k == "env" and isinstance(v, dict):   # merged per mode
                for m, e in v.items():
                    cfg["env"].setdefault(m, {}).update(e or {})
            elif isinstance(cfg[k], dict) and isinstance(v, dict) and k not in ("executables",):
                cfg[k].update(v)
            else:
                cfg[k] = v
        base = path.resolve().parent
    cfg["run_dir"] = str((base / cfg["run_dir"]).resolve())
    out = Path(cfg["output_dir"])
    cfg["output_dir"] = str(out if out.is_absolute() else (base / out).resolve())
    if cfg["ww3_dir"]:
        cfg["ww3_dir"] = str((base / cfg["ww3_dir"]).resolve())
    cfg["executables"] = {k: str((base / v).resolve()) for k, v in (cfg["executables"] or {}).items()}
    for m in cfg["modes"]:
        if m not in ("mpi", "openmp", "hybrid"):
            sys.exit(f"[error] unknown mode '{m}' (use 'mpi', 'openmp' and/or 'hybrid')")
    if cfg["cfl_rule"] not in ("unstable", "warn", "off"):
        sys.exit("[error] cfl_rule must be 'unstable', 'warn' or 'off'")
    lau = cfg["launcher"]
    if lau == "auto":
        lau = "slurm" if os.environ.get("SLURM_JOB_ID") else "local"
    if lau not in ("local", "slurm"):
        sys.exit("[error] launcher must be 'auto', 'local' or 'slurm'")
    cfg["launcher"] = lau
    if lau == "slurm":
        urc = user.get("run_cmd", {}) if isinstance(user.get("run_cmd"), dict) else {}
        for mode, tpl in SLURM_RUN_CMD.items():
            if mode not in urc:          # templates written by the user are kept as they are
                cfg["run_cmd"][mode] = tpl
        uenv = (user.get("env") or {}).get("openmp", {})
        if "OMP_PLACES" not in uenv:     # Slurm chooses the cores of each step
            cfg["env"]["openmp"]["OMP_PLACES"] = "cores"
    return cfg


# job-step templates used inside a Slurm allocation ({slurm_flags} = slurm_step_flags)
SLURM_RUN_CMD = {
    "serial": "srun {slurm_flags} -N 1 -n 1 -c 1 {exe}",
    "openmp": "srun {slurm_flags} -N 1 -n 1 -c {threads} {exe}",
    "mpi": "srun {slurm_flags} -N 1 -n {ranks} -c 1 {exe}",
    "hybrid": "srun {slurm_flags} -N 1 -n {ranks} -c {threads} {exe}",
}


class WallTimeUp(Exception):
    """The Slurm job is close to its time limit: stop cleanly, results are kept for a resubmission."""


def slurm_time_left():
    """Seconds left in the current Slurm job (None if unknown or unlimited)."""
    jid = os.environ.get("SLURM_JOB_ID")
    if not jid or not shutil.which("squeue"):
        return None
    try:
        out = subprocess.run(["squeue", "-h", "-j", jid, "-o", "%L"], capture_output=True, text=True,
                             timeout=30).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None
    m = re.fullmatch(r"(?:(\d+)-)?(?:(\d+):)?(\d+):(\d+)", out)
    if not m:
        return None  # e.g. UNLIMITED / NOT_SET
    d, h, mi, se = (int(x) if x else 0 for x in m.groups())
    return ((d * 24 + h) * 60 + mi) * 60 + se


# ----------------------------------------------------------------------------------------------
# Switch file
# ----------------------------------------------------------------------------------------------
def switch_for_mode(text: str, mode: str, cfg: dict) -> str:
    """Switch file of the case with its parallel switches replaced by those of `mode`."""
    toks = text.split()
    drop = {s.upper() for s in cfg["parallel_switches"]}
    keep = [t for t in toks if t.upper() not in drop]
    add = list(cfg["mode_switches"][mode])
    # the parallel switches go right after the first token (e.g. NCO / F90), as in the WW3 examples
    return " ".join(keep[:1] + add + keep[1:]) + "\n"


def switch_parallel_tokens(text: str, cfg: dict):
    drop = {s.upper() for s in cfg["parallel_switches"]}
    return [t for t in text.split() if t.upper() in drop]


# ----------------------------------------------------------------------------------------------
# WW3 inputs: .inp (positional, '$' comments) and .nml (Fortran namelists, '!' comments)
# ----------------------------------------------------------------------------------------------
TOKEN = re.compile(r"'[^']*'|\"[^\"]*\"|\S+")
DATE_T = re.compile(r"^\d{8}$")
TIME_T = re.compile(r"^\d{6}$")


def _num(tok: str) -> float:
    return float(tok.strip().rstrip(",").lower().replace("d", "e"))


def _fmt_dt(dt: float) -> str:
    return str(int(dt)) if float(dt).is_integer() else f"{dt:g}"


def _fmt_num(x: float) -> str:
    return f"{x:.1f}" if float(x).is_integer() else f"{x:.3f}".rstrip("0")


def inp_data_lines(text: str):
    """(line index, line) of the data lines of a WW3 .inp file (comment lines start with '$')."""
    out = []
    for i, ln in enumerate(text.splitlines(keepends=True)):
        s = ln.strip()
        if not s or s.startswith("$"):
            continue
        out.append((i, ln))
    return out


def _strip_inp_comment(ln: str) -> str:
    """Text before a trailing '$' comment (outside quotes)."""
    q = None
    for k, ch in enumerate(ln):
        if ch in "'\"":
            q = None if q == ch else (ch if q is None else q)
        elif ch == "$" and q is None:
            return ln[:k]
    return ln


def replace_tokens(line: str, new: dict) -> str:
    """Replace the tokens at positions `new` keys of a line, keeping the rest of the line."""
    toks = list(TOKEN.finditer(line))
    out, pos = [], 0
    for idx, m in enumerate(toks):
        out.append(line[pos:m.start()])
        out.append(str(new[idx]) if idx in new else m.group())
        pos = m.end()
    out.append(line[pos:])
    return "".join(out)


# --- namelists ---
NML_ASSIGN = r"(?im)^(?P<pre>[^!\n]*?\b{key}\s*=\s*)(?P<val>'[^']*'|\"[^\"]*\"|[^\s,!/]+)"


def nml_get(text: str, key: str):
    m = re.search(NML_ASSIGN.format(key=re.escape(key)), _nml_uncomment(text))
    if not m:
        return None
    v = m.group("val")
    return v[1:-1] if v[:1] in "'\"" else v


def nml_set(text: str, key: str, value) -> tuple[str, bool]:
    pat = re.compile(NML_ASSIGN.format(key=re.escape(key)))
    clean = _nml_uncomment(text)
    m = pat.search(clean)
    if not m:
        return text, False
    s, e = m.start("val"), m.end("val")
    old = text[s:e]
    v = f"'{value}'" if old[:1] in "'\"" or isinstance(value, str) and not re.fullmatch(r"[-+.\deEdD]+", value) \
        else str(value)
    return text[:s] + v + text[e:], True


def _nml_uncomment(text: str) -> str:
    """Comments ('!' to the end of the line, outside quotes) replaced by spaces: same offsets."""
    out = []
    for ln in text.splitlines(keepends=True):
        q, cut = None, None
        for k, ch in enumerate(ln):
            if ch in "'\"":
                q = None if q == ch else (ch if q is None else q)
            elif ch == "!" and q is None:
                cut = k
                break
        if cut is None:
            out.append(ln)
        else:
            tail = ln[cut:]
            nl = "\n" if tail.endswith("\n") else ""
            out.append(ln[:cut] + " " * (len(tail) - len(nl)) + nl)
    return "".join(out)


# --- ww3_grid ---
TS_KEYS = ("DTMAX", "DTXY", "DTKTH", "DTMIN")


def read_grid_input(text: str, kind: str) -> dict:
    """Time steps, spectral discretisation and (rectilinear) grid of ww3_grid.inp / .nml."""
    g = {"kind": kind}
    if kind == "nml":
        for k in TS_KEYS:
            v = nml_get(text, f"TIMESTEPS%{k}")
            if v is None:
                raise RuntimeError(f"ww3_grid.nml: TIMESTEPS%{k} not found")
            g[k] = _num(v)
        for k, nk in (("xfr", "SPECTRUM%XFR"), ("f1", "SPECTRUM%FREQ1"), ("nk", "SPECTRUM%NK"),
                      ("nth", "SPECTRUM%NTH")):
            v = nml_get(text, nk)
            g[k] = _num(v) if v is not None else None
        for k in ("nk", "nth"):
            g[k] = int(g[k]) if g[k] is not None else None
        g["name"] = nml_get(text, "GRID%NAME") or "?"
        g["type"] = (nml_get(text, "GRID%TYPE") or "RECT").upper()
        g["spherical"] = (nml_get(text, "GRID%COORD") or "SPHE").upper().startswith("SPH")
        g["zlim"] = _num(nml_get(text, "GRID%ZLIM") or "0")
        g["dmin"] = _num(nml_get(text, "GRID%DMIN") or "0")
        if g["type"] == "RECT":
            try:
                for k in ("NX", "NY", "SX", "SY", "SF", "X0", "Y0", "SF0"):
                    v = nml_get(text, f"RECT%{k}")
                    g[k.lower()] = _num(v) if v is not None else (1.0 if k.startswith("SF") else None)
                g["nx"], g["ny"] = int(g["nx"]), int(g["ny"])
            except (TypeError, ValueError):
                g["type"] = "RECT?"
            g["depth_file"] = nml_get(text, "DEPTH%FILENAME")
            g["depth_sf"] = _num(nml_get(text, "DEPTH%SF") or "1")
            g["depth_idla"] = int(_num(nml_get(text, "DEPTH%IDLA") or "1"))
        return g
    data = inp_data_lines(text)
    if len(data) < 4:
        raise RuntimeError("ww3_grid.inp: fewer than 4 data lines (name, spectrum, flags, time steps)")
    g["name"] = _strip_inp_comment(data[0][1]).strip().strip("'\"").strip()
    sp = TOKEN.findall(_strip_inp_comment(data[1][1]))
    if len(sp) >= 4:
        g.update(xfr=_num(sp[0]), f1=_num(sp[1]), nk=int(_num(sp[2])), nth=int(_num(sp[3])))
    ts = TOKEN.findall(_strip_inp_comment(data[3][1]))
    if len(ts) < 4:
        raise RuntimeError(f"ww3_grid.inp: time-step line not understood: {data[3][1].strip()}")
    for k, t in zip(TS_KEYS, ts):
        g[k] = _num(t)
    g["ts_line"] = data[3][0]
    # grid definition: tokens after the 'END OF NAMELISTS' line
    lines = text.splitlines()
    k0 = next((i for i, ln in enumerate(lines) if re.search(r"END\s+OF\s+NAMELISTS", ln, re.I)), None)
    g["type"] = "?"
    if k0 is not None:
        toks = []
        for i in range(k0 + 1, len(lines)):
            s = lines[i].strip()
            if not s or s.startswith("$"):
                continue
            toks += TOKEN.findall(_strip_inp_comment(lines[i]))
            if len(toks) > 25:
                break
        if toks:
            g["type"] = toks[0].strip("'\"").upper()
        try:
            if g["type"] == "RECT":
                g["spherical"] = toks[1].upper().strip(".") in ("T", "TRUE")
                vals = toks[3:]
                g["nx"], g["ny"] = int(_num(vals[0])), int(_num(vals[1]))
                g["sx"], g["sy"], g["sf"] = _num(vals[2]), _num(vals[3]), _num(vals[4])
                g["x0"], g["y0"], g["sf0"] = _num(vals[5]), _num(vals[6]), _num(vals[7])
                g["zlim"], g["dmin"] = _num(vals[8]), _num(vals[9])
                g["depth_sf"] = _num(vals[11])
                g["depth_idla"] = int(_num(vals[12]))
                fn = [t for t in vals[13:20] if t[:1] in "'\""]
                g["depth_from"] = fn[1].strip("'\"").upper() if len(fn) > 1 else "NAME"
                g["depth_file"] = fn[2].strip("'\"") if len(fn) > 2 else None
        except (IndexError, ValueError):
            g["type"] = "RECT?"
    return g


def set_grid_timesteps(text: str, kind: str, ts: dict) -> str:
    if kind == "nml":
        for k in TS_KEYS:
            text, ok = nml_set(text, f"TIMESTEPS%{k}", _fmt_num(ts[k]))
            if not ok:
                raise RuntimeError(f"ww3_grid.nml: TIMESTEPS%{k} not found")
        return text
    lines = text.splitlines(keepends=True)
    i = inp_data_lines(text)[3][0]
    lines[i] = replace_tokens(lines[i], {n: _fmt_num(ts[k]) for n, k in enumerate(TS_KEYS)})
    return "".join(lines)


def timesteps_for(dt: float, g0: dict, cfg: dict) -> dict:
    """The four WW3 time steps for a global step dt, from those of the original grid input."""
    r = dt / g0["DTMAX"]
    ts = {"DTMAX": dt}
    if cfg["timestep_mode"] == "proportional":
        ts["DTXY"] = g0["DTXY"] * r
        ts["DTKTH"] = g0["DTKTH"] * r
    else:  # "fixed": only DTMAX changes (DTXY and DTKTH capped at DTMAX)
        ts["DTXY"] = min(g0["DTXY"], dt)
        ts["DTKTH"] = min(g0["DTKTH"], dt)
    ts["DTMIN"] = g0["DTMIN"] * r if cfg["dtmin_mode"] == "proportional" else min(g0["DTMIN"], dt)
    return {k: round(v, 3) for k, v in ts.items()}


# --- ww3_shel ---
def _parse_date(d: str, t: str):
    return _dt.datetime.strptime(d + t.zfill(6), "%Y%m%d%H%M%S")


def read_shel_input(text: str, kind: str) -> dict:
    """Start / stop time and IOSTYP of ww3_shel.inp / .nml."""
    if kind == "nml":
        st, sp = nml_get(text, "DOMAIN%START"), nml_get(text, "DOMAIN%STOP")
        if not st or not sp:
            raise RuntimeError("ww3_shel.nml: DOMAIN%START and DOMAIN%STOP are needed")
        a, b = st.split(), sp.split()
        io = nml_get(text, "DOMAIN%IOSTYP")
        return {"start": _parse_date(a[0], a[1] if len(a) > 1 else "0"),
                "stop": _parse_date(b[0], b[1] if len(b) > 1 else "0"),
                "iostyp": int(_num(io)) if io is not None else 1, "iostyp_present": io is not None}
    found = []  # (line, token index) of the first two date-time pairs
    for i, ln in inp_data_lines(text):
        toks = TOKEN.findall(_strip_inp_comment(ln))
        for k in range(len(toks) - 1):
            if DATE_T.match(toks[k]) and TIME_T.match(toks[k + 1]):
                found.append((i, k, toks[k], toks[k + 1]))
        if len(found) >= 2:
            break
    if len(found) < 2:
        raise RuntimeError("ww3_shel.inp: start and end times (yyyymmdd hhmmss) not found")
    data = inp_data_lines(text)
    after = [d for d in data if d[0] > found[1][0]]
    io, io_line = None, None
    if after:
        toks = TOKEN.findall(_strip_inp_comment(after[0][1]))
        if len(toks) == 1 and re.fullmatch(r"\d", toks[0]):
            io, io_line = int(toks[0]), after[0][0]
    return {"start": _parse_date(found[0][2], found[0][3]), "stop": _parse_date(found[1][2], found[1][3]),
            "stop_pos": (found[1][0], found[1][1]), "iostyp": io if io is not None else 1,
            "iostyp_line": io_line, "iostyp_present": io is not None}


def set_shel_input(text: str, kind: str, stop: _dt.datetime, iostyp=None) -> tuple[str, list[str]]:
    notes = []
    info = read_shel_input(text, kind)
    if kind == "nml":
        text, _ = nml_set(text, "DOMAIN%STOP", stop.strftime("%Y%m%d %H%M%S"))
        if iostyp is not None:
            text, ok = nml_set(text, "DOMAIN%IOSTYP", str(iostyp))
            if not ok:  # add it to &DOMAIN_NML
                text, n = re.subn(r"(?i)(&DOMAIN_NML[^\n]*\n)", rf"\1  DOMAIN%IOSTYP = {iostyp}\n", text, count=1)
                if not n:
                    raise RuntimeError("ww3_shel.nml: &DOMAIN_NML not found (needed for IOSTYP)")
        return text, notes
    lines = text.splitlines(keepends=True)
    i, k = info["stop_pos"]
    lines[i] = replace_tokens(lines[i], {k: stop.strftime("%Y%m%d"), k + 1: stop.strftime("%H%M%S")})
    if iostyp is not None:
        if info["iostyp_line"] is None:
            raise RuntimeError("ww3_shel.inp: IOSTYP line (after the time frame) not found")
        lines[info["iostyp_line"]] = replace_tokens(lines[info["iostyp_line"]], {0: iostyp})
    return "".join(lines), notes


# ----------------------------------------------------------------------------------------------
# Propagation CFL
# ----------------------------------------------------------------------------------------------
def group_velocity(f: float, h: float | None) -> float:
    """Linear group velocity (m/s) of frequency f (Hz) in depth h (m); deep water if h is None."""
    w = 2 * math.pi * f
    if h is None or h <= 0:
        return G / (2 * w)
    k = w * w / G  # deep-water guess, Newton iterations on w^2 = g k tanh(k h)
    for _ in range(60):
        th = math.tanh(k * h)
        fk = G * k * th - w * w
        dk = G * th + G * k * h * (1 - th * th)
        k_new = k - fk / dk
        if abs(k_new - k) < 1e-12 * k:
            k = k_new
            break
        k = max(k_new, 1e-9)
    kh = k * h
    n = 0.5 * (1 + (2 * kh / math.sinh(2 * kh) if kh < 300 else 0.0))
    return n * w / k


def read_depths(run_dir: Path, g: dict):
    """Water depths (m, positive) of the wet points of a RECT grid, or None if the file cannot be read."""
    fn = g.get("depth_file")
    if not fn or g.get("depth_from", "NAME") != "NAME":
        return None
    p = run_dir / fn
    if not p.exists():
        return None
    try:
        vals = [float(t.replace("D", "E").replace("d", "e")) for t in p.read_text().split()]
    except (OSError, ValueError):
        return None
    if len(vals) < g["nx"] * g["ny"]:
        return None
    z = [v * g.get("depth_sf", 1.0) for v in vals[:g["nx"] * g["ny"]]]
    # WW3 bottom levels: negative below the reference level; wet where z < ZLIM
    zlim = g.get("zlim", 0.0)
    dep = [max(-v, g.get("dmin", 0.0)) for v in z if v < zlim]
    return dep or None


def cfl_factors(run_dir: Path, g: dict):
    """cg_max / dx_min and cg_max / dy_min (1/s): CFL_x = DTXY * fx, CFL_y = DTXY * fy.
    cg_max is the group velocity of the lowest frequency, the fastest component, over the wet depths
    (if the bottom file is readable) or over all depths (about 1.2 x the deep-water value)."""
    if g.get("type") != "RECT" or not g.get("f1") or g.get("sx") is None:
        return None
    f1 = g["f1"]
    deps = read_depths(run_dir, g)
    if deps:
        hs = sorted(set(round(d, 1) for d in deps))
        if len(hs) > 400:
            hs = hs[::max(1, len(hs) // 400)] + [hs[-1]]
        cg = max(group_velocity(f1, h) for h in hs)
        src = f"bottom file {g['depth_file']} ({len(deps)} wet points, h_max {max(deps):.0f} m)"
        hmax = max(deps)
    else:
        L0 = G / (2 * math.pi * f1 ** 2)  # deep-water wavelength
        cg = max(group_velocity(f1, L0 * x / 100.0) for x in range(1, 101))
        src = "depth not read: maximum over all depths (≈ 1.2 × deep water)"
        hmax = None
    sx, sy = g["sx"] / (g.get("sf") or 1.0), g["sy"] / (g.get("sf") or 1.0)
    if g.get("spherical", True):
        y0 = g["y0"] / (g.get("sf0") or 1.0)
        lat = max(abs(y0), abs(y0 + sy * (g["ny"] - 1)))
        lat = min(lat, 89.0)
        dx = R_EARTH * math.radians(sx) * math.cos(math.radians(lat))
        dy = R_EARTH * math.radians(sy)
    else:
        dx, dy = sx, sy
    return {"cg_max": cg, "dx_min": dx, "dy_min": dy, "fx": cg / dx, "fy": cg / dy, "source": src,
            "h_max": hmax, "f1": f1}


# ----------------------------------------------------------------------------------------------
# Log parsing
# ----------------------------------------------------------------------------------------------
LOG_DATE = re.compile(r"(\d{4})[/-](\d{2})[/-](\d{2})[ T]+(\d{2}):(\d{2}):(\d{2})")


def last_model_time(text: str):
    last = None
    for m in LOG_DATE.finditer(text):
        last = m
    if not last:
        return None
    try:
        return _dt.datetime(*map(int, last.groups()))
    except ValueError:
        return None


def parse_log(text: str, cfg: dict, start=None):
    t = last_model_time(text)
    days = (t - start).total_seconds() / DAY if (t and start) else 0.0
    return {
        "blowup": bool(re.search(cfg["unstable_regex"], text, re.I)),
        "done": bool(re.search(cfg["done_regex"], text, re.I)),
        "error": bool(re.search(cfg["error_regex"], text)),
        "days": max(days, 0.0),
    }


# ----------------------------------------------------------------------------------------------
# Field check helper (--check-nc), usable as check_cmd after ww3_ounf
# ----------------------------------------------------------------------------------------------
def check_nc(pattern: str, hs_max: float, var: str = "hs") -> int:
    files = sorted(glob.glob(pattern))
    if not files:
        print(f"[check] no file matches {pattern}")
        return 2
    import numpy as np
    for f in files:
        try:
            import netCDF4
            ds = netCDF4.Dataset(f)
        except ImportError:
            from scipy.io import netcdf_file
            ds = netcdf_file(f, "r", mmap=False)
        try:
            if var not in ds.variables:
                continue
            a = np.ma.filled(np.ma.asarray(ds.variables[var][:]).astype(float), np.nan)
            fv = getattr(ds.variables[var], "_FillValue", None)
            if fv is not None:
                a[a == fv] = np.nan
            a[np.abs(a) > 1e20] = np.nan
            raw = np.ma.asarray(ds.variables[var][:]).astype(float)
            nan = int(np.isnan(raw.filled(0.0)).sum())       # NaN values that are not masked fill values
            mx = np.nanmax(a) if np.isfinite(a).any() else np.nan
        finally:
            ds.close()
        if not np.isfinite(mx) or mx > hs_max or nan > 0:
            print(f"[check] {f}: {var} max = {mx}, {nan} NaN value(s) (limit {hs_max}) -> UNSTABLE")
            return 1
        print(f"[check] {f}: {var} max = {mx:.2f} -> ok")
    return 0


# ----------------------------------------------------------------------------------------------
# Machine information
# ----------------------------------------------------------------------------------------------
def machine_info():
    info = {"hostname": socket.gethostname(), "os": platform.platform(),
            "logical_cpus": os.cpu_count(), "cpu": platform.processor() or "?"}
    try:
        txt = Path("/proc/cpuinfo").read_text()
        m = re.search(r"model name\s*:\s*(.+)", txt)
        if m:
            info["cpu"] = m.group(1).strip()
        phys = {(a, b) for a, b in re.findall(r"physical id\s*:\s*(\d+).*?core id\s*:\s*(\d+)", txt, re.S)}
        if phys:
            info["physical_cores"] = len(phys)
    except OSError:
        pass
    return info


# ----------------------------------------------------------------------------------------------
# Results storage
# ----------------------------------------------------------------------------------------------
FIELDS = ["key", "stage", "mode", "np", "nx", "ny", "opt", "dt", "dtxy", "dtkth", "dtmin", "rep",
          "status", "wall_s", "sim_days", "days_per_hour", "compile_s",
          "exclusive", "peers", "other_cores", "cpus", "t_start",
          "cfl_x", "cfl_y", "cfl_xy", "notes", "log", "timestamp"]
NUMERIC = {"np": int, "nx": int, "ny": int, "dt": float, "dtxy": float, "dtkth": float, "dtmin": float,
           "rep": int, "wall_s": float, "sim_days": float, "days_per_hour": float,
           "compile_s": float, "peers": int, "other_cores": int, "t_start": float,
           "cfl_x": float, "cfl_y": float, "cfl_xy": float}

SERIAL = {"mode": "serial", "np": 1, "nx": 1, "ny": 1}  # nx = MPI ranks, ny = OpenMP threads


def opt_label(pc):
    return f"IOSTYP = {pc['opt'].split('=')[1]}" if pc.get("opt") else "baseline"


def layout_tag(pc):
    t = f"{pc['mode']}_np{pc['np']}_{pc['nx']}x{pc['ny']}"
    if pc.get("opt"):
        t += "_io" + pc["opt"].split("=")[1]
    return t


def layout_txt(a):
    """'4 ranks × 2 threads' style description of a layout."""
    if a["mode"] == "serial":
        return "serial"
    if a["mode"] == "mpi":
        return f"{a['nx']} ranks"
    if a["mode"] == "openmp":
        return f"{a['ny']} threads"
    return f"{a['nx']} × {a['ny']}"


def run_key(pc, dt, rep, exclusive=False):
    return f"{layout_tag(pc)}_dt{_fmt_dt(dt)}_r{rep}" + ("_x" if exclusive else "")


def load_results(path: Path):
    recs = []
    if not path.exists():
        return recs
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            for k, t in NUMERIC.items():
                v = row.get(k, "")
                try:
                    row[k] = t(float(v)) if v not in ("", None) else None
                except ValueError:
                    row[k] = None
            row["exclusive"] = str(row.get("exclusive", "")).strip().lower() == "true"
            recs.append(row)
    return recs


def append_result(path: Path, rec: dict):
    new = not path.exists()
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        if new:
            w.writeheader()
        w.writerow({k: ("" if rec.get(k) is None else rec.get(k)) for k in FIELDS})


# ----------------------------------------------------------------------------------------------
# CPU topology and core slots
# ----------------------------------------------------------------------------------------------
def cpu_slots(cfg):
    """Logical CPU ids the scheduler may hand out, one per physical core by default,
    ordered socket by socket so that contiguous blocks share caches."""
    if cfg["cpu_list"]:
        slots = [int(c) for c in cfg["cpu_list"]]
        return slots, {"source": "cpu_list", "slots": len(slots)}
    try:
        allowed = sorted(os.sched_getaffinity(0))
    except AttributeError:
        allowed = list(range(os.cpu_count() or 1))
    groups = {}
    for c in allowed:
        base = Path(f"/sys/devices/system/cpu/cpu{c}/topology")
        try:
            core = int((base / "core_id").read_text())
            pkg = int((base / "physical_package_id").read_text())
        except (OSError, ValueError):
            core, pkg = c, 0
        groups.setdefault((pkg, core), []).append(c)
    keys = sorted(groups)
    phys = [groups[k][0] for k in keys]
    ht = [c for k in keys for c in groups[k][1:]]
    r = int(cfg["reserve_cores"] or 0)
    phys_av = phys[r:]
    ht_av = [c for k in keys[r:] for c in groups[k][1:]]
    mc = cfg["max_cores"]
    if mc:  # number of cores fixed by the user: respected as given
        mc = int(mc)
        pool = phys_av + ht_av
        if mc > len(pool):
            print(f"[warn] max_cores={mc} but only {len(pool)} logical CPUs are available: using {len(pool)}")
        elif mc > len(phys_av):
            print(f"[warn] max_cores={mc} exceeds the {len(phys_av)} physical cores: "
                  f"{mc - len(phys_av)} hyperthread(s) will be used as cores")
        slots = pool[:mc]
    else:
        slots = phys_av + (ht_av if cfg["use_hyperthreads"] else [])
    if not slots:
        sys.exit("[error] no CPU left for the benchmark (check reserve_cores / max_cores)")
    return slots, {"source": "topology", "logical_allowed": len(allowed), "physical": len(phys),
                   "sockets": len({k[0] for k in keys}), "hyperthreads": len(ht), "slots": len(slots)}


# ----------------------------------------------------------------------------------------------
# Per-run directories: every file of run_dir is copied (small) or linked (large), except outputs
# ----------------------------------------------------------------------------------------------
def is_output_name(name: str, cfg: dict) -> bool:
    return any(fnmatch.fnmatch(name, pat) for pat in cfg["output_globs"])


def populate_dir(dst: Path, run_dir: Path, cfg: dict, skip=()):
    """Make dst look like run_dir for WW3: small files copied, large files and directories symlinked,
    output files left out (WW3 creates them), names in `skip` left for the caller."""
    lim = float(cfg["copy_below_mb"]) * 1e6
    for p in run_dir.iterdir():
        if p.name in skip or is_output_name(p.name, cfg) or p.name.startswith(".") \
                or p.name == Path(cfg["output_dir"]).name:
            continue
        if p.is_file() and not p.is_symlink() and p.stat().st_size < lim:
            shutil.copy2(p, dst / p.name)
        else:
            (dst / p.name).symlink_to(p.resolve())


# ----------------------------------------------------------------------------------------------
# Benchmark driver
# ----------------------------------------------------------------------------------------------
class Job:
    def __init__(self, pc, dt, stage, rep=0, exclusive=False):
        self.pc, self.dt, self.stage, self.rep, self.exclusive = pc, float(dt), stage, rep, exclusive
        self.np = pc["np"]                       # cores used = MPI ranks x OpenMP threads
        self.key = run_key(pc, dt, rep, exclusive)
        self.proc = self.thread = self.fw = self.fr = None
        self.filler = stage.startswith("filler")
        self.est = None
        self.cpus, self.slot_idx = [], []
        self.t0 = self.t_end = self.t_epoch = None
        self.peers = self.other_cores = 0
        self.blow_t, self.timed_out, self.cancelled = None, False, False
        self.tail, self.notes = "", []
        self.sandbox = self.log = self.ts = None
        self.pre_status = None                   # status decided before launching (CFL rule, ww3_grid failure)


class Bench:
    def __init__(self, cfg: dict, rerun=False, dry_run=False):
        self.cfg = cfg
        self.dry = dry_run
        self.run_dir = Path(cfg["run_dir"])
        self.out = Path(cfg["output_dir"])
        rd = self.run_dir
        self.grid_name = cfg["grid_input"] or ("ww3_grid.nml" if (rd / "ww3_grid.nml").exists() else "ww3_grid.inp")
        self.shel_name = cfg["shel_input"] or ("ww3_shel.nml" if (rd / "ww3_shel.nml").exists() else "ww3_shel.inp")
        for n in (self.grid_name, self.shel_name):
            if not (rd / n).exists():
                sys.exit(f"[error] {n} not found in {rd}")
        self.grid_kind = "nml" if self.grid_name.endswith(".nml") else "inp"
        self.shel_kind = "nml" if self.shel_name.endswith(".nml") else "inp"
        self.pristine = {"grid": (rd / self.grid_name).read_text(), "shel": (rd / self.shel_name).read_text()}
        sw = Path(cfg["switch_file"])
        self.switch_path = sw if sw.is_absolute() else rd / sw
        self.switch_text = self.switch_path.read_text() if self.switch_path.exists() else None
        if not dry_run:
            for d in ("builds", "logs", "work", "moddef"):
                (self.out / d).mkdir(parents=True, exist_ok=True)
        self.csv = self.out / "results.csv"
        self.results = [] if (rerun or dry_run) else load_results(self.csv)
        if rerun and self.csv.exists() and not dry_run:
            self.csv.rename(self.csv.with_suffix(f".{int(time.time())}.bak"))
        self.done = {r["key"]: r for r in self.results}
        self.global_fail = None
        for r in self.results:  # knowledge from a previous (resumed) session
            if r["status"] == "UNSTABLE":
                self.global_fail = r["dt"] if self.global_fail is None else min(self.global_fail, r["dt"])

        # machine / cores
        self.slots, self.topo = cpu_slots(cfg)
        self.ncores = len(self.slots)
        self.ref_cores = int(cfg["ref_cores"])
        if self.ref_cores > self.ncores or self.ref_cores < 2:
            nc = max(2, min(self.ref_cores, self.ncores))
            print(f"[warn] ref_cores={self.ref_cores} outside [2, {self.ncores}] usable cores: starting with {nc}")
            self.ref_cores = nc
        self.max_jobs = int(cfg["max_parallel_jobs"] or self.ncores)
        self.backfill = bool(cfg["backfill"]) and self.max_jobs > 1
        if cfg["launch_order"] not in ("large_first", "small_first"):
            sys.exit("[error] launch_order must be 'large_first' or 'small_first'")
        self.large_first = cfg["launch_order"] == "large_first"
        self.live = None
        self.dt_opt = None
        self.running, self.free, self.fillers = [], set(range(self.ncores)), []
        self.dt_floor, self.dt_phase = None, None
        self.taskset = shutil.which("taskset")
        self.launcher = cfg["launcher"]
        self.deadline = None
        if self.launcher == "slurm":
            left = slurm_time_left()
            if left is not None:
                self.deadline = time.time() + left
            nn = os.environ.get("SLURM_JOB_NUM_NODES") or os.environ.get("SLURM_NNODES")
            if nn and nn.isdigit() and int(nn) > 1:
                print(f"[warn] the Slurm job has {nn} nodes: only the cores of this node are used (request -N 1)")
            if not shutil.which("srun"):
                print("[warn] launcher 'slurm' but 'srun' was not found in PATH")
        self.wake = threading.Event()
        self.builds, self.compile_s, self.grid_exe = {}, {}, None
        self.compile_fail_recorded = {r["mode"] for r in self.results if r["status"] == "COMPILE_FAIL"}
        self.moddefs = {}

        self.g0 = read_grid_input(self.pristine["grid"], self.grid_kind)
        self.s0 = read_shel_input(self.pristine["shel"], self.shel_kind)
        self.cfl = cfl_factors(self.run_dir, self.g0)
        mi = machine_info()
        mi.update({"cores_used": self.ncores, "cpu_slots": self.slots, "topology": self.topo,
                   "max_parallel_jobs": self.max_jobs})
        g = self.g0
        self.meta = {"grid_name": g.get("name"), "grid_file": self.grid_name, "shel_file": self.shel_name,
                     "grid_type": g.get("type"), "nx": g.get("nx"), "ny": g.get("ny"), "nk": g.get("nk"),
                     "nth": g.get("nth"), "f1": g.get("f1"), "xfr": g.get("xfr"),
                     "spherical": g.get("spherical"), "ts0": {k: g[k] for k in TS_KEYS},
                     "dt0": g["DTMAX"], "iostyp0": self.s0["iostyp"],
                     "start": self.s0["start"].isoformat(sep=" "),
                     "switch": " ".join(self.switch_text.split()) if self.switch_text else None,
                     "cfl": self.cfl, "ref_cores": self.ref_cores, "machine": mi}
        if not (rerun or dry_run):
            self.load_state()

    # ---------------------------------------------------------------- state (for --report-only / resume)
    STATE_KEYS = ("dt_path", "explore_path", "dt_opt", "dt_stable_max", "options")

    def restore(self):
        """Nothing to restore: run_dir is never modified."""
        return

    # ---------------------------------------------------------------- layouts
    def decomps(self, mode, n):
        """Layouts of n cores: MPI n ranks; OpenMP n threads; hybrid ranks x threads for each
        hybrid_threads value dividing n (at least 2 ranks)."""
        if mode == "serial":
            return [dict(SERIAL)]
        if mode == "mpi":
            return [{"mode": "mpi", "np": n, "nx": n, "ny": 1}]
        if mode == "openmp":
            return [{"mode": "openmp", "np": n, "nx": 1, "ny": n}]
        out = []
        for t in self.cfg["hybrid_threads"]:
            t = int(t)
            if t >= 2 and n % t == 0 and n // t >= 2:
                out.append({"mode": "hybrid", "np": n, "nx": n // t, "ny": t})
        return out

    def layouts(self, n=None):
        n = self.ref_cores if n is None else n
        out = [dict(SERIAL)]
        for mode in self.cfg["modes"]:
            out += self.decomps(mode, n)
        return out

    # ---------------------------------------------------------------- builds (one per parallel mode)
    def exe_for(self, pc):
        return self.builds.get(pc["mode"])

    def _fmt_build(self, s, mode):
        bd = self.out / "builds" / mode
        return s.format(ww3_dir=self.cfg["ww3_dir"] or "", switch=bd / "switch", build_dir=bd,
                        jobs=self.cfg["build_jobs"], run_dir=self.run_dir)

    def build_all(self, layouts):
        modes = list(dict.fromkeys(pc["mode"] for pc in layouts))
        todo = []
        for m in modes:
            if m in self.builds:
                continue
            pre = self.cfg["executables"].get(m)
            if pre:
                self.builds[m] = Path(pre) if Path(pre).exists() else None
                if not self.builds[m]:
                    print(f"[build] executables.{m} = {pre} does not exist")
                continue
            exe = Path(self._fmt_build(self.cfg["shel_exe"], m))
            if exe.exists():
                self.builds[m] = exe
                continue
            todo.append(m)
        if "serial" in modes and self.grid_exe is None:
            pre = self.cfg["executables"].get("grid")
            cand = Path(pre) if pre else Path(self._fmt_build(self.cfg["grid_exe"], "serial"))
            if cand.exists():
                self.grid_exe = cand
        if not todo:
            return
        if not self.switch_text:
            print(f"[build] switch file {self.switch_path} not found: cannot compile {', '.join(todo)} "
                  "(set switch_file, or give the executables)")
            for m in todo:
                self.builds[m] = None
            return
        if not self.cfg["ww3_dir"] and "{ww3_dir}" in self.cfg["compile_cmd"]:
            print("[build] ww3_dir is not set: cannot compile " + ", ".join(todo)
                  + " (set ww3_dir, or give the executables)")
            for m in todo:
                self.builds[m] = None
            return
        print(f"\n=== compiling ww3_shel for {', '.join(todo)} (up to {self.cfg['build_parallel']} at a time) ===")
        queue, running = list(todo), []
        nb = max(1, int(self.cfg["build_parallel"]))
        try:
            while queue or running:
                while queue and len(running) < nb:
                    m = queue.pop(0)
                    bd = self.out / "builds" / m
                    bd.mkdir(parents=True, exist_ok=True)
                    (bd / "switch").write_text(switch_for_mode(self.switch_text, m, self.cfg))
                    cmd = self._fmt_build(self.cfg["compile_cmd"], m)
                    log = open(self.out / "logs" / f"compile_{m}.log", "w")
                    log.write(f"# {cmd}\n# switch: {(bd / 'switch').read_text()}\n")
                    log.flush()
                    p = subprocess.Popen(cmd, shell=True, cwd=bd, stdout=log, stderr=subprocess.STDOUT,
                                         start_new_session=True)
                    running.append((m, p, log, time.perf_counter()))
                    print(f"[build] {m}: {' '.join(self.cfg['mode_switches'][m])} started")
                time.sleep(0.5)
                for item in list(running):
                    m, p, log, t0 = item
                    el = time.perf_counter() - t0
                    if p.poll() is None and el < self.cfg["compile_timeout_s"]:
                        continue
                    if p.poll() is None:
                        self._kill(p)
                    log.close()
                    running.remove(item)
                    exe = Path(self._fmt_build(self.cfg["shel_exe"], m))
                    if p.returncode == 0 and exe.exists():
                        self.builds[m], self.compile_s[m] = exe, el
                        print(f"[build] {m} ok ({el:.0f} s)")
                    else:
                        self.builds[m] = None
                        print(f"[build] {m} FAILED (see logs/compile_{m}.log)")
                        if m not in self.compile_fail_recorded:
                            self.compile_fail_recorded.add(m)
                            self._record({"key": f"{m}_compile", "stage": "build", "mode": m, "np": 0, "nx": 0,
                                          "ny": 0, "rep": 0, "status": "COMPILE_FAIL", "compile_s": round(el, 1),
                                          "log": str(self.out / "logs" / f"compile_{m}.log"),
                                          "notes": f"switch: {' '.join(self.cfg['mode_switches'][m])}",
                                          "timestamp": _dt.datetime.now().isoformat(timespec="seconds")})
        except BaseException:
            for m, p, log, _ in running:
                self._kill(p)
                log.close()
            raise
        if self.grid_exe is None:
            pre = self.cfg["executables"].get("grid")
            cand = Path(pre) if pre else Path(self._fmt_build(self.cfg["grid_exe"], "serial"))
            if cand.exists():
                self.grid_exe = cand

    # ---------------------------------------------------------------- mod_def.ww3 per time step
    def moddef(self, dt):
        """Run ww3_grid with the time steps of dt (once per dt); returns (mod_def path, ts, error)."""
        ts = timesteps_for(dt, self.g0, self.cfg)
        if dt in self.moddefs:
            return self.moddefs[dt]
        d = self.out / "moddef" / f"dt{_fmt_dt(dt)}"
        md = d / "mod_def.ww3"
        if md.exists():
            self.moddefs[dt] = (md, ts, None)
            return self.moddefs[dt]
        if self.grid_exe is None:
            res = (None, ts, "ww3_grid executable not available (serial build or executables.grid)")
            self.moddefs[dt] = res
            return res
        if d.exists():
            shutil.rmtree(d)
        d.mkdir(parents=True)
        populate_dir(d, self.run_dir, self.cfg, skip={self.grid_name})
        (d / self.grid_name).write_text(set_grid_timesteps(self.pristine["grid"], self.grid_kind, ts))
        with open(d / "ww3_grid.out", "w") as f:
            try:
                rc = subprocess.run([str(self.grid_exe)], cwd=d, stdout=f, stderr=subprocess.STDOUT,
                                    timeout=1800).returncode
            except subprocess.TimeoutExpired:
                rc = -999
        err = None if (rc == 0 and md.exists()) else \
            f"ww3_grid failed for dt={_fmt_dt(dt)} s (exit {rc}, see {d / 'ww3_grid.out'})"
        if err:
            print(f"[grid] {err}")
        else:
            for p in d.iterdir():  # keep only the products of ww3_grid
                if p.is_symlink() or (p.name not in ("mod_def.ww3", "mask.ww3", "ww3_grid.out", self.grid_name)
                                      and not is_output_name(p.name, self.cfg)):
                    if p.is_dir() and not p.is_symlink():
                        shutil.rmtree(p, ignore_errors=True)
                    else:
                        p.unlink()
        self.moddefs[dt] = (md if not err else None, ts, err)
        return self.moddefs[dt]

    def predicted_cfl(self, ts):
        if not self.cfl:
            return None
        cx, cy = ts["DTXY"] * self.cfl["fx"], ts["DTXY"] * self.cfl["fy"]
        return {"cfl_x": round(cx, 4), "cfl_y": round(cy, 4), "cfl_xy": round(max(cx, cy), 4)}

    # ---------------------------------------------------------------- one job
    def _kill(self, p):
        for sig in (signal.SIGTERM, signal.SIGKILL):
            try:
                os.killpg(p.pid, sig)
            except (ProcessLookupError, PermissionError):
                return
            try:
                p.wait(timeout=15)
                return
            except subprocess.TimeoutExpired:
                continue

    def make_sandbox(self, j: Job, md: Path):
        sb = self.out / "work" / j.key
        if sb.exists():
            shutil.rmtree(sb)
        sb.mkdir(parents=True)
        populate_dir(sb, self.run_dir, self.cfg, skip={self.grid_name, self.shel_name})
        (sb / self.grid_name).write_text(set_grid_timesteps(self.pristine["grid"], self.grid_kind, j.ts))
        stop = self.s0["start"] + _dt.timedelta(days=float(self.cfg["sim_days"]))
        iostyp = int(j.pc["opt"].split("=")[1]) if j.pc.get("opt") else None
        txt, notes = set_shel_input(self.pristine["shel"], self.shel_kind, stop, iostyp)
        j.notes += notes
        (sb / self.shel_name).write_text(txt)
        (sb / "mod_def.ww3").symlink_to(md.resolve())
        if (md.parent / "mask.ww3").exists():
            (sb / "mask.ww3").symlink_to((md.parent / "mask.ww3").resolve())
        return sb

    def _fmt(self, j: Job, exe):
        cfg = self.cfg
        return {"exe": str(exe), "np": j.np, "ranks": j.pc["nx"], "threads": j.pc["ny"],
                "cpus": ",".join(map(str, j.cpus)), "places": ",".join("{%d}" % c for c in j.cpus),
                "slurm_flags": cfg["slurm_step_flags"], "bench": shlex.quote(str(Path(__file__).resolve())),
                "grid_dir": str(self.grid_exe.parent) if self.grid_exe else "",
                "grid_bin": str(self.grid_exe.parent) if self.grid_exe else "",
                "shel_dir": str(Path(exe).parent), "run_dir": str(self.run_dir)}

    def _command(self, j: Job, exe: Path):
        cfg = self.cfg
        fmt = self._fmt(j, exe)
        tpl = cfg["run_cmd"][j.pc["mode"]]
        if "taskset" in tpl and not self.taskset:
            tpl = re.sub(r"taskset\s+(-c\s+)?\{cpus\}\s*", "", tpl)
            j.notes.append("taskset not found: run not pinned to its cores")
        env = os.environ.copy()
        for k, v in cfg["env"].get(j.pc["mode"], {}).items():
            env[k] = str(v).format(**fmt)
        return tpl.format(**fmt), env

    def _start(self, j: Job, exe: Path):
        ts = timesteps_for(j.dt, self.g0, self.cfg)
        cfl = self.predicted_cfl(ts)
        md, err = None, None
        if not (cfl and self.cfg["cfl_rule"] == "unstable" and cfl["cfl_xy"] > float(self.cfg["cfl_limit"])):
            md, ts, err = self.moddef(j.dt)   # ww3_grid only for the time steps that are run
        j.ts = ts
        j.log = self.out / "logs" / f"run_{j.key}.log"
        j.t_epoch = time.time()
        j.t0 = time.perf_counter()
        if err or md is None:
            # decided without running: the job ends at once
            j.pre_status = ("ERROR", err) if err else \
                ("UNSTABLE", f"propagation CFL {cfl['cfl_xy']:.2f} > {self.cfg['cfl_limit']:g} (not run)")
            j.log.write_text(f"# not run: {j.pre_status[1]}\n")
            j.t_end = j.t0
            self.wake.set()
            print(f"[run]   {j.key:34s} not run: {j.pre_status[1]}", flush=True)
            return
        j.sandbox = self.make_sandbox(j, md)
        fmt = self._fmt(j, exe)
        prep = "".join(f"{c.format(**fmt)} >> prep.log 2>&1 && " for c in self.cfg["prep_cmds"] or [])
        if prep:
            r = subprocess.run(prep + "true", shell=True, cwd=j.sandbox)
            if r.returncode != 0:
                j.pre_status = ("ERROR", "prep_cmds failed (see prep.log in the run directory)")
                j.log.write_text(f"# not run: {j.pre_status[1]}\n")
                j.t_end = time.perf_counter()
                self.wake.set()
                return
            j.t0 = time.perf_counter()
        cmd, env = self._command(j, exe)
        j.fw = open(j.log, "w")
        j.fw.write(f"# command: {cmd}\n# cwd: {j.sandbox}\n# cpus: {j.cpus}\n"
                   f"# started: {_dt.datetime.now().isoformat()}\n")
        j.fw.flush()
        j.fr = open(j.log, "r", errors="replace")
        j.t_epoch = time.time()
        j.t0 = time.perf_counter()
        j.proc = subprocess.Popen(cmd, shell=True, cwd=j.sandbox, stdout=j.fw, stderr=subprocess.STDOUT,
                                  env=env, start_new_session=True)

        def _waiter(job=j):
            job.proc.wait()
            job.t_end = time.perf_counter()
            self.wake.set()
        j.thread = threading.Thread(target=_waiter, daemon=True)
        j.thread.start()
        print(f"[run]   {j.key:34s} cpus={_cpu_ranges(j.cpus):>10s}  DTMAX/DTXY={_fmt_dt(ts['DTMAX'])}/"
              f"{_fmt_num(ts['DTXY'])} s", flush=True)

    def _monitor(self, j: Job, blow_re):
        if j.t_end is not None:
            return
        chunk = j.fr.read()
        if chunk:
            j.tail = j.tail[-4000:] + chunk
            if j.blow_t is None and blow_re.search(j.tail):
                j.blow_t = time.perf_counter()
        now = time.perf_counter()
        if j.blow_t is not None and now - j.blow_t > self.cfg["blowup_grace_s"]:
            self._kill(j.proc)
        elif now - j.t0 > self.cfg["timeout_s"]:
            j.timed_out = True
            self._kill(j.proc)

    def _close(self, j: Job):
        if j.thread:
            j.thread.join(timeout=30)
        for fh in (j.fw, j.fr):
            if fh:
                fh.close()

    def _cleanup_sandbox(self, j: Job):
        if self.cfg["keep_outputs"] or not j.sandbox or not j.sandbox.exists():
            return
        for f in j.sandbox.iterdir():
            if f.is_file() and not f.is_symlink() and (is_output_name(f.name, self.cfg) or f.suffix == ".nc") \
                    and not f.name.startswith("log."):
                f.unlink()

    def _finish(self, j: Job):
        self._close(j)
        cfg, dt = self.cfg, j.dt
        notes = list(j.notes)
        wall = (j.t_end or time.perf_counter()) - j.t0
        rec = {"key": j.key, "stage": j.stage, **j.pc, "dt": dt, "rep": j.rep,
               "dtxy": j.ts["DTXY"], "dtkth": j.ts["DTKTH"], "dtmin": j.ts["DTMIN"],
               "exclusive": j.exclusive, "peers": j.peers, "other_cores": j.other_cores,
               "cpus": _cpu_ranges(j.cpus), "t_start": round(j.t_epoch, 2), "log": str(j.log),
               "compile_s": round(self.compile_s.get(j.pc["mode"], 0.0), 1),
               "timestamp": _dt.datetime.fromtimestamp(j.t_epoch).isoformat(timespec="seconds")}
        cfl = self.predicted_cfl(j.ts)
        if cfl:
            rec.update(cfl)
        if j.pre_status:
            rec.update(status=j.pre_status[0], notes=j.pre_status[1], peers=0, other_cores=0, cpus="")
            print(f"[done]  {j.key:34s} {j.pre_status[0]:8s} {j.pre_status[1]}", flush=True)
            self._record(rec)
            return rec
        rc = j.proc.returncode
        text = j.log.read_text(errors="replace")
        lw = j.sandbox / "log.ww3" if j.sandbox else None
        if lw and lw.exists():
            text += "\n" + lw.read_text(errors="replace")
        info = parse_log(text, cfg, self.s0["start"])
        sim_days = info["days"]
        if info["blowup"]:
            status = "UNSTABLE"
            notes.append("NaN / floating-point error in the log")
        elif j.timed_out:
            status = "TIMEOUT"
        elif rc == 0 and not info["error"] and (info["done"] or sim_days >= 0.99 * cfg["sim_days"]):
            status = "OK"
            if not info["done"]:
                notes.append("no 'End of program' in the log; accepted from the simulated time")
            if sim_days < 0.99 * cfg["sim_days"]:
                sim_days = float(cfg["sim_days"])
        else:
            status = "ERROR"
            notes.append(f"exit code {rc}")
        if status == "OK" and cfg["check_cmd"]:
            fmt = self._fmt(j, self.exe_for(j.pc) or "")
            r = subprocess.run(cfg["check_cmd"].format(**fmt), shell=True, cwd=j.sandbox, capture_output=True,
                               text=True, timeout=3600)
            with open(j.log, "a") as f:
                f.write(f"\n# check_cmd (exit {r.returncode}):\n{r.stdout}{r.stderr}")
            if r.returncode != 0:
                status = "UNSTABLE"
                notes.append(f"check_cmd failed (exit {r.returncode})")
        if cfl and cfg["cfl_rule"] == "warn" and cfl["cfl_xy"] > float(cfg["cfl_limit"]):
            notes.append(f"propagation CFL {cfl['cfl_xy']:.2f} > {cfg['cfl_limit']:g}")
        rec.update(status=status, wall_s=round(wall, 3), sim_days=round(sim_days, 4))
        if status == "OK":
            rec["days_per_hour"] = round(sim_days / (wall / 3600.0), 3)
        rec["notes"] = "; ".join(dict.fromkeys(notes))
        msg = f"{status:8s} wall={wall:9.1f}s  days={sim_days:.3f}  with {j.peers} other run(s)"
        if cfl:
            msg += f"  CFL_xy={cfl['cfl_xy']:.3f}"
        print(f"[done]  {j.key:34s} {msg}", flush=True)
        self._cleanup_sandbox(j)
        self._record(rec)
        return rec

    def _est_end(self, j: Job):
        """Expected end (perf_counter time) of a running job: model time in the log first, estimate otherwise."""
        now = time.perf_counter()
        el = now - j.t0
        t = last_model_time(j.tail)
        if t is not None:
            f = (t - self.s0["start"]).total_seconds() / (float(self.cfg["sim_days"]) * DAY)
            if 0.02 <= f <= 1.0:
                return now + el * (1.0 - f) / f
        if j.est is not None:
            return j.t0 + max(j.est, el)
        return now if not j.filler else float("inf")

    # ---------------------------------------------------------------- stage 4: IOSTYP
    def _best_tag(self, tag, dt):
        pts = [a for a in aggregate(self.results, options=True) if a["tag"] == tag and a["dt"] == dt
               and a["status"] == "OK" and a["wall_s"]]
        return min(pts, key=lambda a: a["wall_s"]) if pts else None

    def option_counts(self, mode):
        """Core counts above the stage-2 stop point of `mode` (the larger runs, whose efficiency fell
        below the threshold); if there is none, stop + step."""
        if self.cfg["option_cores"]:
            return sorted({int(n) for n in self.cfg["option_cores"] if 2 <= int(n) <= self.ncores})
        ep = (self.meta.get("explore_path") or {}).get(mode) or {}
        stop = ep.get("stop")
        tested = sorted(int(n) for n in (ep.get("tested") or {}))
        counts = [n for n in tested if stop is None or n > int(stop)]
        if not counts:
            nxt = int(stop or self.ref_cores) + int(self.cfg["core_step"])
            counts = [nxt] if nxt <= self.ncores else []
        return counts

    def test_options(self, dt, t1):
        cfg = self.cfg
        thr = float(cfg["efficiency_threshold"])
        tests = [int(v) for v in (cfg["iostyp_tests"] or []) if int(v) != int(self.s0["iostyp"])]
        res = {"counts": {}, "rows": [], "notes": [], "threshold": thr, "iostyp0": self.s0["iostyp"],
               "stop": {m: ((self.meta.get("explore_path") or {}).get(m) or {}).get("stop")
                        for m in cfg["option_modes"]}}
        if not tests:
            return
        if self.shel_kind == "inp" and not self.s0["iostyp_present"]:
            res["notes"].append("the IOSTYP line of ww3_shel.inp was not found: stage skipped")
            self.meta["options"] = res
            self.save_state()
            print(f"[options] {res['notes'][-1]}")
            return
        plan, lay = [], []
        for mode in cfg["option_modes"]:
            if mode not in cfg["modes"]:
                res["notes"].append(f"{mode} is not among the modes: skipped")
                continue
            counts = self.option_counts(mode)
            res["counts"][mode] = counts
            for n in counts:
                plan.append((mode, n))
        print(f"\n=== stage 4: output server type IOSTYP = {', '.join(map(str, tests))} (baseline "
              f"{self.s0['iostyp']}) on " + "; ".join(f"{m.upper()} {', '.join(map(str, c))} cores"
                                                    for m, c in res["counts"].items() if c) + " ===")
        need = [pc for mode, n in plan if self._best_at(mode, n, dt) is None for pc in self.decomps(mode, n)]
        if need:
            self.build_all(need)
            self.run_batch([Job(pc, dt, "explore", r, exclusive=bool(cfg["explore_exclusive"]))
                            for pc in need if self.exe_for(pc) for r in range(int(cfg["repeat"]))],
                           exclusive=bool(cfg["explore_exclusive"]))
        rows_plan = []
        for mode, n in plan:
            b = self._best_at(mode, n, dt)
            if b is None:
                res["notes"].append(f"no successful baseline {mode.upper()} run with {n} cores: variants not run")
                continue
            vs = [{"mode": mode, "np": n, "nx": b["nx"], "ny": b["ny"], "opt": f"IOSTYP={v}"} for v in tests]
            lay += vs
            rows_plan.append((mode, n, b, vs))
        self.run_batch([Job(pc, dt, "options", r, exclusive=bool(cfg["explore_exclusive"]))
                        for pc in lay if self.exe_for(pc) for r in range(int(cfg["repeat"]))],
                       exclusive=bool(cfg["explore_exclusive"]))
        for mode, n, b, vs in rows_plan:
            Eb = t1 / (n * b["wall_s"])
            res["rows"].append({"mode": mode, "n": n, "variant": f"IOSTYP = {self.s0['iostyp']} (baseline)",
                                "layout": layout_txt(b), "cores": n, "wall": b["wall_s"], "E": Eb, "E_base": Eb,
                                "dE": 0.0, "speed": 1.0, "above": Eb > thr, "status": "OK", "baseline": True})
            for pc in vs:
                a = self._best_tag(layout_tag(pc), dt)
                row = {"mode": mode, "n": n, "variant": opt_label(pc), "layout": layout_txt(pc), "cores": n,
                       "E_base": Eb, "baseline": False}
                if a is None:
                    st = [r["status"] for r in self.results if r.get("key", "").startswith(layout_tag(pc) + "_dt")]
                    row.update(status=st[-1] if st else "NOT RUN", wall=None, E=None, dE=None, speed=None,
                               above=False)
                else:
                    E = t1 / (n * a["wall_s"])
                    row.update(status="OK", wall=a["wall_s"], E=E, dE=E - Eb, speed=b["wall_s"] / a["wall_s"],
                               above=E > thr)
                res["rows"].append(row)
                msg = (f"T={_tfmt(row['wall'])}  E={row['E']:.3f} (baseline {Eb:.3f}, {row['dE']:+.3f})"
                       f"{'  > threshold' if row['above'] else ''}") if row["E"] is not None else row["status"]
                print(f"[options] {mode.upper():6s} {n:3d} cores  {row['variant']:12s} {msg}")
        for nt in res["notes"]:
            print(f"[options] {nt}")
        self.meta["options"] = res
        self.save_state()

    # ---------------------------------------------------------------- scheduler, dt search, exploration
    def save_state(self):
        if self.dry:
            return
        st = {k: self.meta.get(k) for k in self.STATE_KEYS if self.meta.get(k) is not None}
        _write_atomic(self.out / "search_state.json", json.dumps(st, indent=1, default=str))

    def load_state(self):
        f = self.out / "search_state.json"
        if not f.exists():
            return
        try:
            st = json.loads(f.read_text())
        except (OSError, ValueError):
            return
        for m in (st.get("explore_path") or {}).values():  # JSON keys are strings
            m["tested"] = {int(n): v for n, v in m.get("tested", {}).items()}
        self.meta.update({k: v for k, v in st.items() if k in self.STATE_KEYS})


    def _record(self, rec):
        for k in FIELDS:  # same keys as a row read back from results.csv
            rec.setdefault(k, None)
        append_result(self.csv, rec)
        self.results.append(rec)
        self.done[rec["key"]] = rec
        if self.live:
            self.live.notify()


    def _alloc(self, free: set, n: int):
        """n free slot indices, preferring a contiguous block (same socket / shared cache)."""
        if len(free) < n:
            return None
        order = sorted(free)
        for s in range(len(order) - n + 1):
            blk = order[s:s + n]
            if blk[-1] - blk[0] == n - 1:
                return blk
        return order[:n]

    def _pruned(self, j: Job):
        if j.exclusive:
            return False
        if self.cfg["blowup_is_global"] and self.global_fail is not None and j.dt >= self.global_fail:
            return True   # rule B: never above (or at) a dt that was unstable
        return (j.stage == "dt-search" and self.dt_floor is not None and j.dt < self.dt_floor)

    def _order(self, j: Job):
        """Queue priority: large_first = most cores and largest dt first; small_first = the reverse
        in cores (smallest dt first, i.e. the longest runs of a core count start first)."""
        return (-j.np, -j.dt, j.rep) if self.large_first else (j.np, j.dt, j.rep)

    def _admit(self, j: Job, recs, pending, running):
        if j.key in self.done:
            recs[j.key] = self.done[j.key]
            return False
        if self._pruned(j):
            print(f"[skip]  {j.key}: dt >= {_fmt_dt(self.global_fail)} s was already unstable")
            return False
        if j.np > self.ncores:
            print(f"[skip]  {j.key}: needs {j.np} cores, only {self.ncores} usable")
            return False
        tag = j.pc["mode"]
        if not self.exe_for(j.pc):
            if tag not in self.compile_fail_recorded:
                self.compile_fail_recorded.add(tag)
                self._record({"key": f"{tag}_compile", "stage": j.stage, **j.pc, "dt": j.dt, "rep": 0,
                              "status": "COMPILE_FAIL", "log": str(self.out / "logs" / f"compile_{tag}.log"),
                              "timestamp": _dt.datetime.now().isoformat(timespec="seconds")})
            return False
        if any(p.key == j.key for p in pending + running):
            return False
        pending.append(j)
        return True


    def _estimate(self, j: Job):
        """Expected wall time of a job from runs already measured, scaled by NTIMES (1/dt) and cores."""
        ok = [r for r in self.results if r["status"] == "OK" and r.get("wall_s")]
        if not ok:
            return None
        same = [r for r in ok if layout_tag(r) == layout_tag(j.pc)]
        if same:
            return statistics.median(r["wall_s"] * r["dt"] / j.dt for r in same)
        pool = [r for r in ok if r["mode"] == j.pc["mode"]] or ok
        r = min(pool, key=lambda r: (abs(math.log(r["np"] / j.np)), -r["dt"]))
        t = r["wall_s"] * r["dt"] / j.dt
        # conservative: linear slow-down with fewer cores, sqrt speed-up with more cores
        return t * (r["np"] / j.np if j.np < r["np"] else (r["np"] / j.np) ** 0.5)

    def _shadow(self, need):
        """Earliest time at which `need` cores will be free, and cores left over at that time."""
        now = time.perf_counter()
        avail = len(self.free)
        if avail >= need:
            return now, avail - need
        for t, n in sorted((self._est_end(r), r.np) for r in self.running):
            avail += n
            if avail >= need:
                return t, avail - need
        return float("inf"), 0

    def _check_walltime(self, j: Job):
        """Refuse to start a run that cannot finish before the Slurm time limit (minus the margin)."""
        if not self.deadline:
            return
        left = self.deadline - time.time() - float(self.cfg["walltime_margin_s"])
        est = j.est if j.est is not None else (self._estimate(j) or 0.0)
        if left <= 0 or est * 1.2 > left:
            raise WallTimeUp(f"not enough wall time left for {j.key} (expected {_tfmt(est)}, "
                             f"{_tfmt(max(left, 0))} available)")

    def _launch(self, j: Job, idx):
        self._check_walltime(j)
        self.free -= set(idx)
        j.slot_idx, j.cpus = idx, [self.slots[i] for i in idx]
        if j.est is None:
            j.est = self._estimate(j)
        self._start(j, self.exe_for(j.pc))
        self.running.append(j)
        busy = sum(r.np for r in self.running)
        for r in self.running:
            r.peers = max(r.peers, len(self.running) - 1)
            r.other_cores = max(r.other_cores, busy - r.np)

    def _pick_backfill(self, pending, batch_keys):
        """A smaller job (later main job or filler of any stage) that fits in the free cores now and
        does not delay the job at the head of the queue (EASY backfilling)."""
        if not self.backfill or not self.free:
            return None, None
        now = time.perf_counter()
        if pending:
            shadow_t, extra = self._shadow(pending[0].np)
        else:  # nothing queued: fill only until the last main run of this batch ends
            ends = [self._est_end(r) for r in self.running if r.key in batch_keys]
            if not ends:
                return None, None
            shadow_t, extra = max(ends), 0
        busy_keys = {r.key for r in self.running} | {p.key for p in pending}
        safety = float(self.cfg["backfill_safety"])
        cands = [(p, pending) for p in pending[1:]] + [(f, self.fillers) for f in self.fillers]
        for j, src in cands:
            if j.np > len(self.free) or j.key in self.done or (src is self.fillers and j.key in busy_keys):
                continue
            if self._pruned(j) or not self.exe_for(j.pc):
                continue
            est = self._estimate(j)
            if est is None:
                continue
            if now + est * safety <= shadow_t or j.np <= extra:
                j.est = est
                return j, src
        return None, None

    def _drop_dead_fillers(self):
        keep = []
        for f in self.fillers:
            if f.key in self.done or self._pruned(f):
                continue
            keep.append(f)
        self.fillers = keep

    def _reap(self, recs, blow_re, on_done):
        """Monitor running jobs; finish those that ended."""
        for j in list(self.running):
            if j.cancelled or j not in self.running:
                continue  # cancelled by a unstable run handled earlier in this same pass
            self._monitor(j, blow_re)
            if j.t_end is None:
                continue
            self.running.remove(j)
            self.free |= set(j.slot_idx)
            rec = self._finish(j)
            recs[j.key] = rec
            if rec["status"] == "UNSTABLE":
                self.global_fail = j.dt if self.global_fail is None else min(self.global_fail, j.dt)
            elif rec["status"] == "OK" and j.stage == "dt-search" and self.dt_phase == "bisect":
                self.dt_floor = max(self.dt_floor or 0.0, j.dt)  # runs below a stable dt are not needed
            for r in list(self.running):  # cancel the runs that the new result made unnecessary
                if self._pruned(r):
                    self._cancel(r)
                    self.running.remove(r)
                    self.free |= set(r.slot_idx)
            on_done(rec)

    def drain(self):
        """Wait for the backfill runs still going on (nothing new is launched)."""
        if not self.running:
            return
        print(f"[sched] waiting for {len(self.running)} backfill run(s) to finish")
        blow_re = re.compile(self.cfg["unstable_regex"], re.I)
        try:
            while self.running:
                self.wake.wait(timeout=self.cfg["poll_s"])
                self.wake.clear()
                self._reap({}, blow_re, lambda rec: None)
        except BaseException:
            self.cancel_all()
            raise

    def cancel_all(self):
        for r in list(self.running):
            self._cancel(r)
        self.running.clear()
        self.free = set(range(self.ncores))

    def run_batch(self, jobs, exclusive=False, on_finish=None):
        """Run jobs packing them on the free cores: small jobs first and simultaneously, the next ones
        as soon as enough cores are released. When the head of the queue does not fit, smaller jobs
        (later ones or fillers from other stages) backfill the idle cores if they do not delay it.
        on_finish(rec, running, pending) may return new jobs, which join the queue (pipelining)."""
        cfg = self.cfg
        if exclusive:
            self.drain()
        recs, pending = {}, []
        for j in jobs:
            self._admit(j, recs, pending, self.running)

        def _more(rec):
            if on_finish is None:
                return
            for nj in on_finish(rec, self.running, pending) or []:
                self._admit(nj, recs, pending, self.running)
            pending.sort(key=self._order)
        _more(None)  # lets the controller react to results already known (resumed benchmark)
        if not pending:
            return recs
        pending.sort(key=self._order)
        batch_keys = set()
        max_jobs = 1 if exclusive else self.max_jobs
        blow_re = re.compile(cfg["unstable_regex"], re.I)
        print(f"[sched] {len(pending)} run(s) queued on {self.ncores} cores, "
              f"{'alone on the machine' if exclusive else 'one at a time' if max_jobs == 1 else f'up to {max_jobs} simultaneous'}"
              + (f", {len(self.fillers)} backfill candidate(s)" if self.fillers and not exclusive else ""))
        try:
            while pending or any(r.key in batch_keys for r in self.running):
                while len(self.running) < max_jobs:
                    while pending and self._pruned(pending[0]):
                        j = pending.pop(0)
                        print(f"[skip]  {j.key}: dt >= {_fmt_dt(self.global_fail)} s was already unstable")
                    if pending:
                        idx = self._alloc(self.free, pending[0].np)
                        if idx is not None:  # the head of the queue fits
                            j = pending.pop(0)
                            batch_keys.add(j.key)
                            self._launch(j, idx)
                            continue
                    if exclusive:
                        break
                    self._drop_dead_fillers()
                    j, src = self._pick_backfill(pending, batch_keys)
                    if j is None:
                        break
                    src.remove(j)
                    if src is pending:
                        batch_keys.add(j.key)
                    print(f"[fill]  {j.key} uses idle cores (expected {_tfmt(j.est)})")
                    self._launch(j, self._alloc(self.free, j.np))
                self.wake.wait(timeout=cfg["poll_s"])
                self.wake.clear()
                self._reap(recs, blow_re, _more)
                if self.deadline and time.time() > self.deadline - 0.5 * self.cfg["walltime_margin_s"]:
                    raise WallTimeUp("Slurm job time limit reached")
        except BaseException:
            self.cancel_all()
            raise
        return recs

    def _cancel(self, j: Job):
        self._kill(j.proc)
        self._close(j)
        j.cancelled = True
        if j.sandbox and j.sandbox.exists():
            shutil.rmtree(j.sandbox, ignore_errors=True)
        print(f"[cancel] {j.key}")


    def _jobs(self, pcs, dts, stage, exclusive=False):
        return [Job(pc, dt, stage, r, exclusive) for pc in pcs for dt in dts
                for r in range(int(self.cfg["repeat"]))]


    def _round_dt(self, x):
        return float(round(x)) if x >= 20 else round(x, 2)

    def _serial_status(self, dt, infer=False):
        sts = [r["status"] for r in self.results if layout_tag(r) == layout_tag(SERIAL) and r["dt"] == dt]
        if "UNSTABLE" in sts:
            return "UNSTABLE"
        if "OK" in sts:
            return "OK"
        if self.global_fail is not None and dt >= self.global_fail:
            return "UNSTABLE"  # a smaller or equal dt was already unstable
        if sts:
            return sts[-1]
        if infer and any(r["status"] == "OK" and r["dt"] > dt for r in self.results
                         if layout_tag(r) == layout_tag(SERIAL)):
            return "OK (inferred)"  # below a stable dt: stable (monotonicity), the run was not needed
        return None

    def _serial_batch(self, dts, stage):
        todo = sorted({d for d in dts if self._serial_status(d) is None})
        if todo:
            print(f"[dt] running {len(todo)} serial run(s) at once: "
                  f"{', '.join(_fmt_dt(d) for d in todo)} s")
            self.run_batch([Job(dict(SERIAL), d, stage, 0) for d in todo])
        self.dt_runs += len(todo)

    def _bisect_nodes(self, lo, hi, count, depth, tol):
        """Speculative decision tree of the halving phase: the next midpoint and, below it, the
        midpoints that would follow a unstable run (lower half) or a stable run (upper half)."""
        out = []

        def rec(lo, hi, count, d):
            m = self._round_dt((lo + hi) / 2.0)
            if d == 0 or not (lo < m < hi) or (hi - lo) / hi <= tol:
                return
            out.append(m)
            if count + 1 < 2:          # a second consecutive unstable run ends the search
                rec(lo, m, count + 1, d - 1)
            rec(m, hi, 0, d - 1)
        rec(lo, hi, count, depth)
        return out

    def dt_search(self):
        """Serial (1 core) time-step search.
        Up:     dt_ref, doubled while stable. Rule B: never above a dt that was unstable.
        Down:   if dt_ref blows up, dt is halved until a dt is stable AND its half is stable (rule A:
                never decrease further than that).
        Bisect: then the next dt is the midpoint between the last stable dt and the last unstable run;
                stop after two unstable runs in a row (or interval < dt_tol, or max_dt_runs).
        Several serial runs run at once, but in "strict" mode only runs that are needed whatever the
        pending results are: doubling one at a time, going down d and d/2 together, bisecting the
        midpoint together with the next lower midpoint (cancelled if the midpoint is stable)."""
        cfg = self.cfg
        strict = cfg["dt_speculation"] != "aggressive"
        dt0 = float(cfg["dt_ref"] or self.g0["DTMAX"])
        dt_cap = float(cfg["sim_days"]) * DAY / max(1, int(cfg["min_steps"]))
        if dt0 > dt_cap:
            print(f"[dt] dt_ref {_fmt_dt(dt0)} s leaves fewer than {cfg['min_steps']} steps: using {_fmt_dt(dt_cap)} s")
            dt0 = dt_cap
        k = max(1, min(self.ncores, self.max_jobs))
        tol = float(cfg["dt_tol"])
        maxr = int(cfg["max_dt_runs"])
        path, self.dt_runs = [], 0
        self.dt_floor, self.dt_phase = None, "up"
        st = self._serial_status

        def log(dt, s, phase):
            path.append({"dt": dt, "status": s, "phase": phase})
            print(f"[dt] {phase:8s} dt = {_fmt_dt(dt):>8s} s -> {s}")

        def need(cands):
            if self.dt_runs >= maxr:
                return False
            self._serial_batch(cands, "dt-search")
            return True

        lo = hi = None
        # ---- up: dt_ref, then doubling while stable
        dt = dt0
        while True:
            if st(dt) is None:
                ahead = [dt] if strict else [dt * 2 ** i for i in range(k) if dt * 2 ** i <= dt_cap]
                if not need(ahead) or st(dt) is None:
                    print("[dt] search stopped (max_dt_runs reached or run not completed)")
                    break
            s = st(dt)
            log(dt, s, "up")
            if s == "OK":
                lo = dt
                if dt * 2 > dt_cap:
                    print(f"[dt] doubling to {_fmt_dt(dt * 2)} s would leave fewer than {cfg['min_steps']} steps: stop")
                    break
                dt *= 2
                continue
            if s == "UNSTABLE":
                hi = dt
            else:
                print(f"[dt] run ended with {s} (not a unstable run): search stopped")
            break
        # ---- down: dt_ref unstable -> halve until d stable and d/2 stable (rule A)
        if lo is None and hi is not None:
            self.dt_phase = "down"
            d = hi / 2.0
            while True:
                if st(d) is None or st(d / 2.0) is None:
                    if not need([d, d / 2.0] if strict else [d / 2 ** i for i in range(min(k, 2))]):
                        print(f"[dt] max_dt_runs ({maxr}) reached")
                        break
                s = st(d)
                if s is None:
                    print("[dt] run not completed: search stopped")
                    break
                log(d, s, "down")
                if s == "UNSTABLE":
                    hi, d = d, d / 2.0
                    continue
                if s != "OK":
                    print(f"[dt] run ended with {s} (not a unstable run): search stopped")
                    break
                sh = st(d / 2.0)
                if sh is not None:
                    log(d / 2.0, sh, "down")
                lo = d
                if sh != "OK":
                    print(f"[dt] warning: {_fmt_dt(d)} s stable but {_fmt_dt(d / 2)} s ended with {sh}")
                break
        # ---- bisect between [lo stable, hi unstable run]; stop after two unstable runs in a row
        if lo is not None and hi is not None:
            self.dt_phase, self.dt_floor = "bisect", lo
            depth = max(1, int(math.floor(math.log2(k + 1))))
            count, reason = 0, None
            while reason is None:
                m = self._round_dt((lo + hi) / 2.0)
                if not (lo < m < hi) or (hi - lo) / hi <= tol:
                    reason = f"interval below dt_tol ({tol:g})"
                    break
                if st(m, True) is None:
                    if strict:
                        nodes = [m]
                        c = self._round_dt((lo + m) / 2.0)
                        if count == 0 and lo < c < m and (m - lo) / m > tol:
                            nodes.append(c)    # needed if m blows up; cancelled if m is stable
                    else:
                        nodes = self._bisect_nodes(lo, hi, count, depth, tol)
                    if not need(nodes):
                        reason = f"max_dt_runs ({maxr}) reached"
                        break
                    if st(m, True) is None:
                        reason = "run could not be completed"
                        break
                s = st(m, True)
                log(m, s, "bisect")
                s = "OK" if s == "OK (inferred)" else s
                if s == "UNSTABLE":
                    hi, count = m, count + 1
                    if count >= 2:
                        reason = "two unstable runs in a row"
                elif s == "OK":
                    lo, count = m, 0
                    self.dt_floor = max(self.dt_floor or 0.0, lo)
                else:
                    reason = f"run ended with {s}"
            print(f"[dt] search finished ({reason}): stable {_fmt_dt(lo)} s, unstable {_fmt_dt(hi)} s")
        self.dt_phase, self.dt_floor = None, None
        self.meta["dt_path"] = path
        self.save_state()
        return lo, hi


    def _best_at(self, mode, n, dt):
        pts = [a for a in aggregate(self.results) if a["mode"] == mode and a["np"] == n and a["dt"] == dt
               and a["status"] == "OK" and a["wall_s"]]
        return min(pts, key=lambda a: a["wall_s"]) if pts else None

    def explore_cores(self, dt, t1):
        """Per mode: start at ref_cores, E(n) = T(1)/(n T(n)) with the best decomposition.
        Stop at the first core count with E > threshold (that configuration is the result of the
        mode); otherwise n - core_step, down to 2 cores."""
        cfg = self.cfg
        thr, step = float(cfg["efficiency_threshold"]), int(cfg["core_step"])
        n0 = min(self.ref_cores, self.ncores)
        st = {m: {"n": n0, "tested": {}, "active": True, "why": "", "stop": None}
              for m in cfg["modes"]}
        rnd = 0

        def lower(s, why):
            nxt = s["n"] - step
            if nxt < 2:
                s["active"], s["why"] = False, f"{why}; no core count >= 2 left with E > {thr:g}"
            else:
                s["n"] = nxt
        while any(s["active"] for s in st.values()):
            rnd += 1
            lay = []
            for mode, s in st.items():
                while s["active"]:
                    d = self.decomps(mode, s["n"])
                    if d:
                        lay += d
                        break
                    print(f"[cores] {mode.upper()}: no valid decomposition for {s['n']} cores, skipped")
                    lower(s, f"no valid decomposition for {s['n']} cores")
            if not lay:
                break
            print(f"\n--- exploration round {rnd}: "
                  + ", ".join(f"{m.upper()} {s['n']} cores" for m, s in st.items() if s["active"]) + " ---")
            self.build_all(lay)
            self.run_batch([Job(pc, dt, "explore", r, exclusive=bool(cfg["explore_exclusive"]))
                            for pc in lay if self.exe_for(pc) for r in range(int(cfg["repeat"]))],
                           exclusive=bool(cfg["explore_exclusive"]))
            for mode, s in st.items():
                if not s["active"]:
                    continue
                n = s["n"]
                b = self._best_at(mode, n, dt)
                if b is None:
                    print(f"[cores] {mode.upper():6s} n={n:<3d} no successful run")
                    lower(s, f"no successful run with {n} cores")
                    continue
                E = t1 / (n * b["wall_s"])
                s["tested"][n] = {"E": E, "layout": layout_txt(b), "wall": b["wall_s"]}
                if E > thr:
                    s["active"], s["stop"] = False, n
                    s["why"] = f"E = {E:.3f} > {thr:g} at {n} cores"
                    print(f"[cores] {mode.upper():6s} n={n:<3d} best {layout_txt(b)}  T={_tfmt(b['wall_s'])}  "
                          f"E={E:.3f} > {thr:g} -> stop")
                else:
                    print(f"[cores] {mode.upper():6s} n={n:<3d} best {layout_txt(b)}  T={_tfmt(b['wall_s'])}  "
                          f"E={E:.3f} <= {thr:g} -> next {n - step}")
                    lower(s, f"E <= {thr:g} at {n} cores")
        self.meta["explore_path"] = {m: {"tested": s["tested"], "why": s["why"], "stop": s["stop"]}
                                     for m, s in st.items()}
        self.save_state()
        for m, s in st.items():
            print(f"[cores] {m.upper()}: stop ({s['why']}); "
                  + (f"configuration found: {s['stop']} cores, {s['tested'][s['stop']]['layout']}"
                     if s["stop"] else f"no core count with E > {thr:g}"))


    def go(self):
        self.plan()
        self.build_all([dict(SERIAL)])
        if not self.builds.get("serial"):
            print("[error] the serial ww3_shel is not available (build failed or executables.serial missing)")
            return
        if self.grid_exe is None:
            print("[error] ww3_grid not found (serial build or executables.grid): it is needed to write "
                  "mod_def.ww3 for every time step")
            return
        print("\n=== stage 1: time-step search, serial build (1 core, SHRD), several runs at once ===")
        lo, hi = self.dt_search()
        if lo is None:
            print("[error] no stable dt found; stopping")
            return
        dt_opt = hour_divisor_floor(lo) if self.cfg["dt_hour_divisor"] else lo
        self.meta["dt_stable_max"], self.meta["dt_opt"] = lo, dt_opt
        self.save_state()
        self.dt_opt = dt_opt
        if dt_opt != lo:
            print(f"[stage] largest stable dt = {_fmt_dt(lo)} s -> optimal dt rounded down to {_fmt_dt(dt_opt)} s "
                  f"(3600/{_fmt_dt(dt_opt)} = {3600 / dt_opt:g} steps per hour)")
        else:
            print(f"[stage] optimal dt = {_fmt_dt(dt_opt)} s")
        key = run_key(SERIAL, dt_opt, 0)
        r = self.done.get(key)
        if r is None:
            print(f"\n=== serial reference T(1) at dt = {_fmt_dt(dt_opt)} s, alone on the machine ===")
            self.run_batch([Job(dict(SERIAL), dt_opt, "serial-ref", 0)], exclusive=True)
            r = self.done.get(key)
            if r is None or r["status"] != "OK":
                print(f"[warn] the serial run at {_fmt_dt(dt_opt)} s did not end OK: using {_fmt_dt(lo)} s")
                self.dt_opt = dt_opt = lo
                self.meta["dt_opt"] = lo
                key = run_key(SERIAL, dt_opt, 0)
                r = self.done.get(key)
        if self.cfg["serial_ref_exclusive"] and r and (r.get("peers") or 0) > 0:
            print(f"\n=== serial reference T(1) at dt = {_fmt_dt(dt_opt)} s, alone on the machine ===")
            self.run_batch([Job(dict(SERIAL), dt_opt, "serial-ref", 0, exclusive=True)], exclusive=True)
        ser = self._best_at("serial", 1, dt_opt)
        if ser is None:
            print("[error] no serial reference time; stopping")
            return
        t1 = ser["wall_s"]
        print(f"[stage] T(1) = {_tfmt(t1)}" + ("" if ser["clean"] else " (measured sharing the machine)"))
        print(f"\n=== stage 2: cores exploration from {self.ref_cores} cores "
              f"(stop at the first E > {self.cfg['efficiency_threshold']:g}, otherwise "
              f"-{self.cfg['core_step']} cores) ===")
        self.explore_cores(dt_opt, t1)
        self.drain()
        if self.cfg["efficiency_exclusive"] and self.max_jobs > 1:
            at = [a for a in aggregate(self.results) if a["dt"] == dt_opt and a["status"] == "OK"]
            need = [{k: a[k] for k in ("mode", "np", "nx", "ny")}
                    for pts in efficiency_points(at).values() for a in pts if not a["clean"]]
            if need:
                print(f"\n=== stage 3: re-timing {len(need)} efficiency point(s) alone on the machine ===")
                self.run_batch([Job(pc, dt_opt, "exclusive", r, exclusive=True) for pc in need
                                for r in range(int(self.cfg["repeat"]))], exclusive=True)
        self.test_options(dt_opt, t1)
        self.drain()

    def plan(self):
        t = self.topo
        g = self.g0
        print(f"[plan] machine: {self.meta['machine'].get('cpu')}  ->  {self.ncores} cores usable "
              f"(physical={t.get('physical', '?')}, hyperthreads={t.get('hyperthreads', '?')}, "
              f"sockets={t.get('sockets', '?')}); CPU ids {_cpu_ranges(self.slots)}")
        print(f"[plan] {self.grid_name}: grid '{g.get('name')}' {g.get('type')} "
              + (f"{g['nx']} x {g['ny']}" if g.get("nx") else "")
              + (f", spectrum {g.get('nk')} frequencies x {g.get('nth')} directions, f1 = {g.get('f1')} Hz"
                 if g.get("nk") else ""))
        print("[plan] time steps DTMAX / DTXY / DTKTH / DTMIN = "
              + " / ".join(_fmt_num(g[k]) for k in TS_KEYS) + f" s ({self.cfg['timestep_mode']}; "
              f"DTMIN {self.cfg['dtmin_mode']})")
        print(f"[plan] {self.shel_name}: start {self.s0['start']}, each run {_days(self.cfg['sim_days'])}; "
              f"IOSTYP = {self.s0['iostyp']}")
        if self.cfl:
            c = self.cfl
            print(f"[plan] propagation CFL = DTXY x {max(c['fx'], c['fy']):.3g} 1/s (cg(f1) = {c['cg_max']:.1f} m/s, "
                  f"dx_min = {c['dx_min'] / 1e3:.2f} km, dy = {c['dy_min'] / 1e3:.2f} km; {c['source']}); "
                  f"limit {self.cfg['cfl_limit']:g} ({self.cfg['cfl_rule']})")
        else:
            print("[plan] propagation CFL not computed (only RECT grids with a readable spectrum/grid definition)")
        sw = self.switch_text
        print(f"[plan] switch file: {self.switch_path}" + (f" -> parallel switches "
              f"{' '.join(switch_parallel_tokens(sw, self.cfg)) or 'none'}" if sw else " (NOT FOUND)"))
        for m in ["serial"] + list(self.cfg["modes"]):
            pre = self.cfg["executables"].get(m)
            print(f"        {m:6s} build: " + (f"given executable {pre}" if pre else
                                               f"switch + {' '.join(self.cfg['mode_switches'][m])}"))
        dtr = float(self.cfg["dt_ref"] or self.g0["DTMAX"])
        print(f"[plan] stage 1: serial dt search from DTMAX = {_fmt_dt(dtr)} s (x2 while stable, then halving the "
              f"interval until two unstable runs in a row), up to {min(self.ncores, self.max_jobs)} runs at once")
        print(f"[plan] stage 2: {', '.join(m.upper() for m in self.cfg['modes'])} from {self.ref_cores} cores, "
              f"stop at the first E > {self.cfg['efficiency_threshold']:g}, otherwise -{self.cfg['core_step']}; "
              f"pinning: {'taskset' if self.taskset else 'none (taskset not found)'}")
        for m in self.cfg["modes"]:
            d = self.decomps(m, self.ref_cores)
            print(f"        {m.upper():6s} {self.ref_cores} cores: " + "  ".join(layout_txt(p) for p in d))
        tests = [v for v in (self.cfg["iostyp_tests"] or []) if int(v) != int(self.s0["iostyp"])]
        if tests:
            print(f"[plan] stage 4: IOSTYP = {', '.join(map(str, tests))} (baseline {self.s0['iostyp']}) on the "
                  f"{', '.join(m.upper() for m in self.cfg['option_modes'])} runs with more cores than the stop point")
        if self.launcher == "slurm":
            left = (self.deadline - time.time()) if self.deadline else None
            print(f"[plan] launcher: Slurm job {os.environ.get('SLURM_JOB_ID', '?')} (srun job steps, "
                  f"'{self.cfg['slurm_step_flags']}'); wall time left: "
                  f"{_tfmt(left) if left is not None else 'unknown'}; runs stop "
                  f"{_tfmt(self.cfg['walltime_margin_s'])} before the limit")
        else:
            print("[plan] launcher: local (taskset / mpirun)")
        for mode in ["serial"] + list(self.cfg["modes"]):
            pcs = self.decomps(mode, self.ref_cores) if mode != "serial" else [dict(SERIAL)]
            if not pcs:
                continue
            j = Job(pcs[0], self.g0["DTMAX"], "plan")
            j.cpus = self.slots[:j.np]
            cmd, env = self._command(j, Path("<ww3_shel>"))
            extra = "  OMP_NUM_THREADS=" + env.get("OMP_NUM_THREADS", "") if mode in ("openmp", "hybrid") else ""
            print(f"        {mode:6s} command: {cmd}{extra}")
        return self.layouts()

    def dry_run(self):
        self.plan()
        import difflib
        dtr = float(self.cfg["dt_ref"] or self.g0["DTMAX"])
        ts = timesteps_for(dtr * 2, self.g0, self.cfg)
        gtxt = set_grid_timesteps(self.pristine["grid"], self.grid_kind, ts)
        stop = self.s0["start"] + _dt.timedelta(days=float(self.cfg["sim_days"]))
        stxt, _ = set_shel_input(self.pristine["shel"], self.shel_kind, stop)
        tests = [v for v in (self.cfg["iostyp_tests"] or []) if int(v) != int(self.s0["iostyp"])]
        for name, a, b in ((f"{self.grid_name} (DTMAX = {_fmt_dt(dtr * 2)} s)", self.pristine["grid"], gtxt),
                           (f"{self.shel_name}", self.pristine["shel"], stxt)):
            print(f"\n--- edits in {name} ---")
            sys.stdout.writelines(difflib.unified_diff(a.splitlines(True), b.splitlines(True), n=0))
        if tests:
            try:
                s2, _ = set_shel_input(self.pristine["shel"], self.shel_kind, stop, int(tests[0]))
                print(f"\n--- edits in {self.shel_name} for the stage-4 variant IOSTYP = {tests[0]} ---")
                sys.stdout.writelines(difflib.unified_diff(self.pristine["shel"].splitlines(True),
                                                           s2.splitlines(True), n=0))
            except RuntimeError as e:
                print(f"[warn] {e}")
        if self.switch_text:
            for m in ["serial"] + list(self.cfg["modes"]):
                print(f"\n--- switch for {m}: {switch_for_mode(self.switch_text, m, self.cfg).strip()}")
        print("\n[run dir] files of run_dir in every run directory (copied < "
              f"{self.cfg['copy_below_mb']} MB, otherwise linked); outputs left out:")
        lim = float(self.cfg["copy_below_mb"]) * 1e6
        for p in sorted(self.run_dir.iterdir()):
            if p.name.startswith("."):
                continue
            if is_output_name(p.name, self.cfg):
                how = "output: not linked (written by WW3)"
            elif p.name in (self.grid_name, self.shel_name):
                how = "edited copy"
            elif p.is_file() and not p.is_symlink() and p.stat().st_size < lim:
                how = "copied"
            else:
                how = "symlinked"
            print(f"          {p.name:28s} {how}")
        if self.cfl:
            c = self.cfl
            print(f"\n[cfl] cg(f1={c['f1']:g} Hz) = {c['cg_max']:.1f} m/s, dx_min = {c['dx_min']:.0f} m, "
                  f"dy_min = {c['dy_min']:.0f} m ({c['source']})")
            for e in range(-3, 5):
                dt = dtr * 2.0 ** e
                t = timesteps_for(dt, self.g0, self.cfg)
                cf = self.predicted_cfl(t)
                print(f"      DTMAX={_fmt_dt(dt):>8s}  DTXY={_fmt_num(t['DTXY']):>9s}  DTKTH={_fmt_num(t['DTKTH']):>9s}"
                      f"  DTMIN={_fmt_num(t['DTMIN']):>7s}  CFL_xy={cf['cfl_xy']:.3f}"
                      + ("  > limit" if cf["cfl_xy"] > float(self.cfg["cfl_limit"]) else ""))


def _cpu_ranges(cpus):
    """[0,1,2,3,8] -> '0-3,8'"""
    cpus = sorted(cpus)
    out, s = [], 0
    for i in range(1, len(cpus) + 1):
        if i == len(cpus) or cpus[i] != cpus[i - 1] + 1:
            out.append(f"{cpus[s]}" if s == i - 1 else f"{cpus[s]}-{cpus[i - 1]}")
            s = i
    return ",".join(out)

# ----------------------------------------------------------------------------------------------
# Analysis, figures and report
# ----------------------------------------------------------------------------------------------
def aggregate(results, options=False):
    """One entry per (layout, dt): status and median wall time. Runs of the stage-4 IOSTYP variants are
    left out unless options=True."""
    groups = {}
    for r in results:
        opt = r.get("opt") or ""
        if (opt and not options) or r.get("dt") is None:   # stage-4 variants; failed builds
            continue
        k = (r["mode"], int(r["np"]), int(r["nx"]), int(r["ny"]), float(r["dt"]), opt)
        groups.setdefault(k, []).append(r)
    agg = []
    for (mode, n, nx, ny, dt, opt), rs in groups.items():
        sts = [r["status"] for r in rs]
        status = "UNSTABLE" if "UNSTABLE" in sts else "OK" if "OK" in sts else sts[-1]
        ok_all = [r for r in rs if r["status"] == "OK" and r.get("wall_s") is not None]
        clean = [r for r in ok_all if r.get("exclusive") or not (r.get("peers") or 0)]
        conc = [r for r in ok_all if r not in clean]
        ok = clean or ok_all  # a run measured alone on the machine is preferred
        wall = statistics.median([r["wall_s"] for r in ok]) if ok else None
        first = (ok or rs)[0]
        sd = max([r["sim_days"] or 0 for r in rs] or [0])
        agg.append({"mode": mode, "np": n, "nx": nx, "ny": ny, "dt": dt, "status": status,
                    "wall_s": wall, "nrep": len(ok), "spread": (max(r["wall_s"] for r in ok) -
                                                                min(r["wall_s"] for r in ok)) if len(ok) > 1 else 0.0,
                    "sim_days": sd, "dtxy": first.get("dtxy"), "dtkth": first.get("dtkth"),
                    "dtmin": first.get("dtmin"), "cfl_x": first.get("cfl_x"), "cfl_y": first.get("cfl_y"),
                    "cfl_xy": first.get("cfl_xy"),
                    "not_run": all((r.get("wall_s") is None) for r in rs),
                    "days_per_hour": (sd / (wall / 3600.0)) if wall else None,
                    "clean": bool(clean), "peers": max([r.get("peers") or 0 for r in ok], default=0),
                    "wall_clean": statistics.median([r["wall_s"] for r in clean]) if clean else None,
                    "wall_conc": statistics.median([r["wall_s"] for r in conc]) if conc else None,
                    "opt": opt, "cores": n,
                    "tag": layout_tag({"mode": mode, "np": n, "nx": nx, "ny": ny, "opt": opt})})
    return agg


def stability_summary(agg):
    by_dt = {}
    for a in agg:
        by_dt.setdefault(a["dt"], []).append(a)
    rows = []
    for dt in sorted(by_dt):
        g = by_dt[dt]
        sts = {a["status"] for a in g}
        status = "UNSTABLE" if "UNSTABLE" in sts else "OK" if "OK" in sts else "/".join(sorted(sts))
        pick = lambda k: max([a[k] for a in g if a.get(k) is not None], default=None)  # noqa: E731
        rows.append({"dt": dt, "status": status, "cfl_x": pick("cfl_x"), "cfl_y": pick("cfl_y"),
                     "cfl_xy": pick("cfl_xy"), "dtxy": pick("dtxy"), "dtkth": pick("dtkth"), "dtmin": pick("dtmin"),
                     "not_run": all(a["not_run"] for a in g),
                     "n": len(g), "best_wall": min([a["wall_s"] for a in g if a["wall_s"]], default=None)})
    first_fail = min([r["dt"] for r in rows if r["status"] == "UNSTABLE"], default=None)
    stable = [r for r in rows if r["status"] == "OK" and (first_fail is None or r["dt"] < first_fail)]
    return rows, (stable[-1] if stable else None), \
        (next(r for r in rows if r["dt"] == first_fail) if first_fail else None)


def hour_divisor_floor(dt):
    """Largest integer dt <= the given one with 3600/dt an integer (whole number of steps per hour)."""
    if dt is None or dt < 1:
        return dt
    return float(max(d for d in range(1, 3601) if 3600 % d == 0 and d <= dt))


def _days(d):
    return f"{d:g} day" + ("" if float(d) == 1.0 else "s")


def _tfmt(sec):
    if sec is None:
        return "–"
    if sec < 120:
        return f"{sec:.1f} s"
    if sec < 7200:
        return f"{sec / 60:.1f} min"
    return f"{sec / 3600:.2f} h"


def _tunit(values):
    m = max([v for v in values if v] or [1])
    return (1.0, "s") if m < 300 else (60.0, "min") if m < 3 * 3600 else (3600.0, "h")


def _short_notes(notes, n=70):
    """Notes for the report table: rounding remarks dropped (they stay in results.csv), truncated."""
    keep = [x.strip() for x in str(notes or "").split(";")
            if x.strip() and not re.search(r"does not divide|not an exact multiple|simulates [\d.]+ days", x)]
    t = "; ".join(keep)
    return t if len(t) <= n else t[:n - 1] + "…"


def _measured(a):
    if not a.get("wall_s"):
        return "–"
    return "alone" if a["clean"] else f"with {a['peers']} concurrent"


def _f(x, fmt="{:.3f}", na="–"):
    return na if x is None else fmt.format(x)


COLORS = {"openmp": "#2a6fdb", "mpi": "#d9572b", "hybrid": "#2a9d55", "serial": "#343a40"}
STYLE = {"openmp": "-", "mpi": "--", "hybrid": "-.", "serial": "-"}


def make_figures(agg, out: Path, dt_opt):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np

    colors = COLORS
    figs = []
    U, un = _tunit([a["wall_s"] for a in agg])

    fig, axs = plt.subplots(2, 2, figsize=(13, 9.5))
    # (a) wall time vs dt
    ax = axs[0, 0]
    tags = sorted({a["tag"] for a in agg})
    multi = [t for t in tags if len({a["dt"] for a in agg if a["tag"] == t}) > 1]
    for t in multi:
        pts = sorted([a for a in agg if a["tag"] == t], key=lambda a: a["dt"])
        ok = [a for a in pts if a["status"] == "OK"]
        mode = pts[0]["mode"]
        ln, = ax.plot([a["dt"] for a in ok], [a["wall_s"] / U for a in ok], "o-",
                      color=colors[mode], alpha=0.85, label=t)
        ln.set_linestyle(STYLE.get(mode, "-"))
        bu = [a["dt"] for a in pts if a["status"] == "UNSTABLE"]
        if bu:
            ax.scatter(bu, [0.97] * len(bu), marker="X", s=110, color="crimson", zorder=5,
                       transform=ax.get_xaxis_transform())
    ax.scatter([], [], marker="X", s=80, color="crimson", label="unstable")
    xs = [a["dt"] for a in agg if a["tag"] in multi]
    if xs and max(xs) / min(xs) > 8:  # wide dt range (doubling search): log2 axis
        ax.set_xscale("log", base=2)
        ax.set_xlim(min(xs) / 1.3, max(xs) * 1.3)
    elif xs:
        pad = 0.05 * (max(xs) - min(xs) or max(xs))
        ax.set_xlim(min(xs) - pad, max(xs) + pad)
    ax.set_xlabel("Global time step DTMAX [s]")
    ax.set_ylabel(f"Wall-clock time [{un}]")
    ax.set_title("(a) Run time vs. time step")
    ax.grid(alpha=0.3)
    if ax.get_legend_handles_labels()[0]:
        ax.legend(fontsize=8)

    # (b) wall time vs cores at dt_opt (best layout per np and mode)
    ax = axs[0, 1]
    at = [a for a in agg if a["dt"] == dt_opt and a["status"] == "OK"]
    base = None
    best_np = {}
    for a in at:
        k = (a["mode"], a["np"])
        if k not in best_np or a["wall_s"] < best_np[k]["wall_s"]:
            best_np[k] = a
    if best_np:
        n_min = min(n for _, n in best_np)
        base = min(a["wall_s"] * a["np"] / n_min for (m, n), a in best_np.items() if n == n_min)
    ser = [best_np[("serial", 1)]] if ("serial", 1) in best_np else []
    for mode in ("openmp", "mpi", "hybrid"):
        pts = sorted([a for (m, _), a in best_np.items() if m == mode], key=lambda a: a["np"])
        pts = ser + [a for a in pts if not (ser and a["np"] == 1)] if pts else []
        if pts:
            ax.plot([a["np"] for a in pts], [a["wall_s"] / U for a in pts], "o-", color=colors[mode],
                    label=f"{mode.upper()} (best layout{', 1 core = serial' if ser else ''})")
            for a in pts:
                if a["mode"] == "serial" and mode != "openmp":
                    continue
                ax.annotate("serial" if a["mode"] == "serial" else
                            (f"{a['nx']}x{a['ny']}" if a["mode"] == "hybrid" else ""),
                            (a["np"], a["wall_s"] / U), fontsize=7,
                            color=colors[mode], textcoords="offset points",
                            xytext=(5, 5) if mode == "openmp" else (5, -11))
    if best_np:
        ns = sorted({n for _, n in best_np})
        n_min = ns[0]
        ax.plot(ns, [base * n_min / n / U for n in ns], "k:", label="ideal scaling")
        ax.set_xscale("log", base=2)
        ax.set_yscale("log")
        ax.set_xticks(ns)
        ax.set_xticklabels([str(n) for n in ns])
    ax.set_xlabel("Cores")
    ax.set_ylabel(f"Wall-clock time [{un}]")
    ax.set_title(f"(b) Scaling at dt = {_fmt_dt(dt_opt) if dt_opt else '?'} s")
    ax.grid(alpha=0.3, which="both")
    if ax.get_legend_handles_labels()[0]:
        ax.legend(fontsize=8)

    # (c) parallel efficiency
    ax = axs[1, 0]
    for mode in ("openmp", "mpi", "hybrid"):
        pts = sorted([a for (m, _), a in best_np.items() if m == mode], key=lambda a: a["np"])
        pts = ser + [a for a in pts if not (ser and a["np"] == 1)] if pts else []
        if pts and base:
            n_min = min(n for _, n in best_np)
            sp = [base / a["wall_s"] for a in pts]
            eff = [s / (a["np"] / n_min) * 100 for s, a in zip(sp, pts)]
            ax.plot([a["np"] for a in pts], eff, "o-", color=colors[mode], label=mode.upper())
    ax.axhline(100, color="k", ls=":", lw=1)
    ax.set_xscale("log", base=2)
    if best_np:
        ns = sorted({n for _, n in best_np})
        ax.set_xticks(ns)
        ax.set_xticklabels([str(n) for n in ns])
    ax.set_ylim(0, 120)
    ax.set_xlabel("Cores")
    ax.set_ylabel("Parallel efficiency [%]")
    ax.set_title("(c) Efficiency relative to the smallest core count")
    ax.grid(alpha=0.3)
    if ax.get_legend_handles_labels()[0]:
        ax.legend(fontsize=8)

    # (d) all layouts at dt_opt
    ax = axs[1, 1]
    at_s = sorted(at, key=lambda a: a["wall_s"])[:30]
    y = np.arange(len(at_s))
    ax.barh(y, [a["wall_s"] / U for a in at_s], color=[colors[a["mode"]] for a in at_s])
    ax.set_yticks(y)
    ax.set_yticklabels([a["tag"] for a in at_s], fontsize=7)
    ax.invert_yaxis()
    ax.set_xlabel(f"Wall-clock time [{un}]")
    ax.set_title(f"(d) All layouts at dt = {_fmt_dt(dt_opt) if dt_opt else '?'} s (fastest first)")
    ax.grid(alpha=0.3, axis="x")
    fig.suptitle("WAVEWATCH III benchmark: time to simulate the target period", fontsize=13)
    fig.tight_layout()
    p = out / "benchmark_summary.png"
    _save_fig(fig, p)
    plt.close(fig)
    figs.append(p)

    # CFL figure
    rows, last_ok, first_fail = stability_summary(agg)
    if any(r["cfl_xy"] is not None for r in rows):
        fig, ax = plt.subplots(figsize=(8, 5))
        for key, lab, mk in (("cfl_x", "x: cg(f1)·DTXY/dx_min", "o"), ("cfl_y", "y: cg(f1)·DTXY/dy", "s")):
            pts = [r for r in rows if r[key] is not None]
            if pts:
                ax.plot([r["dt"] for r in pts], [r[key] for r in pts], marker=mk, label=lab)
        bu = [r["dt"] for r in rows if r["status"] == "UNSTABLE"]
        if bu:
            ax.scatter(bu, [0.03] * len(bu), marker="X", s=90, color="crimson", zorder=5,
                       transform=ax.get_xaxis_transform(), label="unstable")
        if first_fail:
            ax.axvline(first_fail["dt"], color="crimson", ls="--", label="first unstable dt")
        if last_ok:
            ax.axvline(last_ok["dt"], color="green", ls="--", label="largest stable dt")
        ax.axhline(1.0, color="k", ls=":", lw=1, label="CFL = 1")
        dts_ = [r["dt"] for r in rows]
        if dts_ and max(dts_) / min(dts_) > 8:
            ax.set_xscale("log", base=2)
            ax.set_yscale("log")
        ax.set_xlabel("DTMAX [s] (DTXY scales with it)")
        ax.set_ylabel("Propagation Courant number")
        ax.set_title("Spatial propagation CFL of the lowest frequency vs. time step")
        ax.grid(alpha=0.3)
        if ax.get_legend_handles_labels()[0]:
            ax.legend(fontsize=8)
        fig.tight_layout()
        p = out / "cfl_vs_dt.png"
        _save_fig(fig, p)
        plt.close(fig)
        figs.append(p)
    return figs


def _save_fig(fig, p: Path):
    """Write the figure to a temporary file and rename it, so a viewer never sees a half-written PNG."""
    tmp = p.with_name(p.stem + ".tmp" + p.suffix)
    fig.savefig(tmp, dpi=130)
    os.replace(tmp, p)


def _write_atomic(p: Path, text: str):
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(text)
    os.replace(tmp, p)


class LiveReport:
    """Rebuilds figures and report in a background thread after every finished simulation
    (several finishes close together are coalesced into one update)."""

    def __init__(self, bench):
        self.b = bench
        self.ev, self.stop_ev = threading.Event(), threading.Event()
        self.t = threading.Thread(target=self._loop, daemon=True)
        self.n = 0

    def start(self):
        self.t.start()
        return self

    def notify(self):
        self.ev.set()

    def _loop(self):
        while not self.stop_ev.is_set():
            if not self.ev.wait(timeout=0.5):
                continue
            self.ev.clear()
            try:
                write_report(list(self.b.results), self.b.cfg, self.b.meta, Path(self.b.cfg["output_dir"]),
                             partial=True)
                self.n += 1
            except Exception as e:  # noqa: BLE001
                print(f"[warn] live report update failed: {e}")

    def stop(self):
        self.stop_ev.set()
        self.t.join(timeout=300)


def _parse_ranges(s):
    out = []
    for part in str(s or "").split(","):
        if "-" in part:
            a, b = part.split("-")
            out += list(range(int(a), int(b) + 1))
        elif part.strip().isdigit():
            out.append(int(part))
    return out


def efficiency_points(agg_at_dt):
    """Best (fastest) layout for each (mode, cores) among the OK runs at one dt."""
    best = {}
    for a in agg_at_dt:
        if a["status"] != "OK" or not a["wall_s"]:
            continue
        k = (a["mode"], a["np"])
        if k not in best or a["wall_s"] < best[k]["wall_s"]:
            best[k] = a
    out = {}
    for (mode, n), a in sorted(best.items(), key=lambda kv: (kv[0][0], kv[0][1])):
        out.setdefault(mode, []).append(a)
    return out


def efficiency_study(agg, dt, threshold):
    """NLHPC efficiency study: S(n) = T(1)/T(n), E(n) = S(n)/n, per parallel mode."""
    res = {}
    allpts = efficiency_points([a for a in agg if a["dt"] == dt])
    serial = (allpts.pop("serial", None) or [None])[0]
    for mode, pts in allpts.items():
        if serial is not None:  # the serial build (no OpenMP/MPI) is T(1) for every mode
            pts = [serial] + [a for a in pts if a["np"] > 1]
        base = pts[0]
        n0, t0 = base["np"], base["wall_s"]
        rows = []
        for a in pts:
            # without a 1-core run, T(1) is estimated as n0*T(n0) (ideal scaling up to n0 cores)
            S = n0 * t0 / a["wall_s"]
            E = S / a["np"]
            rows.append({"mode": mode, "cores": a["np"],
                         "layout": layout_txt(a),
                         "time_s": a["wall_s"], "speedup": S, "efficiency": E, "alone": a["clean"],
                         "ok": E > threshold})
        # recommended: largest core count with efficiency above the threshold
        okr = [r for r in rows if r["ok"] and r["cores"] > 1]
        rec = max(okr, key=lambda r: r["cores"]) if okr else None
        res[mode] = {"rows": rows, "baseline_cores": n0, "recommended": rec,
                     "serial_baseline": base["mode"] == "serial"}
    return res


def make_efficiency_figure(study, out: Path, dt, threshold):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    if not study:
        return None
    colors = COLORS
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.8))
    allc = sorted({r["cores"] for st in study.values() for r in st["rows"]})
    for mode, st in study.items():
        rows = st["rows"]
        c = [r["cores"] for r in rows]
        a1.plot(c, [r["speedup"] for r in rows], "o-", color=colors[mode], label=mode.upper())
        a2.plot(c, [r["efficiency"] for r in rows], "o-", color=colors[mode], label=mode.upper())
        if st["recommended"]:
            rr = st["recommended"]
            a2.plot(rr["cores"], rr["efficiency"], "*", ms=16, color=colors[mode], mec="k",
                    label=f"{mode.upper()}: recommended {rr['cores']} cores")
    a1.plot(allc, allc, "k:", label="ideal (S = n)")
    a1.set_xlabel("Number of cores")
    a1.set_ylabel("Speed-up  S(n) = T(1) / T(n)")
    a1.set_title("Speed-up")
    a2.axhline(threshold, color="crimson", ls="--", label=f"minimum efficiency {threshold:g}")
    a2.axhline(1.0, color="k", ls=":", lw=1)
    a2.set_ylim(0, 1.15)
    a2.set_xlabel("Number of cores")
    a2.set_ylabel("Efficiency  E(n) = S(n) / n")
    a2.set_title("Parallel efficiency")
    for ax in (a1, a2):
        ax.set_xticks(allc)
        ax.grid(alpha=0.3)
        if ax.get_legend_handles_labels()[0]:
            ax.legend(fontsize=8)
    fig.suptitle(f"WAVEWATCH III efficiency study (dt = {_fmt_dt(dt)} s, best layout per core count)", fontsize=12)
    fig.tight_layout()
    p = out / "efficiency_study.png"
    _save_fig(fig, p)
    plt.close(fig)
    return p


def make_options_figure(opts, out: Path, threshold):
    """Grouped bars: efficiency of the baseline run and of each IOSTYP variant per (mode, cores)."""
    rows = [r for r in (opts or {}).get("rows", [])]
    if not rows:
        return None
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    groups = list(dict.fromkeys((r["mode"], r["n"]) for r in rows))
    variants = list(dict.fromkeys(r["variant"] for r in rows))
    pal = ["#6c757d", "#2a9d8f", "#e9c46a", "#9b5de5", "#e76f51", "#264653"]
    fig, ax = plt.subplots(figsize=(min(11.0, max(6.5, 1.1 * len(groups) * len(variants) / 2 + 3)), 4.6))
    w = 0.8 / len(variants)
    for i, v in enumerate(variants):
        xs, es, labs = [], [], []
        for k, g in enumerate(groups):
            r = next((r for r in rows if (r["mode"], r["n"]) == g and r["variant"] == v), None)
            if r is None:
                continue
            xs.append(k + (i - (len(variants) - 1) / 2) * w)
            es.append(r["E"] or 0.0)
            labs.append(f"{r['E']:.2f}" if r["E"] is not None else r["status"])
        bars = ax.bar(xs, es, w * 0.92, color=pal[i % len(pal)], label=v, edgecolor="k", lw=0.4)
        for b, t in zip(bars, labs):
            ax.annotate(t, (b.get_x() + b.get_width() / 2, b.get_height()), ha="center", va="bottom",
                        fontsize=7, xytext=(0, 2), textcoords="offset points")
    ax.axhline(threshold, color="crimson", ls="--", lw=1.2, label=f"threshold {threshold:g}")
    ax.set_xticks(range(len(groups)))
    ax.set_xticklabels([f"{m.upper()}\n{n} cores" for m, n in groups], fontsize=8)
    ax.set_ylabel("Efficiency  E = T(1) / (n · T)")
    ymax = max([r["E"] or 0 for r in rows] + [threshold])
    ax.set_ylim(0, ymax * 1.25 + 0.02)
    ax.grid(axis="y", alpha=0.3)
    ax.legend(fontsize=8, ncol=2)
    ax.set_title("Runs above the stop point: effect of the output server type IOSTYP", fontsize=10)
    fig.tight_layout()
    p = out / "options_efficiency.png"
    _save_fig(fig, p)
    plt.close(fig)
    return p


def make_schedule_figure(results, out: Path):
    """Gantt chart: which runs occupied which cores and when."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    rs = [r for r in results if r.get("t_start") and r.get("wall_s") and r.get("cpus")]
    if not rs:
        return None
    t0 = min(r["t_start"] for r in rs)
    tend = max(r["t_start"] + r["wall_s"] for r in rs)
    U, un = _tunit([tend - t0])
    cpus = sorted({c for r in rs for c in _parse_ranges(r["cpus"])})
    row = {c: i for i, c in enumerate(cpus)}
    fixed = {"dt-search": "#2a6fdb", "dt-refine": "#d9572b", "serial-ref": "#343a40", "parallel": "#2f9e44",
             "full": "#2f9e44", "filler-dt": "#e8a33d", "filler-rep": "#9c36b5", "dt-confirm": "#1098ad",
             "exclusive": "#868e96", "explore": "#2f9e44", "options": "#e76f51"}
    stages = [st for st in fixed if any(r["stage"] == st for r in rs)]
    stages += [st for st in dict.fromkeys(r["stage"] for r in rs) if st not in fixed]
    col = {st: fixed.get(st, "#495057") for st in stages}
    fig, ax = plt.subplots(figsize=(12, max(3.4, 0.32 * len(cpus) + 2.0)))
    for r in rs:
        x0, w = (r["t_start"] - t0) / U, r["wall_s"] / U
        ys = [row[c] for c in _parse_ranges(r["cpus"])]
        for y in ys:
            ax.barh(y, w, left=x0, height=0.8, color=col[r["stage"]],
                    edgecolor="crimson" if r["status"] == "UNSTABLE" else "white",
                    linewidth=1.5 if r["status"] == "UNSTABLE" else 0.6)
        if w > 0.04 * (tend - t0) / U:
            ax.text(x0 + w / 2, (min(ys) + max(ys)) / 2, f"{ {'openmp': 'omp', 'mpi': 'mpi', 'hybrid': 'hyb'}.get(r['mode'], 'ser')} {r['nx']}x{r['ny']}"
                    f"{' io' + r['opt'].split('=')[1] if r.get('opt') else ''}\n"
                    f"dt={_fmt_dt(r['dt'])}", ha="center", va="center", fontsize=6, color="white")
    ax.set_yticks(range(len(cpus)))
    ax.set_yticklabels([f"cpu {c}" for c in cpus], fontsize=7)
    ax.invert_yaxis()
    ax.set_xlabel(f"Time since start of benchmark [{un}]")
    ax.set_title("Run schedule on the machine cores (red edge = unstable)")
    ax.legend(handles=[Patch(color=col[s], label=s) for s in stages], fontsize=8, loc="upper center",
              bbox_to_anchor=(0.5, -0.14), ncol=min(7, len(stages)), frameon=False)
    ax.grid(alpha=0.3, axis="x")
    fig.tight_layout()
    p = out / "schedule.png"
    _save_fig(fig, p)
    plt.close(fig)
    return p


_TEX_SPECIAL = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_",
                "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}
_TEX_UNICODE = {"Δ": r"$\Delta$", "×": r"$\times$", "·": r"$\cdot$", "›": r"$\triangleright$", "→": r"$\rightarrow$",
                "≈": r"$\approx$", "≤": r"$\leq$", "≥": r"$\geq$", "√": r"$\surd$", "₁": r"$_1$", "²": r"$^2$",
                "★": r"$\star$", "−": r"$-$", "–": "--", "—": "---", "…": r"\ldots{}", "“": "``", "”": "''",
                "±": r"$\pm$", "°": r"$^\circ$", "✓": r"$\checkmark$", "✗": r"$\times$", "€": "EUR"}


def _tex_escape(t: str) -> str:
    out = "".join(_TEX_SPECIAL.get(ch, ch) for ch in t)
    return "".join(_TEX_UNICODE.get(ch, ch) for ch in out)


def _tex_inline(text: str) -> str:
    """Markdown inline markup (**bold**, *italic*, `code`, [text](url)) -> LaTeX, with escaping."""
    keep = []

    def stash(s):
        keep.append(s)
        return f"\x00{len(keep) - 1}\x00"
    t = re.sub(r"`([^`]+)`", lambda m: stash(r"\texttt{" + _tex_escape(m.group(1)) + "}"), str(text))
    t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)",
               lambda m: stash(r"\href{" + m.group(2).replace("%", r"\%").replace("#", r"\#") + "}{"
                               + _tex_escape(m.group(1)) + "}"), t)
    t = _tex_escape(t)
    t = re.sub(r"\*\*(.+?)\*\*", r"\\textbf{\1}", t)
    t = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"\\emph{\1}", t)
    return re.sub("\x00(\\d+)\x00", lambda m: keep[int(m.group(1))], t)


class ReportDoc:
    """Structured report: the same blocks are rendered to Markdown and to PDF."""

    def __init__(self):
        self.blocks, self.nfig, self.ntab = [], 0, 0

    def title(self, text, subtitle=""):
        self.blocks.append(("title", text, subtitle))

    def h(self, level, text):
        self.blocks.append(("h", level, text))

    def p(self, text):
        self.blocks.append(("p", text))

    def note(self, text, kind="info"):
        self.blocks.append(("note", kind, text))

    def ul(self, items):
        if items:
            self.blocks.append(("ul", list(items)))

    def kv(self, rows):
        self.blocks.append(("kv", list(rows)))

    def kpis(self, cards):
        if cards:
            self.blocks.append(("kpi", list(cards)))

    def table(self, header, rows, align=None, caption=None):
        if not rows:
            return
        self.ntab += 1
        self.blocks.append(("table", header, rows, align or ["l"] * len(header), caption, self.ntab))

    def image(self, path, caption):
        if path and Path(path).exists():
            self.nfig += 1
            self.blocks.append(("img", Path(path), caption, self.nfig))

    def pagebreak(self):
        self.blocks.append(("pb",))

    # ------------------------------------------------------------------ Markdown
    def markdown(self):
        L = []
        for b in self.blocks:
            k = b[0]
            if k == "title":
                L += [f"# {b[1]}", ""] + ([f"*{b[2]}*", ""] if b[2] else [])
            elif k == "h":
                L += ["#" * b[1] + " " + b[2], ""]
            elif k == "p":
                L += [b[1], ""]
            elif k == "note":
                L += [f"> **{'Warning' if b[1] == 'warn' else 'Note'}:** {b[2]}", ""]
            elif k == "ul":
                L += [f"- {x}" for x in b[1]] + [""]
            elif k == "kv":
                L += ["| | |", "|:---|:---|"] + [f"| **{a}** | {v} |" for a, v in b[1]] + [""]
            elif k == "kpi":
                L += ["| Result | Value | Detail |", "|:---|:---|:---|"]
                L += [f"| {a} | **{v}** | {s} |" for a, v, s in b[1]] + [""]
            elif k == "table":
                _, header, rows, align, cap, n = b
                if cap:
                    L += [f"*Table {n}. {cap}*", ""]
                sep = {"l": ":---", "r": "---:", "c": ":---:"}
                L += ["| " + " | ".join(header) + " |", "|" + "|".join(sep[a] for a in align) + "|"]
                L += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows] + [""]
            elif k == "img":
                L += [f"![{b[2]}]({b[1].name})", "", f"*Figure {b[3]}. {b[2]}*", ""]
        return "\n".join(L) + "\n"

    # ------------------------------------------------------------------ LaTeX
    def latex(self):
        """Standalone LaTeX source (pdflatex or xelatex; standard packages only)."""
        L = [r"\documentclass[10pt,a4paper]{article}",
             r"\usepackage[T1]{fontenc}", r"\usepackage[utf8]{inputenc}",
             r"\IfFileExists{lmodern.sty}{\usepackage{lmodern}}{}",
             r"\usepackage[margin=18mm,headheight=14pt]{geometry}", r"\usepackage[table]{xcolor}",
             r"\usepackage{graphicx}", r"\usepackage{booktabs}", r"\usepackage{longtable}", r"\usepackage{array}",
             r"\usepackage{amssymb}", r"\usepackage{fancyhdr}",
             r"\IfFileExists{lastpage.sty}{\usepackage{lastpage}\newcommand{\ofpages}{\ of \pageref{LastPage}}}"
             r"{\newcommand{\ofpages}{}}",
             r"\IfFileExists{caption.sty}{\usepackage{caption}"
             r"\captionsetup{font=small,labelfont={bf,color=navy}}}{}",
             r"\IfFileExists{enumitem.sty}{\usepackage{enumitem}"
             r"\setlist[itemize]{leftmargin=14pt,itemsep=2pt,topsep=2pt}}{}",
             r"\usepackage[hidelinks]{hyperref}",
             r"\definecolor{navy}{HTML}{16324F}", r"\definecolor{accent}{HTML}{2A6FDB}",
             r"\definecolor{zebra}{HTML}{F4F6F9}", r"\definecolor{noteinfo}{HTML}{EEF4FD}",
             r"\definecolor{notewarn}{HTML}{FFF6E5}", r"\definecolor{muted}{HTML}{6B7685}",
             r"\setlength{\parindent}{0pt}", r"\setlength{\parskip}{4pt}",
             r"\renewcommand{\arraystretch}{1.15}",
             r"\pagestyle{fancy}\fancyhf{}", r"\renewcommand{\headrulewidth}{0.3pt}",
             r"\fancyfoot[L]{\color{muted}\footnotesize Generated by ww3\_bench.py}",
             r"\fancyfoot[R]{\color{muted}\footnotesize Page \thepage\ofpages}"]
        hdr = next((b for b in self.blocks if b[0] == "title"), None)
        if hdr:
            L.append(r"\fancyhead[L]{\color{muted}\footnotesize " + _tex_inline(hdr[1] + " · " + hdr[2]) + "}")
        L += [r"\begin{document}"]
        for b in self.blocks:
            k = b[0]
            if k == "title":
                L += [r"\noindent\colorbox{navy}{\parbox{\dimexpr\linewidth-2\fboxsep}{\vspace{8pt}",
                      r"{\color{white}\LARGE\bfseries " + _tex_inline(b[1]) + r"}\\[4pt]",
                      r"{\color{white!80!accent}\small " + _tex_inline(b[2]) + r"}\vspace{6pt}}}",
                      r"\par\noindent{\color{accent}\rule{\linewidth}{2pt}}\par\medskip"]
            elif k == "h":
                L.append((r"\section{" if b[1] <= 2 else r"\subsection*{") + _tex_inline(b[2]) + "}")
            elif k == "p":
                L += [_tex_inline(b[1]), ""]
            elif k == "note":
                col = "notewarn" if b[1] == "warn" else "noteinfo"
                L += [r"\par\noindent\colorbox{" + col + r"}{\parbox{\dimexpr\linewidth-2\fboxsep}{\small "
                      + (r"\textbf{Warning:} " if b[1] == "warn" else r"\textbf{Note:} ") + _tex_inline(b[2])
                      + r"}}\par\medskip"]
            elif k == "ul":
                L += [r"\begin{itemize}"] + [r"\item " + _tex_inline(x) for x in b[1]] + [r"\end{itemize}"]
            elif k == "kv":
                L += [r"{\small\noindent\begin{tabular}{@{}p{0.24\linewidth}p{0.73\linewidth}@{}}"]
                L += [r"\textbf{\textcolor{navy}{" + _tex_inline(a) + "}} & " + _tex_inline(v) + r" \\[1pt]"
                      for a, v in b[1]]
                L += [r"\end{tabular}}\par\medskip"]
            elif k == "kpi":
                L += [r"\begin{center}\small\rowcolors{1}{zebra}{zebra}",
                      r"\begin{tabular}{!{\color{accent}\vrule width 2pt}>{\raggedright\arraybackslash}p{0.29\linewidth}"
                      r"!{\color{accent}\vrule width 2pt}>{\raggedright\arraybackslash}p{0.29\linewidth}"
                      r"!{\color{accent}\vrule width 2pt}>{\raggedright\arraybackslash}p{0.29\linewidth}}"]
                cells = [r"{\scriptsize\color{muted}" + _tex_inline(a.upper()) + r"}\newline"
                         r"{\large\bfseries\color{navy} " + _tex_inline(v) + r"}\newline{\scriptsize " +
                         _tex_inline(s_) + "}" for a, v, s_ in b[1]]
                while len(cells) % 3:
                    cells.append("")
                for i in range(0, len(cells), 3):
                    L.append(" & ".join(cells[i:i + 3]) + r" \\[3pt]")
                L += [r"\end{tabular}\end{center}"]
            elif k == "table":
                _, header, rows, align, caption, n = b
                size = r"\scriptsize" if len(header) > 8 else r"\footnotesize"
                spec = "".join({"l": "l", "r": "r", "c": "c"}[a] for a in align)
                if len(header) > 8:  # wide table: let the last text column wrap
                    spec = spec[:-1] + r"p{0.16\linewidth}" if spec[-1] == "l" else spec
                L += ["{" + size + r"\rowcolors{2}{white}{zebra}",
                      r"\begin{longtable}{" + spec + "}"]
                if caption:
                    L.append(r"\caption{" + _tex_inline(caption) + r"}\\")
                head = " & ".join(r"\textbf{" + _tex_inline(h) + "}" for h in header) + r" \\"
                L += [r"\toprule", head, r"\midrule", r"\endfirsthead", r"\toprule", head, r"\midrule", r"\endhead",
                      r"\bottomrule", r"\endfoot"]
                L += [" & ".join(_tex_inline(str(c)) for c in r) + r" \\" for r in rows]
                L += [r"\end{longtable}}"]
            elif k == "img":
                L += [r"\begin{figure}[htbp]\centering",
                      r"\includegraphics[width=\linewidth,height=0.55\textheight,keepaspectratio]{"
                      + b[1].name + "}", r"\caption{" + _tex_inline(b[2]) + "}", r"\end{figure}"]
            elif k == "pb":
                L.append(r"\clearpage")
        L += [r"\end{document}", ""]
        return "\n".join(L)

    # ------------------------------------------------------------------ PDF
    def pdf(self, out_pdf: Path, header_text=""):
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_LEFT, TA_CENTER
        from reportlab.lib.fonts import addMapping
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.lib.utils import ImageReader
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.pdfgen import canvas as rl_canvas
        from reportlab.platypus import (CondPageBreak, Image, KeepTogether, ListFlowable, ListItem, PageBreak,
                                        Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)
        from reportlab.platypus.flowables import HRFlowable
        import matplotlib
        ttf = Path(matplotlib.get_data_path()) / "fonts" / "ttf"
        for name, f in (("DejaVu", "DejaVuSans.ttf"), ("DejaVu-Bold", "DejaVuSans-Bold.ttf"),
                        ("DejaVu-Oblique", "DejaVuSans-Oblique.ttf"),
                        ("DejaVu-BoldOblique", "DejaVuSans-BoldOblique.ttf"), ("DejaVuMono", "DejaVuSansMono.ttf")):
            if name not in pdfmetrics.getRegisteredFontNames():
                pdfmetrics.registerFont(TTFont(name, str(ttf / f)))
        addMapping("DejaVu", 0, 0, "DejaVu")
        addMapping("DejaVu", 1, 0, "DejaVu-Bold")
        addMapping("DejaVu", 0, 1, "DejaVu-Oblique")
        addMapping("DejaVu", 1, 1, "DejaVu-BoldOblique")

        NAVY, ACCENT, INK = colors.HexColor("#16324f"), colors.HexColor("#2a6fdb"), colors.HexColor("#1f2933")
        MUTED, LINE, ZEBRA = colors.HexColor("#6b7685"), colors.HexColor("#cfd6df"), colors.HexColor("#f4f6f9")
        body = ParagraphStyle("body", fontName="DejaVu", fontSize=9.2, leading=13, textColor=INK,
                              alignment=TA_LEFT, spaceAfter=5)
        small = ParagraphStyle("small", parent=body, fontSize=7.6, leading=10, textColor=MUTED, spaceAfter=0)
        cap = ParagraphStyle("cap", parent=body, fontName="DejaVu-Oblique", fontSize=8, leading=10.5,
                             textColor=MUTED, spaceBefore=2, spaceAfter=8)
        h2 = ParagraphStyle("h2", parent=body, fontName="DejaVu-Bold", fontSize=13.5, leading=17, textColor=NAVY,
                            spaceBefore=4, spaceAfter=2, keepWithNext=1)
        h3 = ParagraphStyle("h3", parent=body, fontName="DejaVu-Bold", fontSize=10.5, leading=14, textColor=NAVY,
                            spaceBefore=6, spaceAfter=3, keepWithNext=1)
        page_w, page_h = A4
        margin = 16 * mm
        avail = page_w - 2 * margin
        story, sec = [], 0

        def colwidths(rows_plain, header_bold=True, fs=7.4, pad=10.0):
            ncol = max(len(r) for r in rows_plain)

            def wd(t, k, size):  # measured in bold (cells may be bold) plus 3 % margin
                return 1.03 * pdfmetrics.stringWidth(t, "DejaVu-Bold", size)
            while True:
                wmin = [max(max((wd(x, k, fs) for x in r[c].split()), default=0.0)
                            for k, r in enumerate(rows_plain)) + pad for c in range(ncol)]
                if sum(wmin) <= avail or fs <= 5.0:
                    break
                fs -= 0.4
            wtgt = [max(wmin[c], max(wd(r[c][:48], k, fs) for k, r in enumerate(rows_plain)) + pad)
                    for c in range(ncol)]
            if sum(wtgt) <= avail:
                return wtgt, fs
            extra = max(0.0, avail - sum(wmin))
            grow = [wtgt[c] - wmin[c] for c in range(ncol)]
            g = float(sum(grow)) or 1.0
            return [wmin[c] + extra * grow[c] / g for c in range(ncol)], fs

        def plain(t):
            return re.sub(r"[*`]", "", re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", str(t)))

        for b in self.blocks:
            k = b[0]
            if k == "title":
                band = Table([[Paragraph(f'<font name="DejaVu-Bold" size="20" color="white">{_md_inline(b[1])}</font>',
                                         body)],
                              [Paragraph(f'<font size="10" color="#d6e2f2">{_md_inline(b[2])}</font>', body)]],
                             colWidths=[avail])
                band.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), NAVY),
                                          ("LEFTPADDING", (0, 0), (-1, -1), 12), ("RIGHTPADDING", (0, 0), (-1, -1), 12),
                                          ("TOPPADDING", (0, 0), (0, 0), 14), ("BOTTOMPADDING", (0, -1), (-1, -1), 12),
                                          ("LINEBELOW", (0, -1), (-1, -1), 3, ACCENT)]))
                story += [band, Spacer(1, 10)]
            elif k == "h":
                if b[1] <= 2:
                    sec += 1
                    story += [CondPageBreak(60 * mm), Spacer(1, 6),
                              Paragraph(f"{sec}. {_md_inline(b[2])}", h2),
                              HRFlowable(width="100%", thickness=1.2, color=ACCENT, spaceBefore=1, spaceAfter=7)]
                else:
                    story.append(Paragraph(_md_inline(b[2]), h3))
            elif k == "p":
                story.append(Paragraph(_md_inline(b[1]), body))
            elif k == "note":
                col = colors.HexColor("#e8a33d") if b[1] == "warn" else ACCENT
                bg = colors.HexColor("#fff6e5") if b[1] == "warn" else colors.HexColor("#eef4fd")
                t = Table([[Paragraph(_md_inline(b[2]), body)]], colWidths=[avail])
                t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), bg), ("LINEBEFORE", (0, 0), (0, -1), 3, col),
                                       ("LEFTPADDING", (0, 0), (-1, -1), 9), ("TOPPADDING", (0, 0), (-1, -1), 5),
                                       ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
                story += [t, Spacer(1, 7)]
            elif k == "ul":
                story.append(ListFlowable([ListItem(Paragraph(_md_inline(x), body), leftIndent=11) for x in b[1]],
                                          bulletType="bullet", start="•", leftIndent=12, bulletFontName="DejaVu",
                                          bulletColor=ACCENT))
                story.append(Spacer(1, 3))
            elif k == "kv":
                data = [[Paragraph(f'<font name="DejaVu-Bold" color="#16324f">{_md_inline(a)}</font>', body),
                         Paragraph(_md_inline(v), body)] for a, v in b[1]]
                t = Table(data, colWidths=[avail * 0.27, avail * 0.73])
                t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                       ("LINEBELOW", (0, 0), (-1, -2), 0.3, LINE),
                                       ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 1)]))
                story += [t, Spacer(1, 8)]
            elif k == "kpi":
                cards = b[1]
                per = 3
                cw = avail / per
                cells = []
                for a, v, s_ in cards:
                    cells.append([Paragraph(f'<font size="7.5" color="#6b7685">{_md_inline(a).upper()}</font>', body),
                                  Paragraph(f'<font name="DejaVu-Bold" size="14" color="#16324f">{_md_inline(v)}</font>',
                                            ParagraphStyle("kv", parent=body, leading=18, spaceAfter=1)),
                                  Paragraph(_md_inline(s_), small)])
                while len(cells) % per:
                    cells.append("")
                grid = [cells[i:i + per] for i in range(0, len(cells), per)]
                t = Table(grid, colWidths=[cw] * per)
                st_ = [("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 9),
                       ("RIGHTPADDING", (0, 0), (-1, -1), 6), ("TOPPADDING", (0, 0), (-1, -1), 6),
                       ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]
                for i in range(len(cards)):
                    r, c = divmod(i, per)
                    st_ += [("BACKGROUND", (c, r), (c, r), ZEBRA), ("LINEBEFORE", (c, r), (c, r), 3, ACCENT),
                            ("LINEAFTER", (c, r), (c, r), 4, colors.white),
                            ("LINEBELOW", (c, r), (c, r), 4, colors.white)]
                t.setStyle(TableStyle(st_))
                story += [t, Spacer(1, 8)]
            elif k == "table":
                _, header, rows, align, caption, n = b
                rp = [[plain(c) for c in header]] + [[plain(c) for c in r] for r in rows]
                widths, fs = colwidths(rp)
                cst = ParagraphStyle("c", parent=body, fontSize=fs, leading=fs * 1.25, spaceAfter=0)
                hst = ParagraphStyle("hc", parent=cst, fontName="DejaVu-Bold", textColor=colors.white)
                amap = {"l": TA_LEFT, "r": 2, "c": TA_CENTER}

                def cellp(txt, j, style):
                    return Paragraph(_md_inline(txt), ParagraphStyle(f"a{j}{style.name}", parent=style,
                                                                     alignment=amap.get(align[j], TA_LEFT)))
                data = [[cellp(c, j, hst) for j, c in enumerate(header)]] + \
                       [[cellp(str(c), j, cst) for j, c in enumerate(r)] for r in rows]
                t = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
                t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), NAVY),
                                       ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, ZEBRA]),
                                       ("LINEBELOW", (0, 0), (-1, -1), 0.25, LINE),
                                       ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                       ("LEFTPADDING", (0, 0), (-1, -1), 3.5), ("RIGHTPADDING", (0, 0), (-1, -1), 3.5),
                                       ("TOPPADDING", (0, 0), (-1, -1), 2.2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.2)]))
                items = []
                if caption:
                    items.append(Paragraph(f'<font name="DejaVu-Bold" color="#16324f">Table {n}.</font> '
                                           f"{_md_inline(caption)}", ParagraphStyle("tc", parent=cap,
                                                                                    fontName="DejaVu", spaceAfter=3)))
                items.append(t)
                story += [KeepTogether(items) if len(rows) < 25 else items[0], *([] if len(rows) < 25 else [t]),
                          Spacer(1, 9)]
            elif k == "img":
                _, path, caption, n = b
                iw, ih = ImageReader(str(path)).getSize()
                w_ = avail
                hh = w_ * ih / iw
                if hh > 0.58 * page_h:
                    hh = 0.58 * page_h
                    w_ = hh * iw / ih
                img = Image(str(path), width=w_, height=hh)
                frame = Table([[img]], colWidths=[avail])
                frame.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER"), ("BOX", (0, 0), (-1, -1), 0.4, LINE),
                                           ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
                story.append(KeepTogether([frame, Paragraph(
                    f'<font name="DejaVu-Bold" color="#16324f">Figure {n}.</font> {_md_inline(caption)}', cap)]))
            elif k == "pb":
                story.append(PageBreak())

        class Numbered(rl_canvas.Canvas):  # "page X of Y"
            def __init__(self, *a, **kw):
                super().__init__(*a, **kw)
                self._pages = []

            def showPage(self):
                self._pages.append(dict(self.__dict__))
                self._startPage()

            def save(self):
                n = len(self._pages)
                for st in self._pages:
                    self.__dict__.update(st)
                    self.setFont("DejaVu", 7)
                    self.setFillColor(MUTED)
                    if self._pageNumber > 1:
                        self.drawString(margin, page_h - 10 * mm, header_text)
                        self.setStrokeColor(LINE)
                        self.setLineWidth(0.4)
                        self.line(margin, page_h - 11.5 * mm, page_w - margin, page_h - 11.5 * mm)
                    self.drawString(margin, 9 * mm, "Generated by ww3_bench.py")
                    self.drawRightString(page_w - margin, 9 * mm, f"Page {self._pageNumber} of {n}")
                    super().showPage()
                super().save()

        tmp = out_pdf.with_name(out_pdf.stem + ".tmp.pdf")
        doc = SimpleDocTemplate(str(tmp), pagesize=A4, leftMargin=margin, rightMargin=margin,
                                topMargin=16 * mm, bottomMargin=16 * mm, title="WAVEWATCH III Benchmark Report",
                                author="ww3_bench.py")
        doc.build(story, canvasmaker=Numbered)
        os.replace(tmp, out_pdf)


def write_report(results, cfg, meta, out: Path, partial=False):
    agg = aggregate(results)
    if not agg:
        if not partial:
            print("[report] no results yet")
        return None
    rows, last_ok, first_fail = stability_summary(agg)
    ok = [a for a in agg if a["status"] == "OK"]
    dt_opt = None
    if ok:  # dt at which most layouts were compared (stage 2); ties -> larger dt
        cnt = {}
        for a in ok:
            cnt[a["dt"]] = cnt.get(a["dt"], 0) + 1
        dt_opt = max(cnt, key=lambda d: (cnt[d], d))
    elif last_ok:
        dt_opt = last_ok["dt"]
    at_opt = [a for a in ok if a["dt"] == dt_opt]
    best = min(at_opt, key=lambda a: a["wall_s"]) if at_opt else None
    make_figures(agg, out, dt_opt)
    sch = make_schedule_figure(results, out)
    sim_days = cfg["sim_days"]
    mach = meta["machine"]
    thr = float(cfg["efficiency_threshold"])
    dt_rec = meta.get("dt_opt")
    rec_row = next((r for r in rows if dt_rec is not None and r["dt"] == dt_rec), None)
    study = efficiency_study(agg, dt_opt, thr) if (cfg["efficiency_study"] and dt_opt is not None) else {}
    effig = make_efficiency_figure(study, out, dt_opt, thr) if study else None
    ts0 = meta.get("ts0") or {}
    cfl = meta.get("cfl") or {}
    grid_txt = (f"{meta['nx']} × {meta['ny']}" if meta.get("nx") else meta.get("grid_type") or "?")
    spec_txt = (f"{meta['nk']} frequencies × {meta['nth']} directions (f1 = {meta['f1']:g} Hz, factor "
                f"{meta['xfr']:g})" if meta.get("nk") else "?")
    name = meta.get("grid_name") or "?"

    D = ReportDoc()
    D.title("WAVEWATCH III Benchmark Report",
            f"grid '{name}' {grid_txt}  ·  {_days(sim_days)} per run  ·  {_dt.datetime.now():%Y-%m-%d %H:%M}")
    if partial:
        D.note(f"**Partial report**, updated {_dt.datetime.now():%Y-%m-%d %H:%M:%S} with {len(results)} finished "
               "run(s); the benchmark is still running.", "warn")
    D.kv([
        ("Grid", f"`{meta.get('grid_file')}`: '{name}', {meta.get('grid_type')} "
                 f"{grid_txt}{' (spherical)' if meta.get('spherical') else ' (Cartesian)' if meta.get('nx') else ''}"),
        ("Spectrum", spec_txt),
        ("Original time steps", "DTMAX / DTXY / DTKTH / DTMIN = "
                                + " / ".join(_fmt_num(ts0[k]) for k in TS_KEYS) + " s" if ts0 else "?"),
        ("Switch file", f"`{meta.get('switch') or '?'}`"),
        ("Machine", f"`{mach.get('hostname')}`: {mach.get('cpu')}; {mach.get('physical_cores', '?')} physical / "
                    f"{mach.get('logical_cpus')} logical CPUs"),
        ("Cores used", f"{mach.get('cores_used', '?')} (CPU {_cpu_ranges(mach.get('cpu_slots') or [])}), up to "
                       f"{mach.get('max_parallel_jobs', '?')} simultaneous runs"),
        ("Run directory", f"`{cfg['run_dir']}`"),
        ("Simulated period", f"{_days(sim_days)} per run from {meta.get('start')} (`{meta.get('shel_file')}`); "
                             f"output server type IOSTYP = {meta.get('iostyp0')}"),
    ])

    # ---------------------------------------------------------------- 1. key results
    D.h(2, "Key results")
    cards = []
    if rec_row:
        cards.append(("Recommended DTMAX", f"{_fmt_dt(rec_row['dt'])} s",
                      f"DTXY {_fmt_num(rec_row['dtxy'])} s; 3600 / {3600 / rec_row['dt']:g}; largest stable "
                      f"{_fmt_dt(last_ok['dt']) if last_ok else '?'} s"))
    elif last_ok:
        cards.append(("Optimal DTMAX", f"{_fmt_dt(last_ok['dt'])} s", "largest stable dt"))
    opts = meta.get("options") or {}
    orows = [r for r in opts.get("rows", []) if not r.get("baseline") and r.get("E") is not None]
    obest = max([r for r in orows if r["above"]], key=lambda r: (r["cores"], r["E"]), default=None)
    if obest:
        cards.append(("Best IOSTYP variant", f"{obest['variant']}",
                      f"{obest['mode'].upper()} {obest['cores']} cores, E = {obest['E']:.3f} > {thr:g}"))
    for mode, st in study.items():
        r = st["recommended"]
        cards.append((f"Recommended cores · {mode.upper()}", f"{r['cores']} cores" if r else "none",
                      f"{r['layout']}, E = {r['efficiency']:.3f}" if r else f"no core count with E > {thr:g}"))
    if best:
        cards.append(("Fastest run", f"{best['mode'].upper()} {best['np']} cores",
                      f"{layout_txt(best)}, {_tfmt(best['wall_s'])} per {_days(sim_days)}"))
    crow = rec_row or last_ok
    if crow and crow.get("cfl_xy") is not None:
        cards.append(("Propagation CFL at recommended dt", f"{crow['cfl_xy']:.3f}",
                      f"cg(f1)·DTXY/dx; limit {cfg['cfl_limit']:g}" +
                      (f"; first unstable DTMAX {_fmt_dt(first_fail['dt'])} s" if first_fail else "")))
    ser = next((a for a in agg if a["mode"] == "serial" and a["dt"] == dt_opt and a["wall_s"]), None)
    if ser:
        cards.append(("Serial reference T(1)", _tfmt(ser["wall_s"]), f"1 core, SHRD build, DTMAX = {_fmt_dt(dt_opt)} s"))
    D.kpis(cards)
    for r in results:
        if r["status"] == "COMPILE_FAIL":
            D.note(f"The {r['mode'].upper()} build failed ({r.get('notes')}); see `{r.get('log')}`.", "warn")

    items = []
    if rec_row:
        items.append(f"**Recommended global time step: DTMAX = {_fmt_dt(rec_row['dt'])} s** = 3600 / "
                     f"{3600 / rec_row['dt']:g}, the largest integer dt that divides 3600 without exceeding the largest "
                     f"stable dt; with it DTXY = {_fmt_num(rec_row['dtxy'])} s, DTKTH = {_fmt_num(rec_row['dtkth'])} s, "
                     f"DTMIN = {_fmt_num(rec_row['dtmin'])} s. All times and efficiencies were measured with it.")
    if last_ok:
        items.append(f"**Largest stable DTMAX found:** {_fmt_dt(last_ok['dt'])} s (DTXY = {_fmt_num(last_ok['dtxy'])} s"
                     + (f", propagation CFL {last_ok['cfl_xy']:.3f}" if last_ok.get("cfl_xy") is not None else "")
                     + ").")
    if first_fail and last_ok:
        items.append(f"**Stability limit** between {_fmt_dt(last_ok['dt'])} s (stable) and "
                     f"{_fmt_dt(first_fail['dt'])} s (first unstable dt"
                     + (", decided from the CFL number without running" if first_fail.get("not_run") else "") + ").")
    elif first_fail:
        items.append(f"**No tested dt was stable:** even the smallest, {_fmt_dt(min(r['dt'] for r in rows))} s, failed. "
                     "Try a smaller `dt_ref`, and check the run log: the problem may not be the time step.")
    else:
        items.append("No tested dt was unstable: the stability limit is above the largest dt tested (the search "
                     "stopped at `min_steps` or `max_dt_runs`).")
    for mode, st in study.items():
        r = st["recommended"]
        items.append(f"**{mode.upper()}:** " + (f"up to **{r['cores']} cores** ({r['layout']}, efficiency "
                                                 f"{r['efficiency']:.3f} > {thr:g})." if r else
                                                 f"no core count keeps the efficiency above {thr:g}."))
    if opts.get("rows") or opts.get("notes"):
        if obest:
            items.append(f"**Output server:** {obest['variant']} raises the efficiency of the {obest['n']}-core "
                         f"{obest['mode'].upper()} run to {obest['E']:.3f} (baseline {obest['E_base']:.3f}): above the "
                         f"threshold {thr:g}.")
        elif orows:
            g = max(orows, key=lambda r: r["dE"])
            items.append(f"**Output server:** no IOSTYP variant brings a larger run above E = {thr:g}; largest change: "
                         f"{g['variant']} at {g['mode'].upper()} {g['n']} cores, E {g['E_base']:.3f} → {g['E']:.3f} "
                         f"({g['dE']:+.3f}).")
        else:
            items.append("**Output server:** no IOSTYP variant completed (see the section below).")
    if best:
        items.append(f"**Fastest configuration:** {best['mode'].upper()} with {best['np']} cores ({layout_txt(best)}), "
                     f"{_tfmt(best['wall_s'])} per {_days(sim_days)} ({_f(best['days_per_hour'], '{:.1f}')} simulated "
                     "days per wall-clock hour), " + ("measured alone on the machine." if best["clean"] else
                                                       f"measured while sharing the machine with {best['peers']} run(s)."))
    D.ul(items)

    # ---------------------------------------------------------------- 2. time step
    D.h(2, "Time-step search (serial run)")
    D.p("All runs of this stage use the serial build (1 core, `SHRD`). The search variable is the global time step "
        "DTMAX; "
        + ("DTXY and DTKTH keep their ratio to DTMAX" if cfg["timestep_mode"] == "proportional" else
           "DTXY and DTKTH stay as in the grid input (capped at DTMAX)")
        + ", DTMIN " + ("scales with DTMAX" if cfg["dtmin_mode"] == "proportional" else
                        "stays as in the grid input (capped at DTMAX)")
        + f", and `ww3_grid` writes a new `mod_def.ww3` for each dt. Starting from the reference dt "
        f"({_fmt_dt(float(cfg['dt_ref'] or meta['dt0']))} s), dt is doubled while the run is stable; after the first "
        "unstable run the next dt is the midpoint between the last stable and the last unstable dt, and the search "
        "stops after two unstable runs in a row. A dt larger than an unstable one is never tested, and when going down "
        "the search never goes below a stable dt whose half is also stable.")
    D.p("**Unstable** means: NaN or floating-point errors in the output of `ww3_shel` or in `log.ww3`"
        + (f"; a propagation CFL number above {cfg['cfl_limit']:g} (such a dt is not run)"
           if cfg["cfl_rule"] == "unstable" else "")
        + ("; or a failed field check (`check_cmd`)" if cfg.get("check_cmd") else "")
        + ". WW3 seldom stops when its time step is too long, so a run that ends normally is not proof of stability"
        + ("." if cfg["cfl_rule"] == "unstable" or cfg.get("check_cmd") else
           ": consider `cfl_rule: unstable` or a `check_cmd`."))
    path = meta.get("dt_path") or []
    if path:
        lab = {"OK": "stable", "UNSTABLE": "unstable", "OK (inferred)": "stable (inferred)"}
        D.table(["Step", "Phase", "DTMAX [s]", "Result"],
                [[i + 1, r["phase"], _fmt_dt(r["dt"]), lab.get(r["status"], r["status"])] for i, r in enumerate(path)],
                ["r", "l", "r", "l"], "Decision sequence of the time-step search.")
    D.table(["DTMAX [s]", "DTXY [s]", "DTKTH [s]", "DTMIN [s]", "Status", "CFL x", "CFL y", "Best time"],
            [[_fmt_dt(r["dt"]) + (" ★" if rec_row and r is rec_row else ""), _f(r["dtxy"], "{:g}"),
              _f(r["dtkth"], "{:g}"), _f(r["dtmin"], "{:g}"),
              r["status"].lower().replace("ok", "stable") + (" (CFL, not run)" if r["not_run"] and
                                                             r["status"] == "UNSTABLE" else ""),
              _f(r["cfl_x"]), _f(r["cfl_y"]), _tfmt(r["best_wall"])] for r in rows],
            ["r", "r", "r", "r", "l", "r", "r", "r"],
            "Time steps, stability and propagation Courant numbers for every dt tested (★ = recommended dt).")
    if cfl:
        D.p(f"Propagation CFL = cg(f1) · DTXY / Δ, with cg(f1) = {cfl['cg_max']:.2f} m/s the largest group velocity of "
            f"the lowest frequency f1 = {cfl['f1']:g} Hz ({cfl['source']}), Δx_min = {cfl['dx_min'] / 1e3:.2f} km "
            f"(at the highest latitude for spherical grids) and Δy = {cfl['dy_min'] / 1e3:.2f} km.")
        D.image(out / "cfl_vs_dt.png", "Propagation Courant numbers versus time step; the dashed lines mark the largest "
                                       "stable dt and the first unstable dt.")
    else:
        D.note("The propagation CFL number was not computed (only rectilinear grids with a readable spectral and grid "
               "definition are supported).")

    # ---------------------------------------------------------------- 3. cores
    D.h(2, "Core-count exploration")
    D.p(f"Each parallel mode starts at {meta.get('ref_cores')} cores. MPI uses n ranks (WW3 distributes the sea points "
        "over the ranks), OpenMP n threads, and hybrid n = ranks × threads for each value of `hybrid_threads` (the "
        "fastest is kept). With E(n) = T(1) / (n · T(n)): each mode **stops at the first core count with E > "
        f"{thr:g}** (that configuration is its result); otherwise the next test uses {cfg['core_step']} fewer cores, "
        "down to 2.")
    for mode, e in (meta.get("explore_path") or {}).items():
        t = e["tested"]
        if not t:
            continue
        D.table(["Cores", "Best layout", "Time", "Efficiency E", "Decision"],
                [[n, v["layout"], _tfmt(v["wall"]), f"{v['E']:.3f}",
                  f"E > {thr:g} → stop" if v["E"] > thr else f"E ≤ {thr:g} → −{cfg['core_step']}"]
                 for n, v in t.items()],
                ["r", "c", "r", "r", "l"], f"{mode.upper()} exploration path (stop: {e['why']}).")
    D.image(out / "benchmark_summary.png", f"(a) run time versus dt, (b) scaling and (c) parallel efficiency at dt = "
                                           f"{_fmt_dt(dt_opt) if dt_opt else '?'} s, (d) every layout tested.")

    # ---------------------------------------------------------------- 4. efficiency study
    if study:
        D.h(2, "Efficiency study (NLHPC format)")
        D.p(f"Format of the [NLHPC efficiency study](https://wiki.nlhpc.cl/Estudio_de_Eficiencia), at DTMAX = "
            f"{_fmt_dt(dt_opt)} s and {_days(sim_days)} simulated, with the best layout of each core count: "
            "**speed-up** S(n) = T(1) / T(n), **efficiency** E(n) = S(n) / n. T(1) is the serial run (1 core, built "
            f"with `SHRD`). Recommended: the largest core count with E > {thr:g}.")
        with open(out / "efficiency_study.csv", "w", newline="") as fcsv:
            cw = csv.writer(fcsv)
            cw.writerow(["mode", "cores", "layout", "time_s", "speedup", "efficiency", "measured_alone"])
            for mode, st in study.items():
                rr = st["rows"]
                for r in rr:
                    cw.writerow([mode, r["cores"], r["layout"], f"{r['time_s']:.2f}", f"{r['speedup']:.2f}",
                                 f"{r['efficiency']:.2f}", r["alone"]])
                D.table(["No. of cores"] + [str(r["cores"]) for r in rr],
                        [["Layout"] + [r["layout"] for r in rr],
                         ["Time [s]"] + [f"{r['time_s']:.2f}" for r in rr],
                         ["Speed-up"] + [f"{r['speedup']:.2f}" for r in rr],
                         ["Efficiency"] + [f"**{r['efficiency']:.2f}**" if r["ok"] else f"{r['efficiency']:.2f}"
                                           for r in rr],
                         ["Measured alone"] + ["yes" if r["alone"] else "**no**" for r in rr]],
                        ["l"] + ["r"] * len(rr),
                        f"{mode.upper()}: " + (f"recommended **{st['recommended']['cores']} cores**."
                                               if st["recommended"] else f"no core count with E > {thr:g}."))
                if st["baseline_cores"] > 1:
                    D.note(f"No 1-core run: T(1) estimated as {st['baseline_cores']}·T({st['baseline_cores']}), "
                           "assuming ideal scaling up to that core count.")
        D.image(effig, "Speed-up (left, with the ideal line) and parallel efficiency (right, with the threshold); "
                       "stars mark the recommended core count of each mode.")
        if any(not r["alone"] for st in study.values() for r in st["rows"]):
            D.note("Some points were measured while sharing the machine with other runs (row “Measured alone” = no). "
                   "For a formal efficiency study use `efficiency_exclusive: true`.", "warn")

    # ---------------------------------------------------------------- 4b. IOSTYP
    if opts and (opts.get("rows") or opts.get("notes")):
        ofig = make_options_figure(opts, out, thr)
        D.h(2, "Output server type (IOSTYP)")
        stops = ", ".join(f"{m.upper()} {n} cores" for m, n in (opts.get("stop") or {}).items() if n)
        counts = "; ".join(f"{m.upper()} {', '.join(map(str, c))}" for m, c in (opts.get("counts") or {}).items() if c)
        D.p("After the stop point of the exploration" + (f" ({stops})" if stops else "")
            + ", the runs with more cores (" + (counts or "none") + ") are repeated at the same dt with other output "
            f"server types in `{meta.get('shel_file')}` (baseline IOSTYP = {opts.get('iostyp0')}). IOSTYP = 0: no "
            "server, every process writes directly (needs a parallel file system); 1: no server; 2: the last process "
            "is reserved for output; 3: several dedicated output processes. The cores used do not change, so "
            "E = T(1) / (n · T).")
        if opts.get("rows"):
            with open(out / "options_study.csv", "w", newline="") as fcsv:
                cw = csv.writer(fcsv)
                cw.writerow(["mode", "cores", "variant", "layout", "time_s", "efficiency", "efficiency_baseline",
                             "delta_E", "speedup_vs_baseline", "above_threshold", "status"])
                for r in opts["rows"]:
                    cw.writerow([r["mode"], r["n"], r["variant"], r["layout"], _f(r["wall"], "{:.2f}"),
                                 _f(r["E"], "{:.4f}"), f"{r['E_base']:.4f}", _f(r["dE"], "{:+.4f}"),
                                 _f(r["speed"], "{:.3f}"), r["above"], r["status"]])
            D.table(["Mode", "Cores", "Variant", "Layout", "Time", "E", "ΔE vs baseline", "Speed vs baseline",
                     f"E > {thr:g}"],
                    [[r["mode"].upper(), r["n"], r["variant"], r["layout"], _tfmt(r["wall"]),
                      (f"**{r['E']:.3f}**" if r["above"] else f"{r['E']:.3f}") if r["E"] is not None else r["status"],
                      _f(r["dE"], "{:+.3f}") if not r.get("baseline") else "—",
                      _f(r["speed"], "{:.2f}×") if not r.get("baseline") else "—",
                      "yes" if r["above"] else "no"] for r in opts["rows"]],
                    ["l", "r", "l", "c", "r", "r", "r", "r", "c"],
                    "Runs above the stop point with each output server type (Speed > 1: the variant is faster).")
            if ofig:
                D.image(ofig, "Efficiency of each IOSTYP variant; the dashed line is the threshold.")
        for nt in opts.get("notes", []):
            D.note(nt, "warn")

    # ---------------------------------------------------------------- 5. all layouts
    if dt_opt is not None:
        at = sorted([a for a in agg if a["dt"] == dt_opt], key=lambda a: (a["wall_s"] is None, a["wall_s"] or 0))
        refr = [a for a in at if a["wall_s"]]
        nmin = min([a["np"] for a in refr], default=1)
        tref = min([a["wall_s"] * a["np"] / nmin for a in refr if a["np"] == nmin], default=None)
        D.h(2, f"All layouts at DTMAX = {_fmt_dt(dt_opt)} s")
        trs = []
        for a in at:
            sp = tref / a["wall_s"] if a["wall_s"] and tref else None
            eff = sp / (a["np"] / nmin) * 100 if sp else None
            trs.append([a["mode"].upper(), a["np"], layout_txt(a), _tfmt(a["wall_s"]),
                        _f(a["days_per_hour"], "{:.1f}"), _f(sp, "{:.2f}"), _f(eff, "{:.0f} %"), _measured(a),
                        a["status"]])
        D.table(["Mode", "Cores", "Layout", "Time", "Days/hour", "Speed-up", "Efficiency", "Measured", "Status"],
                trs, ["l", "r", "c", "r", "r", "r", "r", "l", "l"],
                f"Every layout at DTMAX = {_fmt_dt(dt_opt)} s, fastest first; speed-up and efficiency relative to the "
                f"fastest run with {nmin} core(s).")
        both = [a for a in agg if a["wall_clean"] and a["wall_conc"]]
        if both:
            D.table(["Layout", "DTMAX [s]", "Time alone", "Time sharing", "Ratio"],
                    [[a["tag"], _fmt_dt(a["dt"]), _tfmt(a["wall_clean"]), _tfmt(a["wall_conc"]),
                      f"{a['wall_conc'] / a['wall_clean']:.2f}×"] for a in sorted(both, key=lambda a: a["wall_clean"])],
                    ["l", "r", "r", "r", "r"],
                    "Effect of sharing the machine (ratio > 1: slower when other runs compete for memory bandwidth "
                    "and cache).")

    # ---------------------------------------------------------------- 6. schedule + appendix
    D.h(2, "Run schedule")
    D.image(sch, "Which run used which cores and when (red edge = unstable).")
    D.h(2, "Methodology")
    D.ul([
        "One `ww3_shel` per parallel mode, built from the switch file of the case with its parallel switches replaced ("
        + ", ".join(f"{m} `{' '.join(v)}`" for m, v in cfg["mode_switches"].items()
                    if m == "serial" or m in cfg["modes"])
        + "), unless an executable is given in `executables`. The core count and the time step need no rebuild.",
        f"Every run works in its own directory (`work/<run>`): files of `run_dir` copied (small) or linked (large), "
        f"output files left out, edited copies of `{meta.get('grid_file')}` and `{meta.get('shel_file')}`, and the "
        "`mod_def.ww3` written by `ww3_grid` (serial build) for its time steps. `run_dir` is never modified.",
        f"`{meta.get('shel_file')}`: end time = start time + {sim_days:g} days; output requests are unchanged.",
        "Measured time: wall-clock time of `ww3_shel` from launch to process end (`ww3_grid` and `prep_cmds` are not "
        "timed). Each run is pinned to its own block of cores (`taskset`, `OMP_PLACES`, or `srun` job steps).",
        "Instability: NaN / floating-point errors in the output; the run is killed after a grace period and runs with "
        "a larger dt are cancelled. Propagation CFL = cg(f1)·DTXY/Δx with the linear group velocity of the lowest "
        "frequency; " + ("a dt above the limit is marked unstable without running." if cfg["cfl_rule"] == "unstable"
                         else "reported only."),
        "Stability over the simulated period does not guarantee stability under stronger forcing: for production, "
        "keep a margin (≈ 10–20 % below the largest stable dt) and check the fields.",
    ])
    D.h(2, "Appendix: all runs")
    D.table(["Stage", "Mode", "Cores", "Layout", "DTMAX", "Rep", "CPUs", "Concurrent", "Status", "Time [s]",
             "Sim. days", "Notes"],
            [[r["stage"], r["mode"] + (" io" + r["opt"].split("=")[1] if r.get("opt") else ""),
              r["np"], f"{r['nx']}×{r['ny']}", _fmt_dt(r["dt"]) if r.get("dt") is not None else "–", r["rep"],
              r.get("cpus") or "",
              _f(r.get("peers"), "{}"), r["status"], _f(r["wall_s"], "{:.1f}"), _f(r["sim_days"], "{:.3f}"),
              _short_notes(r.get("notes"))] for r in results],
            ["l", "l", "r", "c", "r", "r", "l", "r", "l", "r", "r", "l"],
            "Every run of the benchmark, in order (Layout = MPI ranks × OpenMP threads).")

    rep = out / "benchmark_report.md"
    _write_atomic(rep, D.markdown())
    _write_atomic(out / "benchmark_summary.json", json.dumps(
        {"best": best, "largest_stable_dt": last_ok, "first_unstable": first_fail, "recommended_dt": dt_rec,
         "options": opts, "stability": rows, "meta": meta}, indent=2, default=str))
    if partial:
        return rep
    print(f"[report] {rep}")
    if cfg["latex_report"]:
        tex = out / "benchmark_report.tex"
        _write_atomic(tex, D.latex())
        print(f"[report] {tex}  (compile in {out} with: pdflatex benchmark_report.tex, twice)")
    if cfg["pdf_report"]:
        pdf, how = report_to_pdf(rep, D, f"WAVEWATCH III Benchmark Report  ·  grid '{name}' {grid_txt}")
        if pdf:
            print(f"[report] {pdf}  (via {how})")
    return rep


# ----------------------------------------------------------------------------------------------
# Markdown report -> PDF
# ----------------------------------------------------------------------------------------------
def _md_inline(text: str) -> str:
    """Markdown inline markup -> reportlab paragraph markup."""
    t = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<link href="\2" color="#1c5fb8">\1</link>', t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"<i>\1</i>", t)
    t = re.sub(r"`([^`]+)`", r'<font face="DejaVuMono">\1</font>', t)
    return t


def _pdf_matplotlib(md: str, base: Path, pdf: Path):
    """Last resort: plain text pages + one page per figure (needs only matplotlib)."""
    import textwrap
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
    text_lines, images = [], []
    for ln in md.splitlines():
        m = re.match(r"^\s*!\[[^\]]*\]\(([^)]+)\)", ln)
        if m:
            images.append(base / m.group(1))
            continue
        clean = re.sub(r"\*\*|`", "", ln)
        clean = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", clean)
        text_lines += textwrap.wrap(clean, 110) or [""]
    tmp = pdf.with_name(pdf.stem + ".tmp.pdf")
    with PdfPages(tmp) as pp:
        per = 70
        for k in range(0, len(text_lines), per):
            fig = plt.figure(figsize=(8.27, 11.69))
            fig.text(0.05, 0.97, "\n".join(text_lines[k:k + per]), va="top", ha="left", family="DejaVu Sans Mono",
                     fontsize=7)
            pp.savefig(fig)
            plt.close(fig)
        for p in images:
            if p.exists():
                img = plt.imread(str(p))
                fig = plt.figure(figsize=(11.69, 8.27))
                ax = fig.add_axes([0.02, 0.02, 0.96, 0.96])
                ax.imshow(img)
                ax.axis("off")
                pp.savefig(fig)
                plt.close(fig)
    os.replace(tmp, pdf)


def report_to_pdf(md_path: Path, doc=None, header_text=""):
    """benchmark_report.md -> benchmark_report.pdf (reportlab from the structured report; else pandoc;
    else matplotlib)."""
    pdf = md_path.with_suffix(".pdf")
    md = md_path.read_text()
    errors = []
    try:
        if doc is None:
            raise ImportError("structured report not available")
        doc.pdf(pdf, header_text)
        return pdf, "reportlab"
    except ImportError as e:
        errors.append(f"reportlab not available ({e})")
    except Exception as e:  # noqa: BLE001
        errors.append(f"reportlab failed ({e})")
    if shutil.which("pandoc"):
        for eng in ("xelatex", "wkhtmltopdf", "weasyprint", "pdflatex"):
            if shutil.which(eng):
                r = subprocess.run(["pandoc", md_path.name, "-o", pdf.name, f"--pdf-engine={eng}",
                                    "-V", "geometry:margin=1.5cm"], cwd=md_path.parent,
                                   capture_output=True, text=True)
                if r.returncode == 0 and pdf.exists():
                    return pdf, f"pandoc ({eng})"
                errors.append(f"pandoc/{eng} failed")
    try:
        _pdf_matplotlib(md, md_path.parent, pdf)
        return pdf, "matplotlib (basic layout; install reportlab for a formatted PDF)"
    except Exception as e:  # noqa: BLE001
        errors.append(f"matplotlib failed ({e})")
    print("[warn] PDF not generated: " + "; ".join(errors))
    return None, None


# ----------------------------------------------------------------------------------------------
# main
# ----------------------------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-c", "--config", type=Path, help="JSON configuration file")
    ap.add_argument("--init-config", type=Path, metavar="FILE", help="write an example configuration and exit")
    ap.add_argument("--dry-run", action="store_true", help="show the plan and the file edits, run nothing")
    ap.add_argument("--report-only", action="store_true", help="only rebuild report and figures from results.csv")
    ap.add_argument("--rerun", action="store_true", help="ignore previous results.csv (it is kept as .bak)")
    ap.add_argument("--max-cores", type=int, metavar="N",
                    help="maximum number of cores to use (overrides max_cores in the config)")
    ap.add_argument("--check-nc", metavar="GLOB", help="field check: exit 1 if the variable has NaN or exceeds "
                    "--hs-max in the NetCDF files matching GLOB (use in check_cmd)")
    ap.add_argument("--hs-max", type=float, default=30.0, help="limit for --check-nc (default 30 m)")
    ap.add_argument("--var", default="hs", help="variable for --check-nc (default hs)")
    args = ap.parse_args()
    if args.check_nc:
        sys.exit(check_nc(args.check_nc, args.hs_max, args.var))

    if args.init_config:
        ex = {"_comment": EXAMPLE_COMMENT, **json.loads(json.dumps(DEFAULT_CONFIG))}
        args.init_config.write_text(json.dumps(ex, indent=2) + "\n")
        print(f"[info] example configuration written to {args.init_config}")
        return

    cfg = load_config(args.config)
    if args.max_cores is not None:
        if args.max_cores < 1:
            sys.exit("[error] --max-cores must be >= 1")
        cfg["max_cores"] = args.max_cores
    bench = Bench(cfg, rerun=args.rerun, dry_run=args.dry_run)
    if args.dry_run:
        bench.dry_run()
        return
    out = Path(cfg["output_dir"])
    (out / "config_used.json").write_text(json.dumps(cfg, indent=2))
    if args.report_only:
        write_report(bench.results, cfg, bench.meta, out)
        return

    def _term(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, _term)
    t0 = time.time()
    if cfg["live_report"]:
        bench.live = LiveReport(bench).start()
        print(f"[info] figures and report in {out} are updated after every simulation")
    try:
        bench.go()
    except KeyboardInterrupt:
        print("\n[info] interrupted: partial results kept; run again to resume")
    except WallTimeUp as e:
        print(f"\n[info] {e}: stopping before the Slurm time limit. Results are kept; "
              "submit the same job again to resume.")
    finally:
        bench.cancel_all()
        bench.restore()
        if bench.live:
            bench.live.stop()
            bench.live = None
        write_report(bench.results, cfg, bench.meta, out)
        print(f"[info] total benchmark time {(time.time() - t0) / 3600:.2f} h")


if __name__ == "__main__":
    main()
