# ww3_bench — prompt, sources and step-by-step development

`ww3_bench.py` adapts `croco_bench.py` (same conversation, see its own `steps.md`) to the WAVEWATCH III wave
model.

## 1. Prompt

> Create a similar optimizations script but for the ww3 wave model

"Similar" was taken to mean everything `croco_bench.py` does after the previous 22 prompts:
- the serial time-step search (double while stable, bisect after the first failure, stop after two failures in a
  row, never above an unstable dt, never below a stable dt whose half is stable);
- the exploration of cores from 12, stopping at the first configuration above the efficiency threshold;
- the NLHPC efficiency study;
- concurrency with backfill, large-first order and live figures;
- the Markdown, PDF and LaTeX reports in English;
- Slurm (NLHPC) support;
- a final stage that tests optional settings on the runs with more cores. For WW3 the natural counterpart of the
  XIOS / MPI_NOLAND test is the output server type IOSTYP.

## 2. Sources

### Consulted during the work (17 Nov 2026)
- **WW3 tutorial on time stepping:** NOAA/NCEP, *WW3 Tutorial 4.2: Time stepping* (2013).
  <https://polar.ncep.noaa.gov/waves/workshop/pdfs/WW3-workshop-exercises-day4-timestep.pdf>.
  It describes the four time steps of `ww3_grid.inp` (global, x-y CFL, k-θ, minimum source term). The global
  step must be at least as large as the CFL step. The CFL step is limited by the fastest (lowest-frequency)
  waves. Instability shows up in the fields rather than as a model stop.
- **`ww3_shel.inp` template:** NCEP NWPS, with the time frame and the IOSTYP options 0–3.
  <https://www.nco.ncep.noaa.gov/pmb/codes/nwprod/nwps.v1.4.19/fix/templates/ww3_templates/ww3_shel.inp>.
- **`ww3_grid.inp` example:** NCEP HAFS, with the time-step line, the spectrum line and the RECT grid
  definition.
  <https://www.nco.ncep.noaa.gov/pmb/codes/nwprod/hafs.v2.0.8/sorc/hafs_ww3.fd/model/inp/ww3_grid.inp>.
- **Parallel implementation of WW3:** Waves short course, Brest 2014. It covers `SHRD` versus `DIST MPI`, the
  distribution of grid points over processes, and IOSTYP and output servers.
  <https://data-ww3.ifremer.fr/COURS/WAVES_SHORT_COURSE/LECTURES/DAY_4/brest_fall_2014_parallel.pdf>.
- **WW3 CMake build:** `-DSWITCH=` selects the switch file.
  <https://data-ww3.ifremer.fr/TRAINING/MODEL/2022/WW3/CMakeLists.txt>.
- **Switch handling in an operational build** (`DIST MPI` ↔ `SHRD`, removal of `OMPG OMPH OMPX`): NCEP HWRF
  `source_CPL`. <https://www.nco.ncep.noaa.gov/pmb/codes/nwprod/hwrf.v13.2.9/sorc/hwrf_ww3.fd/source_CPL>.
- **Hybrid MPI-OpenMP in WW3:** J.-G. Li (2021), *Hybrid multi-grid parallelisation of WAVEWATCH III model on
  SMC grids*, 19th ECMWF Workshop on HPC in Meteorology.
  <https://events.ecmwf.int/event/169/contributions/2777>.
- **Namelist names** (`DOMAIN%IOSTYP`, `DOMAIN%START/STOP`): CESM WW3 namelist definitions,
  <https://docs.cesm.ucar.edu/models/cesm3/settings/current/ww3_nml.html>, and pyww3,
  <https://pyww3.readthedocs.io/en/latest/_modules/pyww3/shel.html>.
- **NLHPC efficiency study** (S(n), E(n), threshold 0.5): <https://wiki.nlhpc.cl/Estudio_de_Eficiencia>.

### Background knowledge (not fetched)
- **Linear wave theory:** dispersion ω² = g k tanh(kh) and group velocity cg = n·ω/k with
  n = ½(1 + 2kh/sinh 2kh), used for the CFL number.
- **WW3 user manual** (Tolman and the WW3 development group, versions 6–7): structure of `ww3_grid`,
  `ww3_shel`, `ww3_strt`, `ww3_prnc`, `ww3_ounf`; names of the output files.

## 3. Step-by-step development
1. **Research.** The searches above settled four things:
   - which files hold the time steps, run length and IOSTYP, in both the `.inp` and `.nml` formats;
   - how a parallel build is selected (switch file);
   - that WW3 decomposes over sea points (no x/y layout);
   - that a too-long time step seldom stops the model.
2. **Architecture.** The engine of `croco_bench.py` was reused unchanged:
   - core scheduler, backfill, Slurm job steps and walltime guard;
   - resume from `results.csv`, live reports;
   - time-step search, exploration with the threshold stop, efficiency study;
   - report classes (Markdown, reportlab PDF, LaTeX).

   The model layer was written anew:
   - switch editing, with one build per mode (CMake template, or given executables);
   - parsers and editors for `ww3_grid.inp` / `.nml` and `ww3_shel.inp` / `.nml`: positional data lines with `$`
     comments, and namelists with `!` comments;
   - `ww3_grid` once per dt, with a cached `mod_def.ww3`;
   - per-run directories that copy or link `run_dir` but never link output names;
   - layouts as ranks × threads.
3. **Stability.** Four criteria:
   - NaN / floating-point errors in the output, with the run killed after a grace period;
   - the propagation CFL of the lowest frequency, computed from the spectrum, the RECT grid and the bottom file,
     with depth-dependent group velocity (a dt above the limit is not run);
   - an optional field check (`check_cmd`, with the built-in `--check-nc` for Hs);
   - crashes recorded as errors.
4. **Stage 4.** IOSTYP variants on the runs above the stop point, with the same comparison table and figure as
   the XIOS / MPI_NOLAND stage of `croco_bench.py`.
5. **Mock model for testing.** A fake CMake build reads the switch file, rejects `SHRD` + `DIST`, and writes a
   fake `ww3_shel` and `ww3_grid`.
   - The fake `ww3_shel` has a cost model (propagation sub-steps, source terms, output cost growing with the ranks
     unless IOSTYP 2/3) and writes dated progress lines.
   - It produces NaN when the CFL exceeds 1.15, and checks that MPI builds are launched with ranks and serial
     builds without threads.
   - Two cases were used: `.inp` (v6 style) and `.nml` (v7 style).
6. **Tests:**
   - **Full run on 16 virtual cores** (MPI, OpenMP, hybrid):
     - the dt search from 900 s found the stable limit at 2362 s, with the CFL-rejected dt marked "not run";
     - optimal dt 1800 s;
     - every mode stopped at 4 cores (E > 0.6);
     - IOSTYP 2 put MPI 6 and 8 cores above the threshold.
   - **Namelist case:** NaN detection in the log, and `check_cmd` failures counted as unstable.
   - **Fake Slurm:** 16/16 CPUs at most, 0 over-subscriptions, correct `-n`/`-c` for each mode.
   - **Walltime stop** under Slurm.
   - **Given executables** together with a failed hybrid build (recorded and reported).
   - **SIGTERM:** no orphan processes, and the resume repeated no run.
   - **Sources:** `run_dir` checksums unchanged in every test.
   - **Reports:** PDF pages inspected, and the LaTeX compiled without errors.

**Not done:** a run against a real WW3 build. Start with `--dry-run`. Then check the switch of each build, the
handling of every file of `run_dir`, the time-step and end-time edits, and the CFL table. Finally, try a short
`sim_days`.

## 4. Files delivered

| File | Content |
|---|---|
| `ww3_bench.py` | The benchmark tool (single Python file). |
| `bench_example.json` | Example configuration for a 16-core workstation. |
| `run_ww3_bench_nlhpc.bash`, `bench_hpc.json` | Slurm job script and configuration for one NLHPC node. |
| `README.md` | User documentation. |
| `steps.md` | This document. |
| `example_output/` | Report (`.md`, `.pdf`, `.tex`), figures and CSVs produced against the mock WW3 — format only, not real results. |

## How to cite

This tool and its documentation were generated with an AI assistant:

> Anthropic. (2026). *Claude* [Large language model]. Conversation of 22 October – 17 November 2026 producing
> `croco_bench.py` and `ww3_bench.py`. https://claude.ai
