# ww3_bench: find the most efficient time step and core count for WAVEWATCH III

`ww3_bench.py` is the WAVEWATCH III (WW3) version of `croco_bench.py`. It builds `ww3_shel` for each parallel
mode, edits the time steps and the run length, launches simulations of **1 day** (configurable with
`sim_days`), measures the wall-clock time and decides what to test next:

| What changes | File | Variable |
|---|---|---|
| Parallel method | switch file | `SHRD` (serial) · `DIST MPI` (MPI) · `SHRD OMPG` (OpenMP) · `DIST MPI OMPG OMPH` (hybrid) |
| Number of cores | launch command | MPI ranks (`mpirun -np` / `srun -n`), OpenMP threads (`OMP_NUM_THREADS`), or ranks × threads |
| Time step | `ww3_grid.inp` or `ww3_grid.nml` | `DTMAX`, `DTXY`, `DTKTH`, `DTMIN` (then `ww3_grid` writes `mod_def.ww3`) |
| Run length | `ww3_shel.inp` or `ww3_shel.nml` | end time = start time + `sim_days` |
| Output server (stage 4) | `ww3_shel.inp` or `ww3_shel.nml` | `IOSTYP` |

**What is different from CROCO:**
- **No x/y layout.** WW3 distributes the sea points over the MPI ranks by itself, so a core count is one layout
  (OpenMP threads, or ranks × threads in hybrid mode).
- **No rebuild per core count or dt.** Only one build per parallel mode is needed: at most 4 builds in total.
- **Four time steps.** The search variable is the global step DTMAX. DTXY and DTKTH keep their ratio to it
  (`timestep_mode: "proportional"`). DTMIN stays fixed, capped at DTMAX (`dtmin_mode: "fixed"`).
- **No `BLOW UP` message.** WW3 rarely stops when its time step is too long; its fields become noisy or NaN.
  See *Stability* below.

It writes the following outputs:
- `results.csv`;
- `benchmark_summary.png`, `cfl_vs_dt.png`, `schedule.png`;
- `efficiency_study.png` / `.csv` (efficiency study in the NLHPC format);
- `options_efficiency.png`, `options_study.csv` (IOSTYP, stage 4);
- `benchmark_report.md`, `.pdf` and `.tex`.

Figures and report are refreshed after every simulation. **The files in `run_dir` are never modified.**

## Requirements
- Python ≥ 3.8 with `numpy` and `matplotlib`; `reportlab` for the formatted PDF; `netCDF4` or `scipy` only for
  `--check-nc`.
- WW3 sources with the CMake build (v7 and later), or executables already built (see `executables`).
- `mpirun` (OpenMPI or MPICH) or Slurm `srun`; `taskset` to pin each run to its cores (optional).

## Usage
```bash
python3 ww3_bench.py --init-config bench.json   # all options, with their defaults
# edit run_dir, switch_file, ww3_dir (or executables), dt_ref, max_cores, ref_cores, ...
python3 ww3_bench.py -c bench.json --dry-run    # plan, file edits, CFL table; nothing is run
python3 ww3_bench.py -c bench.json              # run (resumes if results.csv exists)
python3 ww3_bench.py -c bench.json --report-only
python3 ww3_bench.py -c bench.json --max-cores 8
```
`run_dir` is the directory where `ww3_shel` normally runs. It holds the grid and shell inputs, the switch file,
the bottom file, the forcing already prepared by `ww3_prnc` (`wind.ww3`, …) and the initial conditions
(`restart.ww3`, or a `prep_cmds` entry that runs `ww3_strt`).

## Builds
For each mode the switch file of the case is copied with its parallel switches (`parallel_switches`: `SHRD
DIST MPI OMPG OMPH OMPX`) replaced by those of `mode_switches`. It is then compiled with `compile_cmd` in
`<output_dir>/builds/<mode>`. The default command is the WW3 CMake build:

```
cmake -S {ww3_dir} -B {build_dir} -DSWITCH={switch} -DCMAKE_INSTALL_PREFIX={build_dir}/install ...
cmake --build {build_dir} --target install -j {jobs}
```

- `ww3_grid` comes from the serial build. It writes one `mod_def.ww3` per time step, cached in `moddef/dt<dt>/`.
- **Already built executables:** with `executables`, e.g. `{"serial": ".../ww3_shel", "grid": ".../ww3_grid",
  "mpi": ".../ww3_shel"}`, those modes are not compiled. This is the way to go with WW3 v6 (`w3_setup` /
  `w3_make`), or with a cluster module that provides an MPI `ww3_shel`.
- **A failed build** is recorded (`COMPILE_FAIL` in `results.csv`, warning in the report); the other modes go on.

## Stage 1: time step, with the serial run
- dt = DTMAX starts at `dt_ref` (default: the value in the grid input) and is doubled while stable.
- After the first unstable run, the next dt is the midpoint between the last stable and the last unstable dt.
  The search stops after **two unstable runs in a row**.
- Rules:
  - a dt above an unstable one is never tested;
  - when going down, never below a stable dt whose half is also stable.
- Up to 2 serial runs at once (`dt_speculation: "strict"`).
- The optimal dt is the largest integer dt ≤ the largest stable dt with 3600/dt an integer. T(1), the serial run
  at that dt, is measured alone.

### Stability
A run is **unstable** when:
1. The output of `ww3_shel` or `log.ww3` shows `NaN` or floating-point errors (`unstable_regex`). The run is
   killed after `blowup_grace_s`.
2. The **propagation CFL number** of the lowest frequency, CFL = cg(f1) · DTXY / Δx, exceeds `cfl_limit` (1.0)
   and `cfl_rule` is `"unstable"` (the default). Such a dt is marked unstable without running. Use `"warn"` to run
   it anyway and only report the number, or `"off"`.
   - cg(f1) is the linear group velocity of the first frequency of the spectrum, the fastest component, computed
     for every wet depth of the bottom file. If the bottom file cannot be read, it is the maximum over all depths
     (≈ 1.2 × the deep-water value).
   - Δx is the smallest grid step (at the highest latitude for spherical grids).
   - Only RECT grids are supported; for curvilinear or unstructured grids the CFL is not computed.
3. `check_cmd` exits with a non-zero code. It runs in the run directory after the model and is not timed. For
   example, after converting the fields with `ww3_ounf`:
   ```json
   "check_cmd": "{grid_dir}/ww3_ounf > ounf.log && python3 {bench} --check-nc 'ww3.*.nc' --hs-max 25"
   ```
   `--check-nc` fails on NaN or on Hs above the limit.

## Stage 2: number of cores
- Each mode starts at `ref_cores` (12) cores:
  - **MPI**: n ranks;
  - **OpenMP**: n threads;
  - **hybrid**: n = ranks × threads for each value of `hybrid_threads` (at least 2 ranks; the fastest is kept).
- Efficiency **E(n) = T(1) / (n · T(n))**. Each mode **stops at the first core count with E > 0.5**
  (`efficiency_threshold`). Otherwise the next test uses 2 fewer cores (`core_step`), down to 2.
- By default the runs of this stage go one at a time (`explore_exclusive`).

## Stage 3: re-timing
With `explore_exclusive: false`, efficiency points measured while sharing the machine are re-timed alone
(`efficiency_exclusive`).

## Stage 4: output server type (IOSTYP)
The runs with **more cores than the stop configuration** are repeated with each value of `iostyp_tests`
(default 2 and 3; `option_modes`, default MPI). If the mode stopped at `ref_cores`, `ref_cores + core_step` is
used.

| IOSTYP | Meaning |
|---|---|
| 0 | No server; every process writes directly (needs a parallel file system such as GPFS) |
| 1 | No server; one process writes each output type (the usual choice) |
| 2 | The last process is reserved for all output |
| 3 | Several dedicated output processes |

The cores used do not change, so E = T(1) / (n · T). The report lists the time, E, ΔE and the speed of each
variant against the baseline, and whether it crosses the threshold. `iostyp_tests: []` disables the stage.

## Run directories
Every run works in `work/<run>/`:
- files of `run_dir` smaller than `copy_below_mb` are copied, larger ones (forcing) and directories are
  symlinked;
- names that match `output_globs` (`out_grd.*`, `log.*`, `restart001.ww3`, `mod_def.ww3`, …) are left out, so WW3
  never writes through a link into `run_dir`;
- edited copies of the grid and shell inputs, and `mod_def.ww3` linked from the cache.

Large output files are deleted after each run unless `keep_outputs` is true.

## HPC clusters (Slurm, e.g. NLHPC)
`run_ww3_bench_nlhpc.bash` submits the whole benchmark as one job on one node (`--exclusive`). With
`launcher: "auto"` (or `"slurm"`) every run is an `srun` job step:
- MPI: `srun -n {ranks} -c 1`;
- OpenMP: `srun -n 1 -c {threads}`;
- hybrid: `srun -n {ranks} -c {threads}`;

all with `--exact --cpu-bind=cores` (`slurm_step_flags`), so simultaneous steps never share cores. Before each
launch the remaining wall time is checked (`walltime_margin_s`). When it runs out, the job stops cleanly, and
submitting it again resumes the benchmark.

## Important options
- `run_cmd` / `env`: templates per mode with `{exe}`, `{np}`, `{ranks}`, `{threads}`, `{cpus}` and `{places}`.
  `env` is merged per mode.
- `prep_cmds`: commands run in each run directory before the timed run (e.g. `["{grid_bin}/ww3_strt"]`).
- `timestep_mode` / `dtmin_mode`: how DTXY, DTKTH and DTMIN follow DTMAX.
- `copy_below_mb`, `output_globs`: how `run_dir` is reproduced in each run directory.
- `max_cores`, `cpu_list`, `reserve_cores`, `max_parallel_jobs`, `backfill`: the core scheduler (as in croco_bench).

## Assumptions to check for your case
- **`ww3_grid.inp`:** the time steps are the 4th data line, and the grid definition follows `END OF NAMELISTS`
  (standard v6 layout).
- **`ww3_shel.inp`:** the first two `yyyymmdd hhmmss` pairs are the start and end times, and IOSTYP is the line
  that follows.
- **Namelists:** `TIMESTEPS%…`, `DOMAIN%START/STOP/IOSTYP`.
- **Forcing and initial conditions:** they must already exist in `run_dir` and cover `sim_days`.
- **Switch-independent `mod_def.ww3`:** the one written by the serial `ww3_grid` is used by every build. Its
  switches differ from the other builds only in the parallel switches.
- **`--dry-run` first:** it shows the edits, the switch of every build, how each file of `run_dir` is handled and
  the CFL number of each dt.
