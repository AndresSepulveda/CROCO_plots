# WAVEWATCH III Benchmark Report

*grid 'MOCK SE PACIFIC 0.25 DEG' 60 × 40  ·  1 day per run  ·  2026-11-17 13:39*

| | |
|:---|:---|
| **Grid** | `ww3_grid.inp`: 'MOCK SE PACIFIC 0.25 DEG', RECT 60 × 40 (spherical) |
| **Spectrum** | 32 frequencies × 24 directions (f1 = 0.035 Hz, factor 1.1) |
| **Original time steps** | DTMAX / DTXY / DTKTH / DTMIN = 900.0 / 300.0 / 450.0 / 15.0 s |
| **Switch file** | `F90 NOGRB NC4 TRKNC DIST MPI PR3 UQ FLX0 LN1 ST4 STAB0 NL1 BT4 DB1 MLIM TR0 BS0 IC0 IS0 REF0 XX0 WNT2 WNX1 RWND CRT1 CRX1 TIDE O0 O1 O2 O3 O4 O5 O6 O7` |
| **Machine** | `vm`: Intel(R) Xeon(R) Processor @ 2.10GHz; 2 physical / 2 logical CPUs |
| **Cores used** | 16 (CPU 0-15), up to 16 simultaneous runs |
| **Run directory** | `/home/claude/mockww3/case` |
| **Simulated period** | 1 day per run from 2023-06-01 00:00:00 (`ww3_shel.inp`); output server type IOSTYP = 1 |

## Key results

| Result | Value | Detail |
|:---|:---|:---|
| Recommended DTMAX | **1800 s** | DTXY 600.0 s; 3600 / 2; largest stable 2362 s |
| Best IOSTYP variant | **IOSTYP = 2** | MPI 8 cores, E = 0.607 > 0.6 |
| Recommended cores · HYBRID | **4 cores** | 2 × 2, E = 0.686 |
| Recommended cores · MPI | **4 cores** | 4 ranks, E = 0.621 |
| Recommended cores · OPENMP | **4 cores** | 4 threads, E = 0.668 |
| Fastest run | **OPENMP 12 cores** | 12 threads, 2.8 s per 1 day |
| Propagation CFL at recommended dt | **0.753** | cg(f1)·DTXY/dx; limit 1; first unstable DTMAX 2390 s |
| Serial reference T(1) | **12.1 s** | 1 core, SHRD build, DTMAX = 1800 s |

- **Recommended global time step: DTMAX = 1800 s** = 3600 / 2, the largest integer dt that divides 3600 without exceeding the largest stable dt; with it DTXY = 600.0 s, DTKTH = 900.0 s, DTMIN = 15.0 s. All times and efficiencies were measured with it.
- **Largest stable DTMAX found:** 2362 s (DTXY = 787.333 s, propagation CFL 0.989).
- **Stability limit** between 2362 s (stable) and 2390 s (first unstable dt, decided from the CFL number without running).
- **HYBRID:** up to **4 cores** (2 × 2, efficiency 0.686 > 0.6).
- **MPI:** up to **4 cores** (4 ranks, efficiency 0.621 > 0.6).
- **OPENMP:** up to **4 cores** (4 threads, efficiency 0.668 > 0.6).
- **Output server:** IOSTYP = 2 raises the efficiency of the 8-core MPI run to 0.607 (baseline 0.335): above the threshold 0.6.
- **Fastest configuration:** OPENMP with 12 cores (12 threads), 2.8 s per 1 day (1268.5 simulated days per wall-clock hour), measured alone on the machine.

## Time-step search (serial run)

All runs of this stage use the serial build (1 core, `SHRD`). The search variable is the global time step DTMAX; DTXY and DTKTH keep their ratio to DTMAX, DTMIN stays as in the grid input (capped at DTMAX), and `ww3_grid` writes a new `mod_def.ww3` for each dt. Starting from the reference dt (900 s), dt is doubled while the run is stable; after the first unstable run the next dt is the midpoint between the last stable and the last unstable dt, and the search stops after two unstable runs in a row. A dt larger than an unstable one is never tested, and when going down the search never goes below a stable dt whose half is also stable.

**Unstable** means: NaN or floating-point errors in the output of `ww3_shel` or in `log.ww3`; a propagation CFL number above 1 (such a dt is not run). WW3 seldom stops when its time step is too long, so a run that ends normally is not proof of stability.

*Table 1. Decision sequence of the time-step search.*

| Step | Phase | DTMAX [s] | Result |
|---:|:---|---:|:---|
| 1 | up | 900 | stable |
| 2 | up | 1800 | stable |
| 3 | up | 3600 | unstable |
| 4 | bisect | 2700 | unstable |
| 5 | bisect | 2250 | stable |
| 6 | bisect | 2475 | unstable |
| 7 | bisect | 2362 | stable |
| 8 | bisect | 2418 | unstable |
| 9 | bisect | 2390 | unstable |

*Table 2. Time steps, stability and propagation Courant numbers for every dt tested (★ = recommended dt).*

| DTMAX [s] | DTXY [s] | DTKTH [s] | DTMIN [s] | Status | CFL x | CFL y | Best time |
|---:|---:|---:|---:|:---|---:|---:|---:|
| 900 | 300 | 450 | 15 | stable | 0.377 | 0.289 | 23.1 s |
| 1800 ★ | 600 | 900 | 15 | stable | 0.753 | 0.577 | 2.8 s |
| 2250 | 750 | 1125 | 15 | stable | 0.942 | 0.721 | 9.8 s |
| 2362 | 787.333 | 1181 | 15 | stable | 0.989 | 0.757 | 9.4 s |
| 2390 | 796.667 | 1195 | 15 | unstable (CFL, not run) | 1.000 | 0.766 | – |
| 2418 | 806 | 1209 | 15 | unstable (CFL, not run) | 1.012 | 0.775 | – |
| 2475 | 825 | 1237.5 | 15 | unstable (CFL, not run) | 1.036 | 0.794 | – |
| 2700 | 900 | 1350 | 15 | unstable (CFL, not run) | 1.130 | 0.866 | – |
| 3600 | 1200 | 1800 | 15 | unstable (CFL, not run) | 1.507 | 1.154 | – |

Propagation CFL = cg(f1) · DTXY / Δ, with cg(f1) = 26.74 m/s the largest group velocity of the lowest frequency f1 = 0.035 Hz (bottom file bottom.inp (2280 wet points, h_max 3920 m)), Δx_min = 21.30 km (at the highest latitude for spherical grids) and Δy = 27.80 km.

![Propagation Courant numbers versus time step; the dashed lines mark the largest stable dt and the first unstable dt.](cfl_vs_dt.png)

*Figure 1. Propagation Courant numbers versus time step; the dashed lines mark the largest stable dt and the first unstable dt.*

## Core-count exploration

Each parallel mode starts at 12 cores. MPI uses n ranks (WW3 distributes the sea points over the ranks), OpenMP n threads, and hybrid n = ranks × threads for each value of `hybrid_threads` (the fastest is kept). With E(n) = T(1) / (n · T(n)): each mode **stops at the first core count with E > 0.6** (that configuration is its result); otherwise the next test uses 2 fewer cores, down to 2.

*Table 3. MPI exploration path (stop: E = 0.621 > 0.6 at 4 cores).*

| Cores | Best layout | Time | Efficiency E | Decision |
|---:|:---:|---:|---:|:---|
| 12 | 12 ranks | 5.0 s | 0.200 | E ≤ 0.6 → −2 |
| 10 | 10 ranks | 4.7 s | 0.255 | E ≤ 0.6 → −2 |
| 8 | 8 ranks | 4.5 s | 0.335 | E ≤ 0.6 → −2 |
| 6 | 6 ranks | 4.5 s | 0.450 | E ≤ 0.6 → −2 |
| 4 | 4 ranks | 4.9 s | 0.621 | E > 0.6 → stop |

*Table 4. OPENMP exploration path (stop: E = 0.668 > 0.6 at 4 cores).*

| Cores | Best layout | Time | Efficiency E | Decision |
|---:|:---:|---:|---:|:---|
| 12 | 12 threads | 2.8 s | 0.354 | E ≤ 0.6 → −2 |
| 10 | 10 threads | 3.0 s | 0.401 | E ≤ 0.6 → −2 |
| 8 | 8 threads | 3.3 s | 0.463 | E ≤ 0.6 → −2 |
| 6 | 6 threads | 3.7 s | 0.547 | E ≤ 0.6 → −2 |
| 4 | 4 threads | 4.5 s | 0.668 | E > 0.6 → stop |

*Table 5. HYBRID exploration path (stop: E = 0.686 > 0.6 at 4 cores).*

| Cores | Best layout | Time | Efficiency E | Decision |
|---:|:---:|---:|---:|:---|
| 12 | 6 × 2 | 3.4 s | 0.291 | E ≤ 0.6 → −2 |
| 10 | 5 × 2 | 3.4 s | 0.356 | E ≤ 0.6 → −2 |
| 8 | 4 × 2 | 3.4 s | 0.438 | E ≤ 0.6 → −2 |
| 6 | 3 × 2 | 3.7 s | 0.547 | E ≤ 0.6 → −2 |
| 4 | 2 × 2 | 4.4 s | 0.686 | E > 0.6 → stop |

![(a) run time versus dt, (b) scaling and (c) parallel efficiency at dt = 1800 s, (d) every layout tested.](benchmark_summary.png)

*Figure 2. (a) run time versus dt, (b) scaling and (c) parallel efficiency at dt = 1800 s, (d) every layout tested.*

## Efficiency study (NLHPC format)

Format of the [NLHPC efficiency study](https://wiki.nlhpc.cl/Estudio_de_Eficiencia), at DTMAX = 1800 s and 1 day simulated, with the best layout of each core count: **speed-up** S(n) = T(1) / T(n), **efficiency** E(n) = S(n) / n. T(1) is the serial run (1 core, built with `SHRD`). Recommended: the largest core count with E > 0.6.

*Table 6. HYBRID: recommended **4 cores**.*

| No. of cores | 1 | 4 | 6 | 8 | 10 | 12 |
|:---|---:|---:|---:|---:|---:|---:|
| Layout | serial | 2 × 2 | 3 × 2 | 4 × 2 | 5 × 2 | 6 × 2 |
| Time [s] | 12.05 | 4.39 | 3.67 | 3.44 | 3.38 | 3.45 |
| Speed-up | 1.00 | 2.75 | 3.28 | 3.51 | 3.56 | 3.50 |
| Efficiency | **1.00** | **0.69** | 0.55 | 0.44 | 0.36 | 0.29 |
| Measured alone | yes | yes | yes | yes | yes | yes |

*Table 7. MPI: recommended **4 cores**.*

| No. of cores | 1 | 4 | 6 | 8 | 10 | 12 |
|:---|---:|---:|---:|---:|---:|---:|
| Layout | serial | 4 ranks | 6 ranks | 8 ranks | 10 ranks | 12 ranks |
| Time [s] | 12.05 | 4.86 | 4.46 | 4.50 | 4.72 | 5.02 |
| Speed-up | 1.00 | 2.48 | 2.70 | 2.68 | 2.55 | 2.40 |
| Efficiency | **1.00** | **0.62** | 0.45 | 0.33 | 0.26 | 0.20 |
| Measured alone | yes | yes | yes | yes | yes | yes |

*Table 8. OPENMP: recommended **4 cores**.*

| No. of cores | 1 | 4 | 6 | 8 | 10 | 12 |
|:---|---:|---:|---:|---:|---:|---:|
| Layout | serial | 4 threads | 6 threads | 8 threads | 10 threads | 12 threads |
| Time [s] | 12.05 | 4.51 | 3.67 | 3.25 | 3.01 | 2.84 |
| Speed-up | 1.00 | 2.67 | 3.28 | 3.70 | 4.01 | 4.25 |
| Efficiency | **1.00** | **0.67** | 0.55 | 0.46 | 0.40 | 0.35 |
| Measured alone | yes | yes | yes | yes | yes | yes |

![Speed-up (left, with the ideal line) and parallel efficiency (right, with the threshold); stars mark the recommended core count of each mode.](efficiency_study.png)

*Figure 3. Speed-up (left, with the ideal line) and parallel efficiency (right, with the threshold); stars mark the recommended core count of each mode.*

## Output server type (IOSTYP)

After the stop point of the exploration (MPI 4 cores), the runs with more cores (MPI 6, 8, 10, 12) are repeated at the same dt with other output server types in `ww3_shel.inp` (baseline IOSTYP = 1). IOSTYP = 0: no server, every process writes directly (needs a parallel file system); 1: no server; 2: the last process is reserved for output; 3: several dedicated output processes. The cores used do not change, so E = T(1) / (n · T).

*Table 9. Runs above the stop point with each output server type (Speed > 1: the variant is faster).*

| Mode | Cores | Variant | Layout | Time | E | ΔE vs baseline | Speed vs baseline | E > 0.6 |
|:---|---:|:---|:---:|---:|---:|---:|---:|:---:|
| MPI | 6 | IOSTYP = 1 (baseline) | 6 ranks | 4.5 s | 0.450 | — | — | no |
| MPI | 6 | IOSTYP = 2 | 6 ranks | 3.1 s | **0.645** | +0.195 | 1.43× | yes |
| MPI | 6 | IOSTYP = 3 | 6 ranks | 3.8 s | 0.530 | +0.080 | 1.18× | no |
| MPI | 8 | IOSTYP = 1 (baseline) | 8 ranks | 4.5 s | 0.335 | — | — | no |
| MPI | 8 | IOSTYP = 2 | 8 ranks | 2.5 s | **0.607** | +0.272 | 1.81× | yes |
| MPI | 8 | IOSTYP = 3 | 8 ranks | 2.8 s | 0.533 | +0.198 | 1.59× | no |
| MPI | 10 | IOSTYP = 1 (baseline) | 10 ranks | 4.7 s | 0.255 | — | — | no |
| MPI | 10 | IOSTYP = 2 | 10 ranks | 2.1 s | 0.567 | +0.312 | 2.22× | no |
| MPI | 10 | IOSTYP = 3 | 10 ranks | 2.3 s | 0.514 | +0.258 | 2.01× | no |
| MPI | 12 | IOSTYP = 1 (baseline) | 12 ranks | 5.0 s | 0.200 | — | — | no |
| MPI | 12 | IOSTYP = 2 | 12 ranks | 1.9 s | 0.527 | +0.327 | 2.64× | no |
| MPI | 12 | IOSTYP = 3 | 12 ranks | 2.1 s | 0.487 | +0.287 | 2.44× | no |

![Efficiency of each IOSTYP variant; the dashed line is the threshold.](options_efficiency.png)

*Figure 4. Efficiency of each IOSTYP variant; the dashed line is the threshold.*

## All layouts at DTMAX = 1800 s

*Table 10. Every layout at DTMAX = 1800 s, fastest first; speed-up and efficiency relative to the fastest run with 1 core(s).*

| Mode | Cores | Layout | Time | Days/hour | Speed-up | Efficiency | Measured | Status |
|:---|---:|:---:|---:|---:|---:|---:|:---|:---|
| OPENMP | 12 | 12 threads | 2.8 s | 1268.5 | 4.25 | 35 % | alone | OK |
| OPENMP | 10 | 10 threads | 3.0 s | 1197.6 | 4.01 | 40 % | alone | OK |
| OPENMP | 8 | 8 threads | 3.3 s | 1106.0 | 3.70 | 46 % | alone | OK |
| HYBRID | 10 | 5 × 2 | 3.4 s | 1063.5 | 3.56 | 36 % | alone | OK |
| HYBRID | 8 | 4 × 2 | 3.4 s | 1047.4 | 3.51 | 44 % | alone | OK |
| HYBRID | 12 | 6 × 2 | 3.4 s | 1044.4 | 3.50 | 29 % | alone | OK |
| HYBRID | 6 | 3 × 2 | 3.7 s | 979.9 | 3.28 | 55 % | alone | OK |
| OPENMP | 6 | 6 threads | 3.7 s | 979.6 | 3.28 | 55 % | alone | OK |
| HYBRID | 4 | 2 × 2 | 4.4 s | 820.0 | 2.75 | 69 % | alone | OK |
| MPI | 6 | 6 ranks | 4.5 s | 807.0 | 2.70 | 45 % | alone | OK |
| MPI | 8 | 8 ranks | 4.5 s | 800.2 | 2.68 | 33 % | alone | OK |
| OPENMP | 4 | 4 threads | 4.5 s | 797.9 | 2.67 | 67 % | alone | OK |
| MPI | 10 | 10 ranks | 4.7 s | 762.7 | 2.55 | 26 % | alone | OK |
| MPI | 4 | 4 ranks | 4.9 s | 741.4 | 2.48 | 62 % | alone | OK |
| MPI | 12 | 12 ranks | 5.0 s | 716.6 | 2.40 | 20 % | alone | OK |
| SERIAL | 1 | serial | 12.1 s | 298.7 | 1.00 | 100 % | alone | OK |

## Run schedule

![Which run used which cores and when (red edge = unstable).](schedule.png)

*Figure 5. Which run used which cores and when (red edge = unstable).*

## Methodology

- One `ww3_shel` per parallel mode, built from the switch file of the case with its parallel switches replaced (serial `SHRD`, mpi `DIST MPI`, openmp `SHRD OMPG`, hybrid `DIST MPI OMPG OMPH`), unless an executable is given in `executables`. The core count and the time step need no rebuild.
- Every run works in its own directory (`work/<run>`): files of `run_dir` copied (small) or linked (large), output files left out, edited copies of `ww3_grid.inp` and `ww3_shel.inp`, and the `mod_def.ww3` written by `ww3_grid` (serial build) for its time steps. `run_dir` is never modified.
- `ww3_shel.inp`: end time = start time + 1 days; output requests are unchanged.
- Measured time: wall-clock time of `ww3_shel` from launch to process end (`ww3_grid` and `prep_cmds` are not timed). Each run is pinned to its own block of cores (`taskset`, `OMP_PLACES`, or `srun` job steps).
- Instability: NaN / floating-point errors in the output; the run is killed after a grace period and runs with a larger dt are cancelled. Propagation CFL = cg(f1)·DTXY/Δx with the linear group velocity of the lowest frequency; a dt above the limit is marked unstable without running.
- Stability over the simulated period does not guarantee stability under stronger forcing: for production, keep a margin (≈ 10–20 % below the largest stable dt) and check the fields.

## Appendix: all runs

*Table 11. Every run of the benchmark, in order (Layout = MPI ranks × OpenMP threads).*

| Stage | Mode | Cores | Layout | DTMAX | Rep | CPUs | Concurrent | Status | Time [s] | Sim. days | Notes |
|:---|:---|---:|:---:|---:|---:|:---|---:|:---|---:|---:|:---|
| dt-search | serial | 1 | 1×1 | 900 | 0 | 0 | 0 | OK | 23.1 | 1.000 |  |
| dt-search | serial | 1 | 1×1 | 1800 | 0 | 0 | 0 | OK | 12.1 | 1.000 |  |
| dt-search | serial | 1 | 1×1 | 3600 | 0 |  | 0 | UNSTABLE | – | – | propagation CFL 1.51 > 1 (not run) |
| dt-search | serial | 1 | 1×1 | 2700 | 0 |  | 0 | UNSTABLE | – | – | propagation CFL 1.13 > 1 (not run) |
| dt-search | serial | 1 | 1×1 | 2250 | 0 | 1 | 1 | OK | 9.8 | 1.000 |  |
| dt-search | serial | 1 | 1×1 | 2475 | 0 |  | 0 | UNSTABLE | – | – | propagation CFL 1.04 > 1 (not run) |
| dt-search | serial | 1 | 1×1 | 2362 | 0 | 1 | 1 | OK | 9.4 | 1.000 |  |
| dt-search | serial | 1 | 1×1 | 2418 | 0 |  | 0 | UNSTABLE | – | – | propagation CFL 1.01 > 1 (not run) |
| dt-search | serial | 1 | 1×1 | 2390 | 0 |  | 0 | UNSTABLE | – | – | propagation CFL 1.00 > 1 (not run) |
| explore | mpi | 12 | 12×1 | 1800 | 0 | 0-11 | 0 | OK | 5.0 | 1.000 |  |
| explore | openmp | 12 | 1×12 | 1800 | 0 | 0-11 | 0 | OK | 2.8 | 1.000 |  |
| explore | hybrid | 12 | 6×2 | 1800 | 0 | 0-11 | 0 | OK | 3.4 | 1.000 |  |
| explore | mpi | 10 | 10×1 | 1800 | 0 | 0-9 | 0 | OK | 4.7 | 1.000 |  |
| explore | openmp | 10 | 1×10 | 1800 | 0 | 0-9 | 0 | OK | 3.0 | 1.000 |  |
| explore | hybrid | 10 | 5×2 | 1800 | 0 | 0-9 | 0 | OK | 3.4 | 1.000 |  |
| explore | mpi | 8 | 8×1 | 1800 | 0 | 0-7 | 0 | OK | 4.5 | 1.000 |  |
| explore | openmp | 8 | 1×8 | 1800 | 0 | 0-7 | 0 | OK | 3.3 | 1.000 |  |
| explore | hybrid | 8 | 4×2 | 1800 | 0 | 0-7 | 0 | OK | 3.4 | 1.000 |  |
| explore | mpi | 6 | 6×1 | 1800 | 0 | 0-5 | 0 | OK | 4.5 | 1.000 |  |
| explore | openmp | 6 | 1×6 | 1800 | 0 | 0-5 | 0 | OK | 3.7 | 1.000 |  |
| explore | hybrid | 6 | 3×2 | 1800 | 0 | 0-5 | 0 | OK | 3.7 | 1.000 |  |
| explore | mpi | 4 | 4×1 | 1800 | 0 | 0-3 | 0 | OK | 4.9 | 1.000 |  |
| explore | openmp | 4 | 1×4 | 1800 | 0 | 0-3 | 0 | OK | 4.5 | 1.000 |  |
| explore | hybrid | 4 | 2×2 | 1800 | 0 | 0-3 | 0 | OK | 4.4 | 1.000 |  |
| options | mpi io2 | 12 | 12×1 | 1800 | 0 | 0-11 | 0 | OK | 1.9 | 1.000 |  |
| options | mpi io3 | 12 | 12×1 | 1800 | 0 | 0-11 | 0 | OK | 2.1 | 1.000 |  |
| options | mpi io2 | 10 | 10×1 | 1800 | 0 | 0-9 | 0 | OK | 2.1 | 1.000 |  |
| options | mpi io3 | 10 | 10×1 | 1800 | 0 | 0-9 | 0 | OK | 2.3 | 1.000 |  |
| options | mpi io2 | 8 | 8×1 | 1800 | 0 | 0-7 | 0 | OK | 2.5 | 1.000 |  |
| options | mpi io3 | 8 | 8×1 | 1800 | 0 | 0-7 | 0 | OK | 2.8 | 1.000 |  |
| options | mpi io2 | 6 | 6×1 | 1800 | 0 | 0-5 | 0 | OK | 3.1 | 1.000 |  |
| options | mpi io3 | 6 | 6×1 | 1800 | 0 | 0-5 | 0 | OK | 3.8 | 1.000 |  |

