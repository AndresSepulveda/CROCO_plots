#!/bin/bash
# ---------------- Script SBATCH - NLHPC - Slurm Parameters ----------------
# WAVEWATCH III benchmark (ww3_bench.py) inside ONE Slurm allocation: every simulation is launched
# by ww3_bench.py as an 'srun' job step, so no run waits in the queue and the timings are comparable.
#SBATCH -J WW3_BENCH
#SBATCH -p general
#SBATCH -N 1                       # one node: all runs share this node's cores
#SBATCH -n 16                      # cores available to the benchmark (>= ref_cores in the JSON)
#SBATCH --ntasks-per-node=16
#SBATCH -c 1
#SBATCH --exclusive                # whole node: no other user's job disturbs the timings
#SBATCH -t 3-00:00:00              # wall time; the benchmark stops cleanly before it (walltime_margin_s)
#SBATCH --mail-user=your.email@institution.cl
#SBATCH --mail-type=ALL
#SBATCH -o WW3_BENCH_%j.out
#SBATCH -e WW3_BENCH_%j.err
#-----------------Toolchain---------------------------
ml purge
ml intel/2022.00
# ----------------Modulos----------------------------
# Modules needed to compile WW3 (NetCDF, CMake) or a WW3 module with ready executables.
# Check the names on the cluster with:  ml spider netcdf   /   ml spider cmake   /   ml spider ww3
# ml netCDF-Fortran
# ml CMake
# Python 3 with numpy and matplotlib (reportlab for the formatted PDF), e.g.:  ml Python
# and install the packages once with:  python3 -m pip install --user numpy matplotlib reportlab netCDF4
#-------------------Comandos--------------------------
cd "$SLURM_SUBMIT_DIR"
python3 ww3_bench.py -c bench_hpc.json
# If the wall time runs out, results are kept: submit this same script again to resume.
