#!/bin/bash
#
# # Environment for Crontab
if [ -f /etc/bashrc ]; then
    . /etc/bashrc
fi
source ~/.bashrc

export PATH=/usr/local/bin:/usr/local/sbin:$PATH

export TIME0=$(date +'%s' -d '2000-01-01')
export NOW=new=$(date +'%s')
export TIME=$(( ($NOW - $TIME0) / 86400 ))
export TDIR=$(date +'%Y%m%d')
export TRIV=$(date +'%m-%d')

export RUNDIR=/home/dgeo/Run_Chiloe
export FILESDIR=/home/dgeo/Run_Chiloe/ROMS_FILES
export SCRATCHDIR=/home/dgeo/Run_Chiloe/SCRATCH/$TDIR
export OGCM=mercator
export ATMOS_BULK=GFS
export DT=45
export NUMTIMES=7680
export NUMHIS=80
export NUMAVG=1920  
export NUMRST=1920  
export NODOS=4
export CORES=12
export MODEL=roms_tides
export PRLZTN=mpi
export NP_XI=4
export NP_ETA=12
  
export GRIDFILE=roms_ChiloeAysen_grd_v2.nc
export BRYFILE=roms_bry_${OGCM}_$TIME.nc
export BLKFILE=roms_blk_${ATMOS_BULK}_$TIME.nc
export FRCFILE=roms_frc_${ATMOS_BULK}_$TIME.nc
#export INIFILE=roms_ini_${OGCM}_$TIME.nc
export RSTFILE=roms_rst_$TDIR.nc
export HISFILE=roms_his_$TDIR.nc
export AVGFILE=roms_avg_$TDIR.nc

#
# Obteniendo CB y CI - Mercator y GFS
#
date 
cd $RUNDIR
echo "DOMINIO CHILOE" 
octave --silent --eval 'start','make_OGCM_frcst','make_GFS'
echo "make_OCM_frcst and GFS done"

#
# Copiar archivos
#
mkdir $SCRATCHDIR
date
echo "COPIANDO ARCHIVOS"
cp $FILESDIR/$GRIDFILE $SCRATCHDIR
cp $FILESDIR/$BRYFILE $SCRATCHDIR
cp $FILESDIR/$BLKFILE $SCRATCHDIR
cp $FILESDIR/$FRCFILE $SCRATCHDIR
cp $RUNDIR/${MODEL}_${PRLZTN}_${NP_XI}_${NP_ETA} $SCRATCHDIR

# Copia el restart correspondiente
for day in `seq 1 4`
do
export AYERDIR=$(date +%Y%m%d -d "$day day ago")
export AYERFILE=$RUNDIR/SCRATCH/$AYERDIR/roms_rst_$AYERDIR.nc
if [ -f $AYERFILE ];
then
export INIFILE=roms_rst_$AYERDIR.nc
export RSTREC=$day
cp $AYERFILE $SCRATCHDIR
break
fi
done

#
# Reintentamos obtener CB (por si se cae)
#
while [ ! -f $SCRATCHDIR/$BRYFILE ] ;
do
      sleep 60
echo "REPITIENDO OGCM"
octave --silent --eval 'start','make_OGCM_frcst'
cp $FILESDIR/$BRYFILE $SCRATCHDIR
#cp $FILESDIR/$INIFILE $SCRATCHDIR
done

while [ ! -f $SCRATCHDIR/$FRCFILE ] ;
do
      sleep 60
echo "REPITIENDO GFS"
octave --silent --eval 'start','make_GFS'
cp $FILESDIR/$FRCFILE $SCRATCHDIR
cp $FILESDIR/$BLKFILE $SCRATCHDIR
done

# Trabajando rios
export FLX1=$(cat /home/dgeo/Run_Chiloe/rios_chilesur.csv | awk "/$TRIV/" | awk '{ print $2}')
export FLX2=$(cat /home/dgeo/Run_Chiloe/rios_chilesur.csv | awk "/$TRIV/" | awk '{ print $3}')
export FLX3=$(cat /home/dgeo/Run_Chiloe/rios_chilesur.csv | awk "/$TRIV/" | awk '{ print $4}')
export FLX4=$(cat /home/dgeo/Run_Chiloe/rios_chilesur.csv | awk "/$TRIV/" | awk '{ print $5}')



# 
date
echo "EDITANDO ARCHIVOS CONFIGURACION"
cp $RUNDIR/roms_inter.in $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/GRDFILE/$GRIDFILE/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/BRYFILE/$BRYFILE/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/BLKFILE/$BLKFILE/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/FRCFILE/$FRCFILE/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/INIFILE/$INIFILE/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/RSTFILE/$RSTFILE/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/HISFILE/$HISFILE/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/AVGFILE/$AVGFILE/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/DETE/$DT/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/RSTREC/$RSTREC/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/NUMTIMES/$NUMTIMES/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/NUMAVG/$NUMAVG/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/NUMHIS/$NUMHIS/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/NUMRST/$NUMRST/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/FLX1/$FLX1/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/FLX2/$FLX2/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/FLX3/$FLX3/g" $SCRATCHDIR/roms_$TIME.in
sed -i -e "s/FLX4/$FLX4/g" $SCRATCHDIR/roms_$TIME.in

cp $RUNDIR/run_roms_mpi.pbs $SCRATCHDIR/run_roms_$TIME.pbs
sed -i -e "s/TIME/$TIME/g" $SCRATCHDIR/run_roms_$TIME.pbs
sed -i -e "s/TDIR/$TDIR/g" $SCRATCHDIR/run_roms_$TIME.pbs
sed -i -e "s/MODEL/$MODEL/g" $SCRATCHDIR/run_roms_$TIME.pbs
sed -i -e "s/CORES/$CORES/g" $SCRATCHDIR/run_roms_$TIME.pbs
sed -i -e "s/NODOS/$NODOS/g" $SCRATCHDIR/run_roms_$TIME.pbs
sed -i -e "s/NPXI/$NP_XI/g" $SCRATCHDIR/run_roms_$TIME.pbs
sed -i -e "s/NPETA/$NP_ETA/g" $SCRATCHDIR/run_roms_$TIME.pbs
sed -i -e "s/PRLZTN/$PRLZTN/g" $SCRATCHDIR/run_roms_$TIME.pbs

cp $RUNDIR/mailcheck_chiloe.sh.tmp $RUNDIR/mailcheck_chiloe.sh
sed -i -e "s/TIME/$TIME/g" $RUNDIR/mailcheck_chiloe.sh
sed -i -e "s/TDIR/$TDIR/g" $RUNDIR/mailcheck_chiloe.sh
chmod u+x $RUNDIR/mailcheck_chiloe.sh

date
echo "CORRIENDO PRONOSTICO"
qsub $SCRATCHDIR/run_roms_$TIME.pbs

date

# Esperamos que el pronostico termine
while :
do
export var=`qstat | grep Chiloe-Frcst | awk '/Chiloe-Frcst/' `
export status=${var:69:1}
if [[ $status == C ]] ; then

/usr/bin/tail -n 13 $SCRATCHDIR/log_$TIME > dailylog_chiloe.txt
/usr/bin/mutt -s "Pronostico Chiloe en IFOP" osv.artal@gmail.com        < dailylog_chiloe.txt
/usr/bin/mutt -s "Pronostico Chiloe en IFOP" andres.sepulveda@gmail.com < dailylog_chiloe.txt
/usr/bin/mutt -s "Pronostico Chiloe en IFOP" cristian.ruiz@ifop.cl < dailylog_chiloe.txt
/usr/bin/mutt -s "Pronostico Chiloe en IFOP" elias.pinilla@ifop.cl < dailylog_chiloe.txt


echo "Plots DOMINIO CHILOE" 
date
cd $RUNDIR
octave --silent --eval 'start','plots_forecast_chiloe_v4'
echo "Graficos terminados"
date

##curl -T "*.png" -u pronchiloeaysen@iproach.cl:ChiloeAysen2015 200.24.13.80

##lftp sftp://pronchiloeaysen@iproach.cl:ChiloeAysen2015@200.24.13.80  -e "mput *.png; bye"
##lftp sftp://pronchiloeaysen@iproach.cl:ChiloeAysen2015@200.24.13.80  -e "mput ????_sup_his.gif; bye"

##lftp sftp://pronchiloeaysen:chiloeAysen2015@ftp.iproach.cl  -e "mput ????_sup_his.gif; bye"

cp $SCRATCHDIR/*.png /home/dgeo/Run_Chiloe/ima_pronostico/
cp $SCRATCHDIR/*.gif /home/dgeo/Run_Chiloe/ima_pronostico/


break
else
sleep 60
fi
done

echo DONE
date


