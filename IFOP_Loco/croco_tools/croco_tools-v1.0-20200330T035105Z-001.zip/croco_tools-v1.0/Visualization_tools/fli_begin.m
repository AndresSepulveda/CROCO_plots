function fid = fli_begin

%function fid = fli_begin

fid = fopen('.ppm.list','w');
