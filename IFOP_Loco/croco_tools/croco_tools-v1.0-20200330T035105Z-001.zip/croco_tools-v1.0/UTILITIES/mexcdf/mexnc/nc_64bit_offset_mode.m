function mode = nc_64bit_offset_mode()
% NC_64BIT_OFFSET_MODE:  returns integer mnemonic for NC_64BIT_OFFSET
%
% USAGE:  mode = nc_64bit_offset_mode;
mode = 512;
return


