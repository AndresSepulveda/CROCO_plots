function nc_datatype = nc_short()
% NC_SHORT:  returns constant corresponding to NC_SHORT enumerated constant in netcdf.h
%
% USAGE:  nc_datatype = nc_short;
%

nc_datatype = 3;
return



