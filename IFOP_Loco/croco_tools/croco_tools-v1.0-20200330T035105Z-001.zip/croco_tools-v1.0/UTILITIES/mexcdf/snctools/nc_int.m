function nc_datatype = nc_int()
% NC_INT:  returns constant corresponding to NC_INT enumerated constant in netcdf.h
%
% USAGE:  nc_datatype = nc_int;
%

nc_datatype = 4;
return


