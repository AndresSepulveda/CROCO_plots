function version(self)

% Version of 04-Oct-2001 15:40:32.

helpdlg(help(mfilename), 'ncvar')
