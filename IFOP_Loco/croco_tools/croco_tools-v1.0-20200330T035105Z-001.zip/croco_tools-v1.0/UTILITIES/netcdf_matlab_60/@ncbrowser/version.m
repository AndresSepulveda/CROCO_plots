function version(self)

% Version of 04-Oct-2001 15:40:31.

helpdlg(help(mfilename), 'ncbrowser')
